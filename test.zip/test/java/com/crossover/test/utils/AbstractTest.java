package com.crossover.test.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest
public abstract class AbstractTest {
	
	@Rule
    public TestName testName = new TestName();

    protected Map<String, Object> testData = new HashMap<>();

    private static ObjectMapper mapper;

    @BeforeClass
    public static void setupMapper() {
        mapper = new ObjectMapper();
        mapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
    }

    @SuppressWarnings("unchecked")
    public <T> T getExpectedResult(String key) {
        return (T) testData.get(key);
    }

    @SuppressWarnings("unchecked")
    public <T> T getData(String key) {
        return (T) testData.get(key);
    }
    
    @SuppressWarnings("unchecked")
    @Before
    public void loadTestData() {
        try {
            JavaType type = mapper.getTypeFactory().constructMapLikeType(Map.class, String.class,
                    Object.class);
            String resouce = "/" + this.getClass().getName().replace('.', '/') + ".json";
            Map<String, Object> data = mapper.readValue(this.getClass().getResource(resouce).openStream(), type);
            if (data.containsKey(testName.getMethodName()))
                testData.putAll((Map<String, Object>) data.get(testName.getMethodName()));
        } catch (IOException e) {
            throw new RuntimeException(
                    "Can't read the test data from of class : " + this.getClass().getName(), e);
        }
    }
    
}

package com.crossover.techtrial.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.crossover.techtrial.model.Person;
import com.crossover.techtrial.repositories.PersonRepository;
import com.crossover.test.utils.AbstractTest;


@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@Transactional
public class PersonServiceImplTest extends AbstractTest{

	@Autowired
    private PersonService personService;

    @Autowired
    private PersonRepository personRepo;
    
    @Test
    public void testAddPerson() {
        Person originalPerson = getData("person");
        Person addedPerson = null;
    	addedPerson = personService.save(originalPerson);
        assertNotNull(addedPerson.getId());
        Person currentPerson = personRepo.findById(addedPerson.getId()).orElse(null);
        assertEquals(currentPerson.getId(), currentPerson.getId());
    }
}

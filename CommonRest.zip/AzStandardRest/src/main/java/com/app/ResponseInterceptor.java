package com.app;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * 各APIのレスポンスについて、共通の処理を行うインターセプタクラス
 * @author 810
 *
 */
public class ResponseInterceptor extends HandlerInterceptorAdapter {

	/* (非 Javadoc)
	 * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// キャッシュコントロールヘッダ追加
		response.addHeader(HttpHeaders.CACHE_CONTROL, "private, no-store, no-cache, must-revalidate, max-age=0");
		response.addHeader(HttpHeaders.PRAGMA, "no-cache");
		return super.preHandle(request, response, handler);
	}

}

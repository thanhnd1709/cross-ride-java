package com.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicates;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Swagger設定クラス
 * @author（TOSCO）ウェイ
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {
	@Bean
    public Docket document() {
		return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select()
		          .apis(Predicates.not(RequestHandlerSelectors.basePackage("org.springframework.boot")))
		             .build()
                     //.produces(new HashSet<String>(Arrays.asList("application/json"))) //Or whatever default value(s)
                     //.consumes(new HashSet<String>(Arrays.asList("application/json"))) //Response Content Typeが*/*になってしまう対策
                     .useDefaultResponseMessages(false); //デフォルトのメッセージコードを抑制する対応　※デフォルトをやめる代わりにControllerの各メソッドにmessage用のアノテーションを付けること
    }

	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("AzureIoT検証システムAPI").description("AzureIoT検証システムAPI 仕様書").version("1.0").build();

	}
}

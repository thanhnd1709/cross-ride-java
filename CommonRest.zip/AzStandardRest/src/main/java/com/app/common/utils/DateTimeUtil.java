package com.app.common.utils;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.app.common.Consts;

/**
 * 日付・時刻ユーティリティクラス
 */
public class DateTimeUtil {
	private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
	private static final SimpleDateFormat FORMATTER1 = new SimpleDateFormat(Consts.DATE_FORMAT1);
	private static final SimpleDateFormat FORMATTER2 = new SimpleDateFormat(Consts.DATE_FORMAT);
	private static final SimpleDateFormat FORMATTER3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final DecimalFormat MICRISEC_FORMATTER = new DecimalFormat("0000000");

	public static Timestamp parseTimestamp(String datetimeStr) throws ParseException {
		Timestamp ts = new Timestamp(FORMATTER.parse(datetimeStr.substring(0,19)).getTime());
		ts.setNanos(Integer.parseInt(datetimeStr.substring(20,27)) * 100);
		return ts;
	}

	public static Timestamp parseTimestamp2(String datetimeStr) throws ParseException {
		Timestamp ts = new Timestamp(FORMATTER3.parse(datetimeStr.substring(0,19)).getTime());
		ts.setNanos(Integer.parseInt(datetimeStr.substring(20,27)) * 100);
		return ts;
	}

	public static String formatTimestamp(Timestamp ts) {
		return FORMATTER.format(ts) + "." + MICRISEC_FORMATTER.format(ts.getNanos() / 100) + "Z";
	}

	/**
	 * Timestampから文字列「yyyyMMddHHmmssSSSSSSS」に変換する
	 */
	public static String formatTs(Timestamp ts){
		return FORMATTER1.format(ts) + MICRISEC_FORMATTER.format(ts.getNanos() / 100);
	}

	/**
	 * 文字列「yyyyMMddHHmmssSSSSSSS」からTimestampに変換する
	 */
	public static Timestamp toTimestamp(String strDate) throws Exception{
		Timestamp ts = new Timestamp(FORMATTER1.parse(strDate.substring(0, 14)).getTime());
		ts.setNanos(Integer.parseInt(strDate.substring(14, 21)) * 100);
		return ts;
	}

	/**
	 * Dateから文字列「yyyyMMddHHmmssSSSSSSS」に変換する
	 */
	public static String formatDate(Date d){
		Timestamp ts = new Timestamp(d.getTime());
		return FORMATTER1.format(ts) + MICRISEC_FORMATTER.format(ts.getNanos() / 100);
	}

	/**
	 * 文字列「yyyyMMddHHmmssSSSSSSS」からDateに変換する
	 */
	public static Date toDate(String strDate) throws Exception{
		return new Date(toTimestamp(strDate).getTime());
	}

	/**
	 * 文字列「yyyy-MM-dd HH:mm:ss.SSSSSSS」からTimestampに変換する
	 */
	public static Timestamp toTimestamp1(String strDate) throws Exception{
		Timestamp ts = new Timestamp(FORMATTER2.parse(strDate.substring(0, 19)).getTime());
		ts.setNanos(Integer.parseInt(strDate.substring(20, 27)) * 100);
		return ts;
	}

	/**
	 * 文字列「yyyy-MM-dd HH:mm:ss.SSSSSSS」からDateに変換する
	 */
	public static Date toDate1(String strDate) throws Exception{
		return new Date(toTimestamp1(strDate).getTime());
	}

	/**
	 * TimestampからDateに変換する
	 */
	public static Date tsToDate(Timestamp ts){
		return new Date(ts.getTime());
	}
}

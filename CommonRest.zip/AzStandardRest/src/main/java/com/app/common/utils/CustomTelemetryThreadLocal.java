package com.app.common.utils;

import java.util.HashMap;
import java.util.Map;

public class CustomTelemetryThreadLocal {

	private CustomTelemetryThreadLocal() {};

	private static ThreadLocal<Map<String,String>> customTelemetry = new ThreadLocal<Map<String,String>>() {
		protected Map<String,String> initialValue() {
			return new HashMap<String,String>();
		};
	};

	/**
	 * エラーメッセージを取得します。
	 *
	 */
	public static String getErrorMsg() {
		return customTelemetry.get().get("errorMsg");
	}

	/**
	 * エラーメッセージを設定します。
	 *
	 */
	public static void setErrorMsg(String errorMsg) {
		customTelemetry.get().put("errorMsg", errorMsg);
	}

	/**
	 * エラーコードを取得します。
	 *
	 */
	public static String getErrorCode() {
		return customTelemetry.get().get("errorCode");
	}

	/**
	 * エラーコードを設定します。
	 *
	 */
	public static void setErrorCode(String errorCode) {
		customTelemetry.get().put("errorCode", errorCode);
	}

	/**
	 * 任意のプロパティを取得します。
	 *
	 */
	public static String getCustomProp(String customProp) {
		return customTelemetry.get().get("customProp");
	}


	/**
	 * 任意のプロパティを設定します。
	 *
	 */
	public static void setCustomProp(String customPropKey, String customPropValue) {
		customTelemetry.get().put(customPropKey,customPropValue);
	}

	/**
	 * 任意のプロパティをMapで設定します。
	 *
	 */
	public static void setCustomProp(Map<String,String> customPropMap) {
		customTelemetry.get().putAll(customPropMap);
	}

	/**
	 * 設定されているプロパティをMapで取得します。
	 *
	 */
	public static Map<String,String> getCustomProp() {
		return customTelemetry.get();
	}

}

package com.app.common.utils;

import java.io.FileWriter;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.app.common.Consts;
import com.app.exception.IoTSQLException;

/**
 * Stringユーティリティクラス
 * @author （TOSCO）ウェイ
 */
public class StringUtil {

	/**
	 * nullかどうかをチェックします。
	 *@param strVal
	 *@return nullの場合：true、以外：false
	 */
	public static boolean IsNullOrEmpty(String strVal){

		//nullの場合
		if(strVal == null){
			return true;
		}
		return false;
	}

	/**
	 * 空白、又は ブランクかどうかをチェックします。
	 *@param strVal
	 *@return 空白、又は ブランクの場合：true、以外：false
	 */
	public static boolean IsBlank(String strVal){

		//空白、又は ブランクの場合
		if("" == strVal.trim() || 0 == strVal.trim().length()){
			return true;
		}
		return false;
	}

	/**
	 * 半角英数字かどうかをチェックします。
	 *@param strVal
	 *@return 半角英数字の場合：true、以外：false
	 */
	public static boolean IsHalfAlphNum(String strVal){

		Pattern p = Pattern.compile("^[\\w\\.\\-]+$");
		Matcher m = p.matcher(strVal);

		//半角英数字の場合
		if(m.find() == true){
			return true;
		}
		return false;
	}

	/**
	 * 半角数字かどうかをチェックします。
	 *@param strVal
	 *@return 半角数字の場合：true、以外：false
	 */
	public static boolean IsHalfNumber(String strVal){

		Pattern p = Pattern.compile("^[0-9]+$");
		Matcher m = p.matcher(strVal);

		//半角数字の場合
		if(m.find() == true){
			return true;
		}
		return false;
	}

	/**
	 * 半角数字(小数含む)かどうかをチェックします。
	 * @param strVal
	 * @return 半角数字の場合：true、以外：false
	 */
	public static boolean IsHalfNumberDbl(String strVal){

		//半角数字の場合
		try{
			Double.parseDouble(strVal);
			return true;
		}
		catch(Exception e){
			return false;
		}
	}


	/**
	 * 指定した型で変換す。
	 * @param strVal
	 * @return 変換できる場合：true、以外：false
	 */
	public static boolean IsValidType(String dataType, String strVal){

		//半角数字の場合
		try{
			switch (dataType){
			case Consts.DATA_TYPE_INT:
				Integer.parseInt(strVal);
				break;
			case Consts.DATA_TYPE_LONG:
				Long.parseLong(strVal);
				break;
			case Consts.DATA_TYPE_REAL:
				Float.parseFloat(strVal);
				break;
			case Consts.DATA_TYPE_FLOAT:
				Double.parseDouble(strVal);
				break;
			case Consts.DATA_TYPE_STAT:
				Integer.parseInt(strVal);
				break;
			}

			return true;
		}
		catch(Exception e){
			return false;
		}
	}


	/**
	 * 桁数チェックをします。
	 *@param strVal
	 *@param precNum
	 *@return 桁数を超える場合：false、以外：true
	 */
	public static boolean chkLength(String strVal,Integer decNum){

		//桁数を超える場合
		if(strVal.length() > decNum){
			return false;
		}
		return true;
	}

	/**
	 * 「/、\、#、?」何れかが含まれているかどうかをチェックします。
	 *@param strVal
	 *@return 「/、\、#、?」何れかが含まれている場合：true、以外：false
	 */
	public static boolean IsValidAlphNum(String strVal){

		Pattern p = Pattern.compile("(?=.*(\\/|\\\\|#|\\?)).*$");
		Matcher m = p.matcher(strVal);

		//「/、\、#、?」何れかが含まれている場合
		if(m.find() == true){
			return true;
		}
		return false;
	}

	/**
	 * 「1、2、3、4、5」以外が含まれているかどうかをチェックします。
	 *@param strVal
	 *@return 「1、2、3、4、5」以外が含まれている場合：true、以外：false
	 */
	public static boolean IsValidNum(String strVal){

		Pattern p = Pattern.compile("[^1-5]");
		Matcher m = p.matcher(strVal);

		//「1、2、3、4、5」以外が含まれている場合
		if(m.find() == true){
			return true;
		}
		return false;
	}

	/**
	 * 一致するかどうかをチェックします。
	 *@param strVal1
	 *@param strVal1
	 *@return 一致する場合：false、以外：true
	 */
	public static boolean IsEquals(String strVal1, String strVal2){

		//一致する場合
		if(strVal1.equals(strVal2)){
			return true;
		}
		return false;
	}

	/**
	 * 「true、false」かどうかをチェックします。
	 *@param strVal
	 *@return 「true、false」の場合：true、以外：false
	 */
	public static boolean IsBoolean(String strVal){

		//「true、false」の場合
		if(strVal.equals("true") || strVal.equals("false")){
			return true;
		}
		return false;
	}

	/**
	 * 「1、2」かどうかをチェックします。
	 * @param strVal
	 * @return 「1、2」の場合：true、それ以外の場合：false
	 */
	public static boolean IsChar1(String strVal){

		//一致する場合
		if(strVal.equals("1") || strVal.equals("2")){
			return true;
		}
		return false;
	}

	/**
	 * 「1、2、3」かどうかをチェックします。
	 * @param strVal
	 * @return 「1、2、3」の場合：true、それ以外の場合：false
	 */
	public static boolean IsChar2(String strVal){

		//一致する場合
		if(strVal.equals("1") || strVal.equals("2") || strVal.equals("3")){
			return true;
		}
		return false;
	}

	/**
	 * 「A、1、N」かどうかをチェックします。
	 * @param strVal
	 * @return 「A、1、N」の場合：true、それ以外の場合：false
	 */
	public static boolean IsChar3(String strVal){

		//一致する場合
		if(strVal.equals("A") || strVal.equals("1") || strVal.equals("N")){
			return true;
		}
		return false;
	}


	/**
	 * 「int、float、bit、stat、string、binary、json」かどうかをチェックします。
	 * @param strVal
	 * @return 「int、float、bit、stat、string、binary、json」の場合：true、それ以外の場合：false
	 */
	public static boolean IsType(String strVal){

		//一致する場合
		if(strVal.equals("int") || strVal.equals("float") || strVal.equals("bit") || strVal.equals("stat")
				|| strVal.equals("string") || strVal.equals("binary") || strVal.equals("json")){
			return true;
		}
		return false;
	}

	/**
	 * 上限値以下かどうかをチェックします。
	 * @param strValue
	 * @param max
	 * @return 上限値以下の場合：true、それ以外の場合：false
	 */
	public static boolean IsMax(Double strValue,Double max){

		//上限値以下の場合
		if(strValue <= max){
			return true;
		}
		return false;
	}

	/**
	 * 下限値以上かどうかをチェックします。
	 * @param strValue
	 * @param min
	 * @return 下限値以下の場合：true、それ以外の場合：false
	 */
	public static boolean IsMin(Double strValue,Double min){

		//下限値以下の場合
		if(strValue >= min){
			return true;
		}
		return false;
	}

	/**
	 * 上限値と下限値の整合性をチェックします。
	 * @param max
	 * @param min
	 * @return 上限値 > 下限値の場合：true、それ以外の場合：false
	 */
	public static boolean IsMaxMin(Double max,Double min){

		//上限値 > 下限値の場合
		if(max > min){
			return true;
		}
		return false;
	}

	/**
	 * 指定範囲内であるかチェックします。
	 * @param strVal
	 * @param max
	 * @param min
	 * @return 指定範囲内の場合：true、それ以外の場合：false
	 */
	public static boolean IsMaxMin2(Double strVal,Double max,Double min){

		//指定範囲内の場合
		if(max >= strVal && strVal >= min){
			return true;
		}
		return false;
	}

	/**
	 * 桁数をチェックします
	 * @param strVal
	 * @param maxLen
	 * @return 指定桁数以下の場合：true、以外：false
	 */
	public static boolean IsLength(String strVal,Integer maxLen){

		//指定桁数以下の場合
		if(strVal.length() <= maxLen){
			return true;
		}
		return false;
	}

	/**
	 * int型に収まるデータかどうかチェックします。
	 * @param intVal
	 * @return int型に収まる場合：true、以外：false
	 */
	public static boolean chkInt(int intVal){

		//int型に収まる場合
		if(intVal >= -2147483648 && intVal <= 2147483647){
			return true;
		}

		return false;
	}

	/**
	 * float型に収まるデータかどうかチェックします。
	 * @param fltVal
	 * @return float型に収まる場合：true、以外：false
	 */
	public static boolean chkFloat(Double fltVal){

		//float型に収まる場合
		if((fltVal >= -1.79*(10^308) && fltVal <= -2.23*(10^-308))
				|| fltVal.equals(0)
				|| (fltVal >= 2.23*(10^-308) && fltVal <= 1.79*(10^308))){
			return true;
		}

		return false;
	}

	/**
	 * 日付かどうかをチェックします。
	 * @param strVal
	 * @return 日付として有効なフォーマットの場合：true、以外：false
	 */
	public static boolean IsDate(String strVal){

		//日付として有効なフォーマットの場合
		try{
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			format.parse(strVal);
			return true;
		}
		catch(ParseException e){
			return false;
		}
	}

	/**
	 * 計測時間(From)と計測時間(To)の桁数が一致するかどうかをチェックします。
	 * @param strVal1
	 * @param strVal2
	 * @return 計測時間(From)と計測時間(To)の桁数が一致する場合：true、以外：false
	 */
	public static boolean IsDateLength(String strVal1,String strVal2){
		if(strVal1.length() == strVal2.length()){
			return true;
		}
		return false;
	}

	/**
	 * 計測時間(From)が計測時間(To)以前かどうかをチェックします。
	 * @param from
	 * @param to
	 * @return 計測時間(From)が計測時間(To)以前の場合：true、以外：false
	 */
	public static boolean IsFromTo(String from, String to){
		try{
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			Date dateFrom = format.parse(from);
			Date dateTo = format.parse(to);
			if (dateFrom.before(dateTo)){
				return true;
				}
			return false;
			}

		catch(ParseException e){
			return false;
			}
		}

	/**
	 * 計測時間が有効な範囲かどうかをチェックします。
	 * @param strVal
	 * @return 計測時間が有効な範囲の場合：true、以外：false
	 */
	public static boolean chkMeasureTime(String strVal){

		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();

		//現在日付の取得
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DATE);

        String strNow = ""+ year + month + day;

		try{
			Date dateNow = format.parse(strNow);

			if(strVal.length() == 8){
				Date dateVal = format.parse(strVal);
				if(dateVal.equals(dateNow)){
					return false;
					}
				}
			else{
				Date dateVal = format.parse(strVal.substring(0, 8));
				if(dateVal.before(dateNow)){
					return false;
					}
				}
			return true;
		}
			catch(ParseException e){
			return false;
		}
	}

	/**
	 * StringをIntegerに変換します。
	 * 変換できない場合はIntegerの最小値を返します。
	 * @param 数値文字列
	 * @return 引数をIntegerに変換した値
	 */
	public static Function<String, Integer> String2Integer = x -> {
		try {
			return Integer.valueOf(x);
		} catch (Exception e) {
			return Integer.MIN_VALUE;
		}
	};

	/**
	 * StringをLongに変換します。
	 * 変換できない場合は-1のLong値を返します。
	 * @param 数値文字列
	 * @return 引数をLongに変換した値
	 */
	public static Function<String, Long> String2Long = x -> {
		try {
			return Long.valueOf(x);
		} catch (Exception e) {
			return -1L;
		}
	};

	/**
	 * StringをDoubleに変換します。
	 * 変換できない場合は-1のDouble値を返します。
	 * @param 数値文字列
	 * @return 引数をDoubleに変換した値
	 */
	public static Function<String, Double> String2Double = x -> {
		try {
			return Double.valueOf(x);
		} catch (Exception e) {
			return -1d;
		}
	};

	/**
	 * StringをBigDecimalに変換します。
	 * 変換できない場合は-1のBigDecimal値を返します。
	 * @param 数値文字列
	 * @return 引数をBigDecimalに変換した値
	 */
	public static Function<String, BigDecimal> String2BigDecimal = x -> {
		try {
			return new BigDecimal(x);
		} catch (Exception e) {
			return null;
		}
	};

	/**
	 * StringをBooleanに変換します。
	 * 変換できない場合はnull値を返します。
	 * @param "true"または"false"の文字列
	 * @return 引数をBooleanに変換した値
	 */
	public static Function<String, Boolean> String2Boolean = x -> {
		try {
			return (x.equalsIgnoreCase("true") || x.equalsIgnoreCase("false")) ? Boolean.valueOf(x) : null;
		} catch (Exception e) {
			return null;
		}
	};

	/**
	 * StringをTimeStampに変換します。
	 * 変換できない場合はTimeStampの最小値を返します。
	 * @param yyyy-MM-dd'T'HH:mm:ss.fffffff'Z'形式の文字列
	 * @return 引数をTimeStampに変換した値
	 */
	public static Function<String, Timestamp> String2Timestamp = x -> {
		try {
			return DateTimeUtil.parseTimestamp(x);
		} catch (Exception e) {
			return new Timestamp(0);
		}
	};

	/**
	 * StringをTimeStampに変換します。
	 * 変換できない場合はTimeStampの最小値を返します。
	 * @param yyyy-MM-dd HH:mm:ss.fffffff'Z'形式の文字列
	 * @return 引数をTimeStampに変換した値
	 */
	public static Function<String, Timestamp> String2Timestamp2 = x -> {
		try {
			return DateTimeUtil.parseTimestamp2(x);
		} catch (Exception e) {
			return new Timestamp(0);
		}
	};


	/** 指定したインデックス内の文字列を取得する。
	 * @param target
	 * @param startIdx
	 * @param endIdx
	 * @return 取得した文字列
	 */
	public static String subString(String target, int startIdx, int endIdx){
		try{
			return target.substring(startIdx, endIdx);
		}catch(Exception e){
			throw new IoTSQLException(e);
		}
	}

	/**
	 * 文字列をスプリットする。
	 * @param target
	 * @param regex
	 * @param limit
	 * @return スプリットした文字列
	 */
	public static String[] split(String target, String regex, int limit){
		try{
			return target.split(regex, limit);
		}catch(Exception e){
			throw new IoTSQLException(e);
		}
	}

	/**
	 * 16進数文字列から設定した固定長サイズの2進数文字列へ変換する。
	 * @param data        対象データ
	 * @param fixLength   固定長サイズ
	 * @return 変換した文字列
	 */
	public static String getBitData(String data, int fixLength){

		if(data.trim() == ""){
			return "";
		}else{
			StringBuffer sb = new StringBuffer(Integer.toString(Integer.decode("0x" + data), 2));
			String value = sb.reverse().toString();
			if(fixLength == value.length()){
				return value;
			}
			return fixLength > value.length()?String.format("%1$" + fixLength + "s", value).replace(" ", "0"):
												subString(value, value.length() - fixLength, value.length());
		}
	}

	/**
	 * ファイルパスを取得する。
	 * @return ファイルパス
	 */
	public static String getFilePath(String val1, String val2, String val3, String val4, String val5){
		String filePath = val1;
		filePath += val2 != null && val2.trim() != "" ? Consts.DELIMITER + val2 : "";
		filePath += val3 != null && val3.trim() != "" ? Consts.DELIMITER + val3 : "";
		filePath += val4 != null && val4.trim() != "" ? Consts.DELIMITER + val4 : "";
		filePath += val5 != null && val5.trim() != "" ? Consts.DELIMITER + val5 : "";
		return filePath;
	}

	public static String getFormat(String value, int len){
		return String.format("%1$-" + len + "s", value).replace(" ", "0");
	}

	public static String getFormat1(double value, int len){
		return String.format("%." + len + "f", value);
	}

	/**
	 * CSVファイル読込処理
	 */
	public static void writeCSV(List<String> lstData, String fileName){

		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(fileName);

			for(String data : lstData){
				fileWriter.append(data);
				fileWriter.append(Consts.LINE_SEPARATOR);
			}
		} catch (Exception e) {
			throw new IoTSQLException(e);
		}finally{
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (Exception e) {
				throw new IoTSQLException(e);
			}
		}
	}

	/**
	 * プロパティ名をチャックします。
	 *@param bean
	 *@param paramList
	 *@return ソート項目が存在しない場合：false、以外：true
	 */
	public static boolean hasProperty(Object bean, List<String> paramList){
        List<String> propertyList = new ArrayList<String>();
        Field[] fieldArray = bean.getClass().getDeclaredFields();
        for (int i = 0;i < fieldArray.length;i++) {
            propertyList.add(fieldArray[i].getName());
        }

        for(String param :paramList) {
            if(!propertyList.contains(param)) {
                //存在しないものが1個でもあったらfalse
                return false;
            };
        }
        //全部存在したらtrue
        return true;
    }

	/**
	 * リスト内に重複値があるかどうかをチャックします。
	 *@param sortParamList
	 *@return 重複値がない場合：false、以外：true
	 */
	public static boolean hasDuplicate(List<String> paramList){

		Set<String> set = new HashSet<String>(paramList);
		if(set.size() < paramList.size()){
			return true;
		}
		return false;
	}
}

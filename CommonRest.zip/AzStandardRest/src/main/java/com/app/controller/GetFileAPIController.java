package com.app.controller;

import java.io.File;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.FileModel;
import com.app.model.SubResponseModel;
import com.app.service.GetFileService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * ファイル取得コントローラクラス
 * @author（TOSCO）
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags ={Consts.TAGS_SENSOR_DATA_FILE_MGT,}, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class GetFileAPIController {

	@Autowired private GetFileService _service;
	@Autowired private MessageSource _msgSource;

	public static final Logger logger = LoggerFactory.getLogger(GetFileAPIController.class);

	/**
	 * ファイル取得処理
	 */
	@ApiOperation(value = Consts.MSG_GET_FILE, notes = Consts.MSG_GET_FILE_01, nickname = Consts.OPERATIONID_GET_FILE_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = InputStreamResource.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_FILE, method = RequestMethod.GET)
    public ResponseEntity<InputStreamResource> GetFile(Locale locale, FileModel reqModel) throws Exception {

		logger.info("request：" + reqModel);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// ファイル取得処理
		InputStream result = _service.getFile(reqModel);
		logger.info("response：" + result);

		//ファイル名取得
		String getFileName = new File(reqModel.getFile_name()).getName();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType("application/octet-stream"));

		//ファイル名の半角チェック
		if(getFileName.matches("^[\\u0020-\\u007E]+$")){
			headers.add("Content-Disposition", "attachment; filename=\"" + getFileName + "\"");
		}
		else{
			headers.add("Content-Disposition", "attachment; filename*=UTF-8''" +URLEncoder.encode(getFileName,"UTF-8"));
		}

		ResponseEntity<InputStreamResource> response = new ResponseEntity<InputStreamResource>
			(new InputStreamResource(result), headers, HttpStatus.OK);
		return response;
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, FileModel reqModel, List<SubResponseModel> lstError){

		// リクエスト．ファイル種別が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getFile_type()) || StringUtil.IsBlank(reqModel.getFile_type())){
			lstError.add(new SubResponseModel("file_type"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		// リクエスト．ファイル種別 1 , 9 以外の場合
		}else if(!Consts.FILE_TYPE_1.equals(reqModel.getFile_type())
						&& !Consts.FILE_TYPE_9.equals(reqModel.getFile_type())){
			lstError.add(new SubResponseModel("file_type"
					, _msgSource.getMessage(Consts.MESSAGE_E000048, null, locale)));
		}
		else{
			// リクエスト．ファイル種別が 9 の時は、コンテナ名が null、又は 空白（""）の場合
			if(Consts.FILE_TYPE_9.equals(reqModel.getFile_type())
					&& (StringUtil.IsNullOrEmpty(reqModel.getContainer()) || StringUtil.IsBlank(reqModel.getContainer()))){
				lstError.add(new SubResponseModel("container"
						, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
			}
		}

		// リクエスト．ファイル名が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getFile_name()) || StringUtil.IsBlank(reqModel.getFile_name())){
			lstError.add(new SubResponseModel("file_name"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		}
		return lstError;
	}
}

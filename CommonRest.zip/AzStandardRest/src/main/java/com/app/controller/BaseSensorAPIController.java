package com.app.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.BaseSensorModel;
import com.app.model.BaseSensorQueryModel;
import com.app.model.ResponseModel;
import com.app.model.SubResponseModel;
import com.app.service.BaseSensorService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * センサーマスタコントローラクラス
 *
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_MST)
@Api(tags ={Consts.TAGS_BASE_SENSOR,}, description = Consts.MSG_BASE_SENSOR)
public class BaseSensorAPIController {

	public static final Logger logger = LoggerFactory.getLogger(BaseSensorAPIController.class);

	@Autowired
	private BaseSensorService baseSensorService;
	@Autowired
	private MessageSource messageSource;
	@ApiOperation(value = Consts.MSG_GET_BASE_SENSOR, notes = Consts.MSG_GET_BASE_SENSOR_01, nickname = Consts.OPERATIONID_BASE_SENSOR_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = BaseSensorModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_BASE_SENSOR, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<List<BaseSensorModel>> index(Locale locale, @ModelAttribute @Valid BaseSensorQueryModel querymodel, BindingResult errors) throws Exception {

		logger.info("Get開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, querymodel, querymodel.getFields(), lstError);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}

		// ページング処理
        HttpHeaders headers = new HttpHeaders();
		if (querymodel.getPage() != null && querymodel.getLimit() != null) {
			Integer page = Integer.parseInt(querymodel.getPage());
			Integer limit = Integer.parseInt(querymodel.getLimit());
			Integer next = null;
			Integer prev = null;

			Long count = baseSensorService.countAll(querymodel);
			if (count == 0) {
				return new ResponseEntity<List<BaseSensorModel>>(new ArrayList<BaseSensorModel>(), HttpStatus.OK);
			}
			int countpage = count.intValue() / limit;
			countpage += (count.intValue() % limit > 0) ? 1 : 0;

			if (countpage <= page) page = countpage;
			if (page > 1) prev = page - 1;
			if (page < countpage) next = page + 1;

			querymodel.setPage(String.valueOf(page));
	        UriComponents uriComponents = MvcUriComponentsBuilder.fromMethodName(
	        					BaseSensorAPIController.class, "index",locale, querymodel, errors).build();
	        URI location = uriComponents.toUri();
	        StringBuffer sb = new StringBuffer();
	        if (next != null) {
	        	querymodel.setPage(String.valueOf(next));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"next\",");

	        	querymodel.setPage(String.valueOf(countpage));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"last\"");
	        }
	        if (prev != null) {
	        	if (sb.length() > 0) sb.append(",");

	        	querymodel.setPage("1");
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"first\",");

	        	querymodel.setPage(String.valueOf(prev));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"prev\"");
	        }
	        if (sb.length() > 0) headers.add("Link", sb.toString());

	        querymodel.setPage(String.valueOf(page));
		}

		List<BaseSensorModel> result = baseSensorService.findAll(querymodel);

        return new ResponseEntity<List<BaseSensorModel>>(result, headers, HttpStatus.OK);
	}

	@ApiOperation(value = Consts.MSG_GET_BASE_SENSOR_ID, notes = Consts.MSG_GET_BASE_SENSOR_ID_01, nickname = Consts.OPERATIONID_BASE_SENSOR_SHOW)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = BaseSensorModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_BASE_SENSOR_ID, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public BaseSensorModel show(Locale locale, @PathVariable("id") String idStr
			,@RequestParam(name = Consts.REQUEST_URL_FIELDS_KEY, required = false) String fields) throws Exception {
		logger.info("GetByID開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, null, fields, lstError);

		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
		}

		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}

		BaseSensorModel result = baseSensorService.findOne(id, fields);
		return result;
	}

	@ApiOperation(value = Consts.MSG_POST_BASE_SENSOR, notes = Consts.MSG_POST_BASE_SENSOR_01, nickname = Consts.OPERATIONID_BASE_SENSOR_CREATE)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Created", response = BaseSensorModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 409, message = Consts.HTTP_MESSAGE_409),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_BASE_SENSOR, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<BaseSensorModel> create(Locale locale, @Valid @RequestBody BaseSensorModel model, Errors errors) throws Exception {
		logger.info("POST開始");
		//入力チェック
		 if (errors.hasErrors()) {
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 List<SubResponseModel> lstError = new ArrayList<>();
			 for(FieldError err :  errors.getFieldErrors()) {
				 lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			 }
			 exp.setArgs(lstError);
			 throw exp;
		 }

		 return new ResponseEntity<BaseSensorModel>(baseSensorService.save(model), HttpStatus.CREATED);
	}

	@ApiOperation(value = Consts.MSG_PUT_BASE_SENSOR, notes = Consts.MSG_PUT_BASE_SENSOR_01, nickname = Consts.OPERATIONID_BASE_SENSOR_PUT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = BaseSensorModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 409, message = Consts.HTTP_MESSAGE_409),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_BASE_SENSOR_ID, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
    public BaseSensorModel  put(Locale locale, @PathVariable(value = "id") String idStr, @Valid @RequestBody BaseSensorModel model, Errors errors) throws Exception {
		logger.info("PUT開始");
		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			List<SubResponseModel> lstError = new ArrayList<>();
			String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
			exp.setArgs(lstError);
			throw exp;
		}

		//入力チェック
		 if (errors.hasErrors()) {
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 List<SubResponseModel> lstError = new ArrayList<>();
			 for(FieldError err :  errors.getFieldErrors()) {
				 lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			 }
			 exp.setArgs(lstError);
			 throw exp;
		 }

		 return baseSensorService.update(locale, id, model);
    }

	@ApiOperation(value = Consts.MSG_DELETE_BASE_SENSOR, notes = Consts.MSG_DELETE_BASE_SENSOR_01, nickname = Consts.OPERATIONID_BASE_SENSOR_DELETE)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_BASE_SENSOR_ID, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
    public ResponseEntity<Object> delete(Locale locale
					    , @PathVariable(value = "id") String idStr)
					    		throws Exception {
		logger.info("delete開始");
		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			List<SubResponseModel> lstError = new ArrayList<>();
			 String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
			 exp.setArgs(lstError);
			throw exp;
		}

		// デバイス情報削除処理を行う
		baseSensorService.delete(id);
		// 正常
		ResponseModel returnInfoModel =
				new ResponseModel(HttpStatus.OK.value()
								, HttpStatus.OK.getReasonPhrase()
								, "");
		return new ResponseEntity<Object>(returnInfoModel, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @param locale   ロケール
	 * @param queryModel    検索条件
	 * @param fields   フィールド
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, BaseSensorQueryModel queryModel, String fields, List<SubResponseModel> lstError) {

		String sorts = queryModel == null?null:queryModel.getSort();
		String page = queryModel == null?null:queryModel.getPage();
		String limit = queryModel == null?null:queryModel.getLimit();

		try{
			if (page != null && Integer.parseInt(page) < 1){
				lstError.add(new SubResponseModel("page",
						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page",
					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limit指定あり不正の場合
		try{
			if (limit != null && Integer.parseInt(limit) < 1){
				lstError.add(new SubResponseModel("limit",
						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit",
					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if(sorts != null){
			List<String> sortParams = new ArrayList<String>();
			for (String item : sorts.split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(sortParams)
	        		|| !StringUtil.hasProperty(new BaseSensorModel(), sortParams)){
	        	lstError.add(new SubResponseModel("sort",
	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		// フィールドの指定が不正な場合
		if(fields != null){
			List<String> fieldParams = new ArrayList<String>();
			for (String item : fields.split(",")) {
				fieldParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(fieldParams)
	        		|| !StringUtil.hasProperty(new BaseSensorModel(), fieldParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		return lstError;
	}

}

package com.app.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.ResponseModel1;
import com.app.model.SensorDataModel2;
import com.app.model.SubResponseModel;
import com.app.service.DeleteSensorDataService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * センサーデータ削除コントローラクラス
 * @author（TOSCO）ウェイ
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags ={Consts.TAGS_SENSOR_DATA_FILE_MGT,}, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class DeleteSensorDataAPIController {

	@Autowired private DeleteSensorDataService _service;
	@Autowired private MessageSource _msgSource;

	public static final Logger logger = LoggerFactory.getLogger(DeleteSensorDataAPIController.class);

	/**
	 * センサーデータ削除処理
	 */
	@ApiOperation(value = Consts.MSG_DEL_SENSOR_DATA, notes = Consts.MSG_DEL_SENSOR_DATA_01
					, nickname = Consts.OPERATIONID_SENSOR_DATA_DELETE)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseModel1.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_SENSOR_DATA, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
    public ResponseEntity<ResponseModel1> DeleteSensorData(Locale locale, SensorDataModel2 reqModel)
    		throws Exception {

		logger.info("request：" + reqModel);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// センサーデータを削除する
		_service.deleteSensorData(reqModel);
		return new ResponseEntity<ResponseModel1>(
						new ResponseModel1(Consts.HTTP_CODE_200, Consts.HTTP_MESSAGE_200), HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, SensorDataModel2 req, List<SubResponseModel> lstError){

		boolean isNull = false;

		// 機種IDが null の場合
		if(StringUtil.IsNullOrEmpty(req.getModel_id())){
			lstError.add(new SubResponseModel("model_id"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
			isNull = true;
		}

		// シリアルNoが null の場合
		if(StringUtil.IsNullOrEmpty(req.getSerial_no())){
			lstError.add(new SubResponseModel("serial_no"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
			isNull = true;
		}

		// 機種ID、シリアルNo両方が 空白（""）の場合
		if(isNull == false){
			if(StringUtil.IsBlank(req.getModel_id()) && StringUtil.IsBlank(req.getSerial_no())){
				lstError.add(new SubResponseModel("model_id, serial_no"
						, _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
			}
		}

		// センサーIDが null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(req.getSensor_id()) || StringUtil.IsBlank(req.getSensor_id())){
			lstError.add(new SubResponseModel("sensor_id"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		Date mTimeTo = null;
		Date mTimeFrom = null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		formatter.setLenient(false);

		// 対象期間(From)が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(req.getMeasure_time_from()) || StringUtil.IsBlank(req.getMeasure_time_from())){
			lstError.add(new SubResponseModel("measure_time_from"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			try{
				String dateFrom = req.getMeasure_time_from();
				Timestamp tsFrom = new Timestamp(formatter.parse(dateFrom.substring(0, 19)).getTime());
				tsFrom.setNanos(Integer.parseInt(dateFrom.substring(20, 27)) * 100);
				mTimeFrom = new Date(tsFrom.getTime());

				// 対象期間(From)が現在日時より未来の場合
				/*if(date.compareTo(mTimeFrom) < 0){
					lstError.add(new SubResponseModel("measure_time_from"
							, _msgSource.getMessage(Consts.MESSAGE_E000014
									, new String[]{_msgSource.getMessage(Consts.MESSAGE_SYSTEM_DATETIME, null, locale)
											,_msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_FROM, null, locale)}
							, locale)));
				}*/
			} catch (Exception e) {
				// 対象期間(From)のフォーマットが不正、又は 不正な日付の場合
				lstError.add(new SubResponseModel("measure_time_from"
						, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
			}
		}

		if(!StringUtil.IsNullOrEmpty(req.getMeasure_time_to()) && !StringUtil.IsBlank(req.getMeasure_time_to())){
			try{
				String dateTo = req.getMeasure_time_to();
				Timestamp tsTo = new Timestamp(formatter.parse(dateTo.substring(0, 19)).getTime());
				tsTo.setNanos(Integer.parseInt(dateTo.substring(20, 27)) * 100);
				mTimeTo = new Date(tsTo.getTime());

				// 対象期間(To)が現在日時より未来の場合
				/*if(mTimeTo.compareTo(date) > 0){
					lstError.add(new SubResponseModel("measure_time_to"
							, _msgSource.getMessage(Consts.MESSAGE_E000014
									, new String[]{_msgSource.getMessage(Consts.MESSAGE_SYSTEM_DATETIME, null, locale)
											,_msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_TO, null, locale)}
							, locale)));

				}else{*/
					// 対象期間(From)が対象期間(To)より未来の場合
					if(mTimeFrom != null && mTimeTo.compareTo(mTimeFrom) < 0){
						lstError.add(new SubResponseModel("measure_time_from, measure_time_to"
								, _msgSource.getMessage(Consts.MESSAGE_E000014
										, new String[]{_msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_TO, null, locale)
												, _msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_FROM, null, locale)}
								, locale)));
					}
				//}
			} catch (Exception e) {
				// 対象期間(To)のフォーマットが不正、又は 不正な日付の場合
				lstError.add(new SubResponseModel("measure_time_to"
						, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));

			}
		}

		return lstError;
	}
}

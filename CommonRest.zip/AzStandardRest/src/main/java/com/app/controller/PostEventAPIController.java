package com.app.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.entity.PostEventEntity;
import com.app.exception.BadRequestException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.EventListModel1;
import com.app.model.ResponseModel1;
import com.app.model.StdEventModel;
import com.app.model.SubResponseModel;
import com.app.service.PostEventService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * イベント・アラーム登録コントローラクラス
 * @author（TOSCO）ウェイ
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_ALARM_EVENT_MGT)
@Api(tags ={Consts.TAGS_ALARM_EVENT_MGT,}, description = Consts.MSG_ALARM_EVENT_MGT)
public class PostEventAPIController {

	@Autowired private PostEventService _service;
	@Autowired private MessageSource _msgSource;
	@Autowired private AuthUserInfoComponent authUserInfoComponent;

	public static final Logger logger = LoggerFactory.getLogger(PostEventAPIController.class);

	/**
	 * イベント・アラーム登録処理
	 */
	@ApiOperation(value = Consts.MSG_POST_STD_EVENT, notes = Consts.MSG_POST_STD_EVENT_01, nickname = Consts.OPERATIONID_POST_EVENT_CREATE)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Created", response = ResponseModel1.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@ResponseStatus(HttpStatus.CREATED)
	@RequestMapping(value = Consts.REQUEST_URL_POST_EVENT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public ResponseEntity<ResponseModel1> PostEvent(Locale locale, @RequestBody List<StdEventModel> reqModelList)
    																							throws Exception {
		logger.info("request：" + reqModelList);

		// 認証されたユーザIDを検索条件に設定
		String userId = authUserInfoComponent.getPrincipalName();
		reqModelList.get(0).setUser_id(userId);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModelList, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// イベント・アラーム登録処理
		_service.postFile(reqModelList);

		return new ResponseEntity<ResponseModel1>(
				new ResponseModel1(Consts.HTTP_CODE_201, Consts.HTTP_MESSAGE_201), HttpStatus.CREATED);
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 * @throws Exception
	 */
	private List<SubResponseModel> Validation(Locale locale
												, List<StdEventModel> modelList
												, List<SubResponseModel> lstError) throws Exception{

		//リクエストボディがnull、又は 空リストの場合
		if(modelList == null || modelList.size() <= 0){
			lstError.add(new SubResponseModel("request body"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
			return lstError;
		}

		ArrayList<String> val = new ArrayList<String>();

		String modelId = "";
		String serialNo = "";
		String eventId = "";
		int outIdx = 0;
		for(StdEventModel model : modelList){

			//機種IDがnullの場合
			if(StringUtil.IsNullOrEmpty(model.getModelId())){
				lstError.add(new SubResponseModel("[" + outIdx + "]modelId"
								, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
			}

			//シリアルNoがnullの場合
			if(StringUtil.IsNullOrEmpty(model.getSerialNo())){
				lstError.add(new SubResponseModel("[" + outIdx + "]serialNo"
								, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
			}

			//機種ID と シリアルNo の両方とも 空白("") の場合
			if(!StringUtil.IsNullOrEmpty(model.getModelId()) && StringUtil.IsBlank(model.getModelId())
					&& !StringUtil.IsNullOrEmpty(model.getSerialNo()) && StringUtil.IsBlank(model.getSerialNo())){
				lstError.add(new SubResponseModel("[" + outIdx + "]modelId, serialNo"
								, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
			}

			if(lstError.isEmpty()){
				modelId=model.getModelId();
				serialNo = model.getSerialNo();
			}

			//検出区分が空白（""）の場合
			if(!StringUtil.IsNullOrEmpty(model.getDetectionClass()) && StringUtil.IsBlank(model.getDetectionClass())){
				lstError.add(new SubResponseModel("[" + outIdx + "]detectionClass"
								, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
			}

			List<EventListModel1> eventList = model.getEventList();
			//イベントリストがnull、又は 空リストの場合
			if(eventList == null || eventList.size() <= 0){
				lstError.add(new SubResponseModel("[" + outIdx + "]eventList"
								, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

			}else{
				int inIdx = 0;
				for(EventListModel1 event : eventList){

					//イベント発生時刻が null、又は 空白（""）の場合
					if(StringUtil.IsNullOrEmpty(event.getEventTime()) || StringUtil.IsBlank(event.getEventTime())){
						lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]eventTime"
									, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					}else{
						if(!StringUtil.chkLength(event.getEventTime(), 21) || !StringUtil.IsHalfNumber(event.getEventTime())){
							lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]eventTime"
									, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));

						}else{
							//イベント発生時刻のフォーマットが不正、又は 不正な日付の場合
							try{
								SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
								formatter.setLenient(false);
								Timestamp tsTime = new Timestamp(formatter.parse(event.getEventTime().substring(0, 14)).getTime());
								tsTime.setNanos(Integer.parseInt(event.getEventTime().substring(14, 21)) * 100);
								new Date(tsTime.getTime());

							}catch (Exception e) {
								lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]eventTime"
										, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
							}
						}
					}

					//イベントIDが null、又は 空白（""）の場合
					if(StringUtil.IsNullOrEmpty(event.getEventId()) || StringUtil.IsBlank(event.getEventId())){
						lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]eventId"
										, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					}

					//イベント状態が空白（""）の場合
					if(!StringUtil.IsNullOrEmpty(event.getEventStatus())
							&& StringUtil.IsBlank(event.getEventStatus())){
						lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]eventStatus"
										, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					}

					//発生復帰区分が null、又は 空白（""）の場合
					if(StringUtil.IsNullOrEmpty(event.getIncidentClass())
							|| StringUtil.IsBlank(event.getIncidentClass())){
						lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]incidentClass"
										, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

					//発生復帰区分が 「1、2」以外の場合
					}else if(!StringUtil.IsNullOrEmpty(event.getIncidentClass())
							&& !StringUtil.IsChar1(event.getIncidentClass())){
						lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]incidentClass"
										, _msgSource.getMessage(Consts.MESSAGE_E000044, null, locale)));
					}

					//イベントレベルが空白（""）の場合
					if(!StringUtil.IsNullOrEmpty(event.getEventLevel())
							&& StringUtil.IsBlank(event.getEventLevel())){
						lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]eventLevel"
										, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					}

					//検出時情報が空白（""）の場合
					if(!StringUtil.IsNullOrEmpty(event.getDetectionInfo())
							&& StringUtil.IsBlank(event.getDetectionInfo())){
						lstError.add(new SubResponseModel("[" + outIdx + ":" + inIdx + "]detectionInfo"
										, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					}
					inIdx += 1;
					if(lstError.isEmpty()){
						eventId=event.getEventId();
						val.add(modelId + "$" + serialNo + "$" + eventId);
					}
				}
			}
			outIdx += 1;
		}
		//イベント権限チェック
		if(lstError.isEmpty()){
			List<String> val2 = new ArrayList<String>(new LinkedHashSet<>(val));
			List<PostEventEntity> authChk =  _service.eventAuthChk(val2,modelList.get(0).getUser_id());
			if(!authChk.isEmpty()){
				for(PostEventEntity e : authChk){
					lstError.add(new SubResponseModel("modelId, serialNo, eventId"
							, _msgSource.getMessage(Consts.MESSAGE_E000120,
									new String[] { e.getModel_id(), e.getSerial_no(),e.getEvent_id() }, locale)));
				}
			}
			}


		return lstError;
	}
}

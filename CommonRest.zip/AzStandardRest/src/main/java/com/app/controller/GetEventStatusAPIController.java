package com.app.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.DeviceListModel;
import com.app.model.EventListModel2;
import com.app.model.EventStatusListModel;
import com.app.model.EventStatusModel;
import com.app.model.ResponseEventStatusModel;
import com.app.model.SubResponseModel;
import com.app.service.EventStatusService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * イベント・アラーム状態取得コントローラクラス
 * @author（TOSCO）エヒー
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_ALARM_EVENT_MGT)
@Api(tags= {Consts.TAGS_ALARM_EVENT_MGT,}, description = Consts.MSG_ALARM_EVENT_MGT)
public class GetEventStatusAPIController {

	public static final Logger logger = LoggerFactory.getLogger(GetEventStatusAPIController.class);

	@Autowired private EventStatusService eventStatusService;
	@Autowired private MessageSource _msgSource;

	@ApiOperation(value = Consts.MSG_GET_EVENT_STATUS, notes = Consts.MSG_GET_EVENT_STATUS_01, nickname = Consts.OPERATIONID_GET_EVENT_STATUS_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseEventStatusModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_EVENT_STATUS, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<List<ResponseEventStatusModel>> index(Locale locale, EventStatusModel reqModel, BindingResult result1) throws Exception {

		logger.info("【イベント・アラーム状態取得】Request：" + reqModel);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		List<ResponseEventStatusModel> result = eventStatusService.GetEventStatus(reqModel);
		return new ResponseEntity<List<ResponseEventStatusModel>>(result, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @param locale ロケール
	 * @param reqModelイベント・アラーム状態モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale
												, EventStatusModel reqModel
												, List<SubResponseModel> lstError){

		// リクエスト．検出区分が null、又は 空白（""）の場合
		if (reqModel.getGet_class() == null || reqModel.getGet_class().length == 0) {
			lstError.add(new SubResponseModel("get_class"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		} else {
			// リクエスト．検出区分が 1/2/3/4/5 以外の場合
			for (String getClass : reqModel.getGet_class()) {
				if (StringUtil.IsValidNum(getClass)) {
					lstError.add(new SubResponseModel("get_class"
							, _msgSource.getMessage(Consts.MESSAGE_E000046, null, locale)));
				}
			}
		}

		// リクエスト．発生復帰区分 が 入力されている場合
		if (!StringUtil.IsNullOrEmpty(reqModel.getIncident_class())&& !StringUtil.IsBlank(reqModel.getIncident_class())) {
			// リクエスト．発生復帰区分 が 1/2/3 以外の場合
			if (!StringUtil.IsChar2(reqModel.getIncident_class())) {
				lstError.add(new SubResponseModel("incident_class"
						, _msgSource.getMessage(Consts.MESSAGE_E000045, null, locale)));
			}
		}

		//イベント時刻のフォーマットチェック
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		formatter.setLenient(false);

		if (!StringUtil.IsNullOrEmpty(reqModel.getEvent_time()) && !StringUtil.IsBlank(reqModel.getEvent_time())) {

			try {
				String eventDate = reqModel.getEvent_time();
				Timestamp tsFrom = new Timestamp(formatter.parse(eventDate.substring(0, 19)).getTime());
				tsFrom.setNanos(Integer.parseInt(eventDate.substring(20, 27)) * 100);
				new Date(tsFrom.getTime());

			} catch (Exception e) {
				// イベント時刻のフォーマットが不正、又は 不正な日付の場合
				lstError.add(new SubResponseModel("event_time",
						_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
			}
		}

		//発生時刻のフォーマットチェック
		if (!StringUtil.IsNullOrEmpty(reqModel.getIncident_time())
				&& !StringUtil.IsBlank(reqModel.getIncident_time())) {
			try {
				String incitentDate = reqModel.getIncident_time();
				Timestamp tsFrom = new Timestamp(formatter.parse(incitentDate.substring(0, 19)).getTime());
				tsFrom.setNanos(Integer.parseInt(incitentDate.substring(20, 27)) * 100);
				new Date(tsFrom.getTime());
			} catch (Exception e) {
				// 発生時刻のフォーマットが不正、又は 不正な日付の場合
				lstError.add(new SubResponseModel("incident_time",
						_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
			}
		}

		// 復帰時刻のフォーマットチェック
		if (!StringUtil.IsNullOrEmpty(reqModel.getReturn_time()) && !StringUtil.IsBlank(reqModel.getReturn_time())) {
			try {
				String returnDate = reqModel.getReturn_time();
				Timestamp tsFrom = new Timestamp(formatter.parse(returnDate.substring(0, 19)).getTime());
				tsFrom.setNanos(Integer.parseInt(returnDate.substring(20, 27)) * 100);
				new Date(tsFrom.getTime());
			} catch (Exception e) {
				// 復帰時刻のフォーマットが不正、又は 不正な日付の場合
				lstError.add(new SubResponseModel("return_time",
						_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
			}
		}

		// デバイスグループID 指定時、 [配列]デバイスリスト、 [配列]イベントリスト は指定不可
  		// [配列]デバイスリスト指定時、デバイスグループID 、 [配列]イベントリスト は指定不可
       	// [配列]イベントリスト指定時、 [配列]デバイスリスト、デバイスグループID は指定不可
		int cnt = 0;
		int idx;
		if (!StringUtil.IsNullOrEmpty(reqModel.getDevice_group_id()) && !StringUtil.IsBlank(reqModel.getDevice_group_id())){
			cnt++;
		}
		if (reqModel.getDevice_list() != null && reqModel.getDevice_list().size() > 0) {
			cnt++;

			idx = 0;
			for(DeviceListModel devModel : reqModel.getDevice_list()){
				if(StringUtil.IsNullOrEmpty(devModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]device_list.model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

				}else if(StringUtil.IsNullOrEmpty(devModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]device_list.serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}
				idx += 1;
			}
		}
		if (reqModel.getEvent_list() != null && reqModel.getEvent_list().size() > 0) {
			cnt++;

			idx = 0;
			for(EventListModel2 eventModel : reqModel.getEvent_list()){
				if(StringUtil.IsNullOrEmpty(eventModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]event_list.model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

				}else if(StringUtil.IsNullOrEmpty(eventModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]event_list.serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

				}else if(StringUtil.IsNullOrEmpty(eventModel.getEvent_id())){
					lstError.add(new SubResponseModel("[" + idx + "]event_list.event_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}
				idx += 1;
			}
		}
		if(cnt > 1){
			lstError.add(new SubResponseModel("device_group_id, device_list, event_list",
					_msgSource.getMessage(Consts.MESSAGE_E000034, null, locale)));
		}

		try{
			if (reqModel.getPage() != null && Integer.parseInt(reqModel.getPage()) < 1){
				lstError.add(new SubResponseModel("page",
						_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page",
					_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limit指定あり不正の場合
		try{
			if (reqModel.getLimit() != null && Integer.parseInt(reqModel.getLimit()) < 1){
				lstError.add(new SubResponseModel("limit",
						_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit",
					_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if (reqModel.getSort() != null) {
			List<String> sortParams = new ArrayList<String>();
			for (String item : reqModel.getSort().split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

			if (StringUtil.hasDuplicate(sortParams) ||
				 !StringUtil.hasProperty(new EventStatusListModel(), sortParams)) {
					lstError.add(
							new SubResponseModel("sort", _msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
			}
		}
		// フィールドの指定が不正な場合
		if (reqModel.getFields() != null) {
			List<String> fieldParams = new ArrayList<String>();
			for (String item : reqModel.getFields().split(",")) {
				fieldParams.add(item.toLowerCase().replace("-", ""));
			}

			if (StringUtil.hasDuplicate(fieldParams) ||
				 !StringUtil.hasProperty(new EventStatusListModel(), fieldParams)) {
					lstError.add(
							new SubResponseModel("fields", _msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
			}
		}

		return lstError;
	}
}


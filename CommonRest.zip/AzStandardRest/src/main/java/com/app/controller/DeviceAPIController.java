/**
 * デバイス情報(DB)コントローラクラス
 *
 */
package com.app.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.DeviceModel;
import com.app.model.DeviceQueryModel;
import com.app.model.ResponseModel;
import com.app.model.SubResponseModel;
import com.app.repository.DeviceRepositoryCustom;
import com.app.service.DeviceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_MST)
@Api(tags ={Consts.TAGS_DEVICE,}, description = Consts.MSG_DEVICE)
public class DeviceAPIController {

	public static final Logger logger = LoggerFactory.getLogger(DeviceAPIController.class);

	@Autowired
	private DeviceService deviceService;
	@Autowired
	private DeviceRepositoryCustom deviceRepositoryCustom;
	@Autowired
	private MessageSource messageSource;
	@ApiOperation(value = Consts.MSG_GET_DEVICE, notes = Consts.MSG_GET_DEVICE_01, nickname = Consts.OPERATIONID_DEVICE_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = DeviceModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<List<DeviceModel>> index(Locale locale
			, @ModelAttribute @Valid DeviceQueryModel querymodel, BindingResult errors) throws Exception {

		logger.info("Get開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, querymodel, querymodel.getFields(), lstError);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// ページング処理
        HttpHeaders headers = new HttpHeaders();
		if (querymodel.getPage() != null && querymodel.getLimit() != null) {
			Integer page = Integer.parseInt(querymodel.getPage());
			Integer limit = Integer.parseInt(querymodel.getLimit());
			Integer next = null;
			Integer prev = null;

			Long count = deviceService.countAll(querymodel);
			if (count == 0) {
				return new ResponseEntity<List<DeviceModel>>(new ArrayList<DeviceModel>(), HttpStatus.OK);
			}
			int countpage = count.intValue() / limit;
			countpage += (count.intValue() % limit > 0) ? 1 : 0;

			if (countpage <= page) page = countpage;
			if (page > 1) prev = page - 1;
			if (page < countpage) next = page + 1;

			querymodel.setPage(String.valueOf(page));
			UriComponents uriComponents = MvcUriComponentsBuilder
					.fromMethodName(DeviceAPIController.class, "index", locale, querymodel, errors).build();
	        URI location = uriComponents.toUri();
	        StringBuffer sb = new StringBuffer();
	        if (next != null) {
	        	querymodel.setPage(String.valueOf(next));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"next\",");

	        	querymodel.setPage(String.valueOf(countpage));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"last\"");
	        }
	        if (prev != null) {
	        	if (sb.length() > 0) sb.append(",");

	        	querymodel.setPage("1");
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"first\",");

	        	querymodel.setPage(String.valueOf(prev));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"prev\"");
	        }
	        if (sb.length() > 0) headers.add("Link", sb.toString());

	        querymodel.setPage(String.valueOf(page));
		}

		List<DeviceModel> result = deviceService.findAll(querymodel);

        return new ResponseEntity<List<DeviceModel>>(result, headers, HttpStatus.OK);
	}

	@ApiOperation(value = Consts.MSG_GET_DEVICE_ID, notes = Consts.MSG_GET_DEVICE_ID_01, nickname = Consts.OPERATIONID_DEVICE_SHOW)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = DeviceModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE_ID, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public DeviceModel show(Locale locale, @PathVariable("id") String idStr
			,@RequestParam(name = Consts.REQUEST_URL_FIELDS_KEY, required = false) String fields) throws Exception {
		logger.info("GetByID開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, null, fields, lstError);

		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			 String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
		}

		// 入力エラーがある場合、
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		DeviceModel result = deviceService.findOne(id, fields);
		return result;
	}

	@ApiOperation(value = Consts.MSG_POST_DEVICE, notes = Consts.MSG_POST_DEVICE_01, nickname = Consts.OPERATIONID_DEVICE_CREATE)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Created", response = DeviceModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 409, message = Consts.HTTP_MESSAGE_409),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<DeviceModel> create(Locale locale, @Valid @RequestBody DeviceModel model, Errors errors) throws Exception {
		logger.info("POST開始");
		//入力チェック
		 if (errors.hasErrors()) {
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 List<SubResponseModel> lstError = new ArrayList<>();
			 for(FieldError err :  errors.getFieldErrors()) {
				 lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			 }
			 exp.setArgs(lstError);
			 throw exp;
		 }

		 //機種NOと親機種NOが同一がどうか
		 List<SubResponseModel> errorsEqual = this.isDeviceEqualToParent(locale, model);
		 if (!errorsEqual.isEmpty()){
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 exp.setArgs(errorsEqual);
			 throw exp;
		 }

		 //指定した親デバイスが存在するかどうか
		 List<SubResponseModel> errorsRef = isDeviceParentExist(locale, model);
		 if (!errorsRef.isEmpty()){
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 exp.setArgs(errorsRef);
			 throw exp;
		 }

		 return new ResponseEntity<DeviceModel>(deviceService.save(model), HttpStatus.CREATED);
	}

	@ApiOperation(value = Consts.MSG_PUT_DEVICE, notes = Consts.MSG_PUT_DEVICE_01, nickname = Consts.OPERATIONID_DEVICE_PUT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = DeviceModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 409, message = Consts.HTTP_MESSAGE_409),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE_ID, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
    public DeviceModel  put(Locale locale, @PathVariable(value = "id") String idStr, @Valid @RequestBody DeviceModel model, Errors errors) throws Exception {
		logger.info("PUT開始");
		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			List<SubResponseModel> lstError = new ArrayList<>();
			String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
			exp.setArgs(lstError);
			throw exp;
		}

		//入力チェック
		 if (errors.hasErrors()) {
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 List<SubResponseModel> lstError = new ArrayList<>();
			 for(FieldError err :  errors.getFieldErrors()) {
				 lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			 }
			 exp.setArgs(lstError);
			 throw exp;
		 }

		 //機種NOと親機種NOが同一がどうか
		 List<SubResponseModel> errorsList= this.isDeviceEqualToParent(locale, model);
		 if (!errorsList.isEmpty()){
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 exp.setArgs(errorsList);
			 throw exp;
		 }

		 //指定した親デバイスが存在するかどうか
		 errorsList = isDeviceParentExist(locale, model);
		 if (!errorsList.isEmpty()){
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 exp.setArgs(errorsList);
			 throw exp;
		 }

		 //循環参照チェックを追加
		 errorsList = isCirculationReference(locale, model);
		 if (!errorsList.isEmpty()){
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 exp.setArgs(errorsList);
			 throw exp;
		 };

		 return deviceService.update(locale, id, model);
    }

	@ApiOperation(value = Consts.MSG_DELETE_DEVICE, notes = Consts.MSG_DELETE_DEVICE_01, nickname = Consts.OPERATIONID_DEVICE_DELETE)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE_ID, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
    public ResponseEntity<Object> delete(Locale locale
					    , @PathVariable(value = "id") String idStr)
					    		throws Exception {
		logger.info("delete開始");
		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			List<SubResponseModel> lstError = new ArrayList<>();
			 String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
			 exp.setArgs(lstError);
			throw exp;
		}

		// デバイス情報削除処理を行う
		deviceService.delete(id);
		// 正常
		ResponseModel returnInfoModel =
				new ResponseModel(HttpStatus.OK.value()
								, HttpStatus.OK.getReasonPhrase()
								, "");
		return new ResponseEntity<Object>(returnInfoModel, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @param locale   ロケール
	 * @param queryModel    検索条件
	 * @param fields   フィールド
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, DeviceQueryModel queryModel, String fields, List<SubResponseModel> lstError) {

		String sorts = queryModel == null?null:queryModel.getSort();
		String page = queryModel == null?null:queryModel.getPage();
		String limit = queryModel == null?null:queryModel.getLimit();

		try{
			if (page != null && Integer.parseInt(page) < 1){
				lstError.add(new SubResponseModel("page",
						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page",
					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limit指定あり不正の場合
		try{
			if (limit != null && Integer.parseInt(limit) < 1){
				lstError.add(new SubResponseModel("limit",
						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit",
					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if(sorts != null){
			List<String> sortParams = new ArrayList<String>();
			for (String item : sorts.split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(sortParams) || !StringUtil.hasProperty(new DeviceModel(), sortParams)){
	        	lstError.add(new SubResponseModel("sort",
	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		// フィールドの指定が不正な場合
		if(fields != null){
			List<String> fieldParams = new ArrayList<String>();
			for (String item : fields.split(",")) {
				fieldParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(fieldParams) || !StringUtil.hasProperty(new DeviceModel(), fieldParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}
		return lstError;
	}

	/**
	 * 親デバイスが存在するかどうかチェック
	 * @param locale   ロケール
	 * @param model     モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> isDeviceParentExist(Locale locale, DeviceModel model)throws Exception {
		DeviceQueryModel querymodel = new DeviceQueryModel();

		List<SubResponseModel> lstError = new ArrayList<>();

		if (model.getParent_model_id()==null &&	model.getParent_serial_no() == null ) return lstError;

		querymodel.setModel_id(new String[]{model.getParent_model_id()});
		querymodel.setSerial_no(new String[]{model.getParent_serial_no()});


		List<DeviceModel> result = deviceService.findAll(querymodel);
		// 検索結果が０件の場合不正
		if(result.size()== 0){
					String[] params = new String[]{"parent_model_id", "parent_serial_no"};
			    	lstError.add(new SubResponseModel("parent_model_id",
	        			messageSource.getMessage(Consts.MESSAGE_E000126, params, locale)));
		}

		return lstError;
	}

	/**
	 * 親機種IDと機種IDが同一かどうか
	 * @param locale   ロケール
	 * @param model     モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> isDeviceEqualToParent(Locale locale, DeviceModel model)throws Exception {

		List<SubResponseModel> lstError = new ArrayList<>();
		if((model.getParent_model_id()!=null && model.getSerial_no()!= null &&
				model.getParent_model_id().compareToIgnoreCase(model.getModel_id()) == 0 &&
				model.getParent_serial_no().compareToIgnoreCase(model.getSerial_no()) == 0)){
			String[] params = {"parent_model_id","parent_serial_no","model_id","serial_no"};
			lstError.add(new SubResponseModel("parent_model_id",
        			messageSource.getMessage(Consts.MESSAGE_E000124, params, locale)));
		}
		return lstError;

	}

	/**
	 * 循環参照しているかどうか
	 * @param locale   ロケール
	 * @param model     モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> isCirculationReference(Locale locale, DeviceModel model)throws Exception {

		List<SubResponseModel> lstError = new ArrayList<>();

		if(model.getParent_model_id()== null && model.getSerial_no()== null) return lstError;

		if(deviceRepositoryCustom.isCirculationReference(model)){
			String[] params = {"parent_model_id","parent_serial_no"};
			lstError.add(new SubResponseModel("parent_model_id",
        			messageSource.getMessage(Consts.MESSAGE_E000125, params, locale)));
		}
		return lstError;

	}


}

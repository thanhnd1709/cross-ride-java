package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.exception.BadRequestException;
import com.app.model.StatusManagementModel;
import com.app.model.StatusManagementQueryModel;
import com.app.model.SubResponseModel;
import com.app.service.StatusManagementService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_ALARM_EVENT_MGT)
@Api(tags ={Consts.TAGS_ALARM_EVENT_MGT}, description = Consts.MSG_PUT_STATUS)
public class StatusManagementAPIController {

	public static final Logger logger = LoggerFactory.getLogger(StatusManagementAPIController.class);

	@Autowired
	private StatusManagementService updateEventStatusService;
	@Autowired
	private MessageSource messageSource;

	@ApiOperation(value = Consts.MSG_PUT_STATUS, notes = Consts.MSG_PUT_STATUS_01, nickname = Consts.OPERATIONID_STATUS_MANAGEMENT_PUT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = StatusManagementModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 409, message = Consts.HTTP_MESSAGE_409),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_STATUS_MGT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PATCH)
    public StatusManagementModel  put(Locale locale, @PathVariable(value = "id") String idStr, @Valid @RequestBody StatusManagementQueryModel model, Errors errors) throws Exception {
		logger.info("PATCH開始");
		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			List<SubResponseModel> lstError = new ArrayList<>();
			String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
			exp.setArgs(lstError);
			throw exp;
		}

		//入力チェック
		 if (errors.hasErrors()) {
			 BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			 List<SubResponseModel> lstError = new ArrayList<>();
			 for(FieldError err :  errors.getFieldErrors()) {
				 lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			 }
			 exp.setArgs(lstError);
			 throw exp;
		 }

		 return updateEventStatusService.update(locale, id, model);
    }

//	/**
//	 * 入力チェック処理
//	 * @param locale   ロケール
//	 * @param queryModel    検索条件
//	 * @param fields   フィールド
//	 * @return List<SubResponseModel> エラーリスト
//	 */
//	private List<SubResponseModel> Validation(Locale locale, UpdateEventStatusQueryModel queryModel, String fields, List<SubResponseModel> lstError) {
//
//		String sorts = queryModel == null?null:queryModel.getSort();
//		String page = queryModel == null?null:queryModel.getPage();
//		String limit = queryModel == null?null:queryModel.getLimit();
//
//		try{
//			if (page != null && Integer.parseInt(page) < 1){
//				lstError.add(new SubResponseModel("page",
//						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
//			}
//		}catch (NumberFormatException e) {
//			lstError.add(new SubResponseModel("page",
//					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
//		}
//
//		//limit指定あり不正の場合
//		try{
//			if (limit != null && Integer.parseInt(limit) < 1){
//				lstError.add(new SubResponseModel("limit",
//						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
//			}
//		}catch (NumberFormatException e) {
//			lstError.add(new SubResponseModel("limit",
//					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
//		}
//
//		// ソートの指定が不正な場合
//		if(sorts != null){
//			List<String> sortParams = new ArrayList<String>();
//			for (String item : sorts.split(",")) {
//				sortParams.add(item.toLowerCase().replace("-", ""));
//			}
//
//	        if(StringUtil.hasDuplicate(sortParams) || !StringUtil.hasProperty(new UpdateEventStatusModel(), sortParams)){
//	        	lstError.add(new SubResponseModel("sort",
//	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
//	        }
//		}
//
//		// フィールドの指定が不正な場合
//		if(fields != null){
//			List<String> fieldParams = new ArrayList<String>();
//			for (String item : fields.split(",")) {
//				fieldParams.add(item.toLowerCase().replace("-", ""));
//			}
//
//	        if(StringUtil.hasDuplicate(fieldParams) || !StringUtil.hasProperty(new UpdateEventStatusModel(), fieldParams)){
//	        	lstError.add(new SubResponseModel("fields",
//	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
//	        }
//		}
//		return lstError;
//	}
}

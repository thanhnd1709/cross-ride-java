package com.app.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.RequestOpeInstructModel;
import com.app.model.ResponseOpeInstructModel;
import com.app.model.SubResponseModel;
import com.app.service.GatewayCommandService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.sdk.iot.service.exceptions.IotHubException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * GWへのコマンド実行依頼APIコントローラクラス
 * @author（TOSCO）
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DEVICE)
@Api(tags ={Consts.TAGS_DEVICE_OPERATIONS,}, description = Consts.MSG_DEVICE_OPERATIONS)
public class OpeInstructAPIController {

	public static final Logger logger = LoggerFactory.getLogger(OpeInstructAPIController.class);

	@Autowired
	private GatewayCommandService gatewayCommandService;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private AuthUserInfoComponent authUserInfo;

	/**
	 * GWへのコマンド実行依頼
	 */
	@ApiOperation(value = Consts.MSG_POST_OPEINSTRUCT, notes = Consts.MSG_POST_OPEINSTRUCT_01, nickname = Consts.OPERATIONID_OPE_INSTRUCTIONS_POST)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseOpeInstructModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@ResponseStatus(HttpStatus.OK)
	@RequestMapping(value = Consts.REQUEST_URL_OPE_INSTRUCTIONS, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public ResponseEntity<ResponseOpeInstructModel> post(Locale locale,
    		@RequestBody @Valid RequestOpeInstructModel reqModel,
    		BindingResult errors,
    		@RequestHeader(name = "RemoteAddr", required = false) String remoteAddr,
    		@RequestHeader(name = "x-forwarded-for", required = false) String clientAddr,
    		@RequestHeader(name = "referer", required = false) String referer,
    		@RequestHeader(name = "origin", required = false) String origin,
    		@RequestHeader(name = "user-agent", required = false) String userAgent
    		) throws Exception {

		logger.info("GWへのコマンド実行依頼API 開始 request：" + reqModel + ", RemoteAddr=" + remoteAddr + ", x-forwarded-for=" +
		clientAddr + ", referer=" + referer + ", origin=" + origin + ", user-agent=" + userAgent);
		ResponseOpeInstructModel resModel;

		reqModel.setRemote_addr(remoteAddr);
		reqModel.setClient_addr(clientAddr);
		reqModel.setHttp_referer(referer);
		reqModel.setCors_origin(origin);
		reqModel.setRequest_user_id(authUserInfo.getPrincipalName());

		//入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		if (errors.hasErrors()) {
			for(FieldError err :  errors.getFieldErrors()) {
				lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			}
		}
		lstError = Validation(locale, reqModel, lstError);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}

		// GWデバイス、デバイス権限チェック
		lstError = gatewayCommandService.checkDeviceAuthority(locale, reqModel, lstError);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}

		// GWコマンド実行前スクリプト実行
		gatewayCommandService.beforeRequestCommand(reqModel);

		// GWコマンド実行履歴登録
		Integer id = gatewayCommandService.addGwCommandHistory(reqModel);

		try{
			// GWコマンド実行
			 resModel = gatewayCommandService.requestCommand(reqModel, id);

		}catch (IotHubException ioHub) {
			// GWコマンド実行履歴更新
			try {
				ResponseOpeInstructModel res = new ResponseOpeInstructModel();
				res.setResult_code("408");
				res.setResult_message(ioHub.getMessage());
				gatewayCommandService.updateGwCommandHistory(res, id);
			} catch (DataIntegrityViolationException e) {
				throw new Exception(messageSource.getMessage(Consts.MESSAGE_E000115, null, locale), e);
			}
			throw ioHub;
		}catch (IOException io) {
			// GWコマンド実行履歴更新
			try {
				ResponseOpeInstructModel res = new ResponseOpeInstructModel();
				res.setResult_code("500");
				res.setResult_message(io.getMessage());
				gatewayCommandService.updateGwCommandHistory(res, id);
			} catch (DataIntegrityViolationException e) {
				throw new Exception(messageSource.getMessage(Consts.MESSAGE_E000115, null, locale), e);
			}
			throw io;
		}

		// GWコマンド実行後スクリプト実行
		gatewayCommandService.afterRequestCommand(reqModel);

		// GWコマンド実行履歴更新
		try {
			gatewayCommandService.updateGwCommandHistory(resModel, id);
		} catch (DataIntegrityViolationException e) {
			throw new Exception(messageSource.getMessage(Consts.MESSAGE_E000115, null, locale), e);
		}

		logger.info("GWへのコマンド実行依頼API 正常終了");
		HttpStatus status = HttpStatus.valueOf(Integer.parseInt(resModel.getResult_code()));
		return new ResponseEntity<ResponseOpeInstructModel>(resModel, status);
	}

	/**
	 * 入力チェック処理
	 * @param locale ロケール
	 * @param req 検索モデル
	 * @param lstError エラーリスト
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, RequestOpeInstructModel req, List<SubResponseModel> lstError) {


		// 引数
		if (req.getArgument() instanceof Map) {
			ObjectMapper mapper = new ObjectMapper();
			try {
				String argment = mapper.writeValueAsString(req.getArgument());
				req.setArgumentString(argment);
			} catch (Exception e) {
	        	lstError.add(new SubResponseModel("argument",
	        			messageSource.getMessage(Consts.MESSAGE_E000051, null, locale)));
			}
		}

		// 実行時刻
		SimpleDateFormat formatter = null;
		String execTime = req.getExec_time();
		if (!StringUtil.IsNullOrEmpty(execTime)) {
			if(execTime.length() == "yyyyMMddHHmmss".length()) {
				formatter = new SimpleDateFormat("yyyyMMddHHmmss");
			} else if (execTime.length() == "HHmmss".length()) {
				formatter = new SimpleDateFormat("HHmmss");
			}

			if (formatter == null) {
				lstError.add(new SubResponseModel("exec_time"
						, messageSource.getMessage(Consts.MESSAGE_E000015, null, locale)));
			} else {
				try {
					formatter.setLenient(false);
					formatter.parse(execTime);
				} catch (ParseException e) {
					lstError.add(new SubResponseModel("exec_time"
							, messageSource.getMessage(Consts.MESSAGE_E000015, null, locale)));
				}
			}
		}

		return lstError;
	}

}

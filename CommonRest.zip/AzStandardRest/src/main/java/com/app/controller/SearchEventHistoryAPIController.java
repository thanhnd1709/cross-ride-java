package com.app.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.DeviceListModel;
import com.app.model.EventHistoryListModel;
import com.app.model.EventHistoryModel;
import com.app.model.EventListModel2;
import com.app.model.ResponseEventHistoryModel;
import com.app.model.SubResponseModel;
import com.app.service.EventHistoryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * イベント・アラーム履歴検索コントローラクラス
 * @author（TOSCO）小川
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_ALARM_EVENT_MGT)
@Api(tags = { Consts.TAGS_ALARM_EVENT_MGT, }, description = Consts.MSG_ALARM_EVENT_MGT)
public class SearchEventHistoryAPIController {

	public static final Logger logger = LoggerFactory.getLogger(SearchEventHistoryAPIController.class);

	@Autowired
	private EventHistoryService eventHistoryService;
	@Autowired
	private MessageSource _msgSource;

	@ApiOperation(value = Consts.MSG_SEARCH_EVENT_HISTORY, notes = Consts.MSG_SEARCH_EVENT_HISTORY_01, nickname = Consts.OPERATIONID_SEARCH_EVENT_HISTORY_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseEventHistoryModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_EVENT_HISTORY, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<ResponseEventHistoryModel> index(Locale locale, EventHistoryModel reqModel, BindingResult result1)
																								throws Exception {
		logger.info("【イベント・アラーム履歴検索】Request：" + reqModel);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		ResponseEventHistoryModel result = eventHistoryService.SearchEventHistory(reqModel);
		return new ResponseEntity<ResponseEventHistoryModel>(result, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @param locale ロケール
	 * @param reqModel イベント・アラーム履歴検索モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, EventHistoryModel req, List<SubResponseModel> lstError) {

		// リクエスト．検出区分が null、又は 空白（""）の場合
		if (req.getGet_class() == null || req.getGet_class().length == 0) {
			lstError.add(new SubResponseModel("get_class"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		} else {
			// リクエスト．検出区分が 1/2/3/4/5 以外の場合
			for (String getClass : req.getGet_class()) {
				if (StringUtil.IsValidNum(getClass)) {
					lstError.add(new SubResponseModel("get_class",
									_msgSource.getMessage(Consts.MESSAGE_E000046, null, locale)));
				}
			}
		}

		// リクエスト．発生復帰区分 が 入力されている場合、かつ 1/2/3 以外の場合
		if (!StringUtil.IsNullOrEmpty(req.getIncident_class()) && !StringUtil.IsBlank(req.getIncident_class())) {
			if (!StringUtil.IsChar2(req.getIncident_class())) {
				lstError.add(new SubResponseModel("incident_class",
								_msgSource.getMessage(Consts.MESSAGE_E000045, null, locale)));
			}
		}

		Date mTimeTo = null;
		Date mTimeFrom = null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.");
		formatter.setLenient(false);

		// 対象期間(From)が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(req.getEvent_time_from()) || StringUtil.IsBlank(req.getEvent_time_from())){
			lstError.add(new SubResponseModel("event_time_from"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			if(!StringUtil.chkLength(req.getEvent_time_from(), 27)){
				lstError.add(new SubResponseModel("event_time_from"
						, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));

			}else{
				try{
					Timestamp tsFrom = new Timestamp(formatter.parse(req.getEvent_time_from().substring(0, 20)).getTime());
					tsFrom.setNanos(Integer.parseInt(req.getEvent_time_from().substring(20, 27)) * 100);
					mTimeFrom = new Date(tsFrom.getTime());

					// 対象期間(From)が現在日時より未来の場合
					/*if(date.compareTo(mTimeFrom) < 0){
						lstError.add(new SubResponseModel("event_time_from"
								, _msgSource.getMessage(Consts.MESSAGE_E000014
										, new String[]{_msgSource.getMessage(Consts.MESSAGE_SYSTEM_DATETIME, null, locale)
												,_msgSource.getMessage(Consts.MESSAGE_EVENT_TIME_FROM, null, locale)}
								, locale)));
					}*/
				} catch (Exception e) {
					// 対象期間(From)のフォーマットが不正、又は 不正な日付の場合
					lstError.add(new SubResponseModel("event_time_from"
							, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
				}
			}
		}

		if(!StringUtil.IsNullOrEmpty(req.getEvent_time_to()) && !StringUtil.IsBlank(req.getEvent_time_to())){

			if(!StringUtil.chkLength(req.getEvent_time_to(), 27)){
				lstError.add(new SubResponseModel("event_time_to"
						,_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));

			}else{
				try{
					Timestamp tsTo = new Timestamp(formatter.parse(req.getEvent_time_to().substring(0, 20)).getTime());
					tsTo.setNanos(Integer.parseInt(req.getEvent_time_to().substring(20, 27)) * 100);
					mTimeTo = new Date(tsTo.getTime());

					// 対象期間(To)が現在日時より未来の場合
					/*if(mTimeTo.compareTo(date) > 0){
						lstError.add(new SubResponseModel("event_time_to"
								, _msgSource.getMessage(Consts.MESSAGE_E000014
										, new String[]{_msgSource.getMessage(Consts.MESSAGE_SYSTEM_DATETIME, null, locale)
												,_msgSource.getMessage(Consts.MESSAGE_EVENT_TIME_TO, null, locale)}
								, locale)));

					}else{*/
						// 対象期間(From)が対象期間(To)より未来の場合
						if(mTimeFrom != null && mTimeTo.compareTo(mTimeFrom) < 0){
							lstError.add(new SubResponseModel("event_time_from, event_time_to"
									, _msgSource.getMessage(Consts.MESSAGE_E000014
											, new String[]{_msgSource.getMessage(Consts.MESSAGE_EVENT_TIME_TO, null, locale)
													, _msgSource.getMessage(Consts.MESSAGE_EVENT_TIME_FROM, null, locale)}
									, locale)));
						}
					//}
				} catch (Exception e) {
					// 対象期間(To)のフォーマットが不正、又は 不正な日付の場合
					lstError.add(new SubResponseModel("event_time_to"
							,_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
				}
			}
		}

		// デバイスグループID 指定時、 [配列]デバイスリスト、 [配列]イベントリスト は指定不可
  		// [配列]デバイスリスト指定時、デバイスグループID 、 [配列]イベントリスト は指定不可
       	// [配列]イベントリスト指定時、 [配列]デバイスリスト、デバイスグループID は指定不可
		int cnt = 0;
		int idx;
		if (!StringUtil.IsNullOrEmpty(req.getDevice_group_id()) && !StringUtil.IsBlank(req.getDevice_group_id())){
			cnt++;
		}
		if (req.getDevice_list() != null && req.getDevice_list().size() > 0) {
			cnt++;

			idx = 0;
			for(DeviceListModel devModel : req.getDevice_list()){
				if(StringUtil.IsNullOrEmpty(devModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]device_list.model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

				}else if(StringUtil.IsNullOrEmpty(devModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]device_list.serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}
				idx += 1;
			}
		}
		if (req.getEvent_list() != null && req.getEvent_list().size() > 0) {
			cnt++;

			idx = 0;
			for(EventListModel2 eventModel : req.getEvent_list()){
				if(StringUtil.IsNullOrEmpty(eventModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]event_list.model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

				}else if(StringUtil.IsNullOrEmpty(eventModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]event_list.serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

				}else if(StringUtil.IsNullOrEmpty(eventModel.getEvent_id())){
					lstError.add(new SubResponseModel("[" + idx + "]event_list.event_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}
				idx += 1;
			}
		}
		if(cnt > 1){
			lstError.add(new SubResponseModel("device_group_id, device_list, event_list",
					_msgSource.getMessage(Consts.MESSAGE_E000034, null, locale)));
		}
		try{
			if (req.getPage() != null && Integer.parseInt(req.getPage()) < 1){
				lstError.add(new SubResponseModel("page",
						_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page",
					_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limit指定あり不正の場合
		try{
			if (req.getLimit() != null && Integer.parseInt(req.getLimit()) < 1){
				lstError.add(new SubResponseModel("limit",
						_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit",
					_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if(req.getSort() != null){
			List<String> sortParams = new ArrayList<String>();
			for (String item : req.getSort().split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(sortParams)
	        		|| !StringUtil.hasProperty(new EventHistoryListModel(), sortParams)){
	        	lstError.add(new SubResponseModel("sort",
	        			_msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		// フィールドの指定が不正な場合
		if(req.getFields() != null){
			List<String> fieldParams = new ArrayList<String>();
			for (String item : req.getFields().split(",")) {
				fieldParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(fieldParams)
	        		|| !StringUtil.hasProperty(new EventHistoryListModel(), fieldParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			_msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		return lstError;
	}
}

package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.PostFileModel;
import com.app.model.ResponseFileModel2;
import com.app.model.SubResponseModel;
import com.app.service.PostFileService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * ファイル登録コントローラクラス
 * @author（TOSCO）
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags ={Consts.TAGS_SENSOR_DATA_FILE_MGT,}, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class PostFileAPIController {

	@Autowired private PostFileService _service;
	@Autowired private MessageSource _msgSource;
	@Autowired
	private AuthUserInfoComponent authUserInfoComponent;

	public static final Logger logger = LoggerFactory.getLogger(PostFileAPIController.class);

	/**
	 * ファイル登録処理
	 */
	@ApiOperation(value = Consts.MSG_POST_FILE, notes = Consts.MSG_POST_FILE_01, nickname = Consts.OPERATIONID_POST_FILE_CREATE)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Created", response = ResponseFileModel2.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@ResponseStatus(HttpStatus.CREATED)
	@RequestMapping(value = Consts.REQUEST_URL_FILE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public ResponseEntity<ResponseFileModel2> PostFile(Locale locale,@RequestBody PostFileModel reqModel) throws Exception {

		logger.info("request：" + reqModel);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// 認証されたユーザIDを設定
		String userId = authUserInfoComponent.getPrincipalName();
		reqModel.setUser_id(userId);

		// ファイル登録処理
		String result = _service.postFile(reqModel,locale);
		return new ResponseEntity<ResponseFileModel2>(new ResponseFileModel2(result), HttpStatus.CREATED);
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, PostFileModel reqModel, List<SubResponseModel> lstError){

		// リクエスト．コンテナ名が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getContainer()) || StringUtil.IsBlank(reqModel.getContainer())){
			lstError.add(new SubResponseModel("container"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			//展開用ファイル用コンテナ(expansion)、受信ファイル用コンテナ(receivefile) の場合
			if(reqModel.getContainer().equals(Consts.BLOB_EXPANSION) || reqModel.getContainer().equals(Consts.BLOB_RECEIVEFILE)){
				lstError.add(new SubResponseModel("container"
						, _msgSource.getMessage(Consts.MESSAGE_E000054, new String[]{reqModel.getContainer()}, locale)));
				}
		}

		// リクエスト．圧縮有無フラグが null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getZip_flg()) || StringUtil.IsBlank(reqModel.getZip_flg())){
			lstError.add(new SubResponseModel("zip_flg"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// リクエスト．ファイルデータが null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getFile_data()) || StringUtil.IsBlank(reqModel.getFile_data())){
			lstError.add(new SubResponseModel("file_data"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}


		return lstError;
	}
}

package com.app.controller;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.DateTimeUtil;
import com.app.common.utils.StringUtil;
import com.app.entity.PostExpansionFileEntity;
import com.app.exception.BadRequestException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.PostExpansionFileQueryModel;
import com.app.model.ResponseFileModel2;
import com.app.model.SubResponseModel;
import com.app.service.PostExpansionFileService;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.codec.binary.Base64;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * 展開用ファイル登録コントローラクラス @author（TOSCO）
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags = { Consts.TAGS_SENSOR_DATA_FILE_MGT, }, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class PostExpansionFileAPIController {

	@Autowired
	private PostExpansionFileService _service;
	@Autowired
	private MessageSource _msgSource;
	@Autowired
	private AuthUserInfoComponent authUserInfoComponent;

	public static final Logger logger = LoggerFactory.getLogger(PostExpansionFileAPIController.class);

	private enum fields {
		body,
		modelId,
		serialNo,
		timeList,
		measureTime,
		dataList,
		sensorId,
		data,
		measureStartTime,
		measureInterval
	 };

	/**
	 * ファイル登録処理
	 */
	@ApiOperation(value = Consts.MSG_POST_EXPANSION_FILE, notes = Consts.MSG_POST_EXPANSION_FILE_01, nickname = Consts.OPERATIONID_POST_EXPANSION_FILE_CREATE)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Created", response = ResponseFileModel2.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500) })
	@ResponseStatus(HttpStatus.CREATED)
	@RequestMapping(value = Consts.REQUEST_URL_EXPANSION_FILE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<ResponseFileModel2> PostExpansionFile(Locale locale,
			@RequestBody PostExpansionFileQueryModel reqModel) throws Exception {

		logger.info("request：" + reqModel);

		// 認証されたユーザIDを設定
		String userId = authUserInfoComponent.getPrincipalName();
		reqModel.setUser_id(userId);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError, userId);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// ファイル登録処理
		String result = _service.postExpansionFile(reqModel, locale);
		return new ResponseEntity<ResponseFileModel2>(new ResponseFileModel2(result), HttpStatus.CREATED);
	}

	/**
	 * 入力チェック処理
	 *
	 * @return List<SubResponseModel> エラーリスト
	 * @throws Exception
	 */
	private List<SubResponseModel> Validation(Locale locale, PostExpansionFileQueryModel reqModel,
			List<SubResponseModel> lstError, String userId) throws Exception {

		// リクエスト．圧縮有無フラグが null、又は 空白（""）の場合
		if (StringUtil.IsNullOrEmpty(reqModel.getZip_flg()) || StringUtil.IsBlank(reqModel.getZip_flg())) {
			lstError.add(new SubResponseModel("zip_flg", _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// リクエスト．メッセージ区分が null、又は 空白（""）の場合
		if (StringUtil.IsNullOrEmpty(reqModel.getMessage_class()) || StringUtil.IsBlank(reqModel.getMessage_class())) {
			lstError.add(
					new SubResponseModel("message_class", _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

			// Data Send1,Data Send2,Data Send3 のいずれでもない場合
		} else if (!reqModel.getMessage_class().equals("Data Send1")
				&& !reqModel.getMessage_class().equals("Data Send2")
				&& !reqModel.getMessage_class().equals("Data Send3")) {
			lstError.add(
					new SubResponseModel("message_class", _msgSource.getMessage(Consts.MESSAGE_E000055, null, locale)));
		}

		// リクエスト．ファイルデータが null、又は 空白（""）の場合
		if (StringUtil.IsNullOrEmpty(reqModel.getFile_data()) || StringUtil.IsBlank(reqModel.getFile_data())) {
			lstError.add(
					new SubResponseModel("file_data", _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		} else {
			if (lstError.isEmpty()) {
				List<String> list = jsonParse(reqModel, locale);
				List<PostExpansionFileEntity> authChk = _service.sensorAuthChk(list, userId);
				if (!authChk.isEmpty()) {
					for (PostExpansionFileEntity s : authChk) {
						lstError.add(new SubResponseModel("model_id, serial_no, sensor_id",
								_msgSource.getMessage(Consts.MESSAGE_E000119,
										new String[] { s.getModel_id(), s.getSerial_no(), s.getSensor_id() }, locale)));
					}
				}
			}
		}
		return lstError;
	}

	/**
	 * JSONパース
	 *
	 * @param query
	 *            INパラメータ
	 * @return list(機種ID、シリアルNo、センサーID)
	 * @throws BadRequestException
	 * @throws JSONException
	 */
	public List<String> jsonParse(PostExpansionFileQueryModel query, Locale locale) throws BadRequestException {
		// base64 フラグがtrueの場合、デコード
		byte[] fileBinary = null;
		if (Boolean.valueOf(query.getBase64_flg())) {
			fileBinary = Base64.decodeBase64(query.getFile_data());
		} else {
			fileBinary = query.getFile_data().getBytes();
		}
		String fileDataStr = new String(fileBinary);

		String message_class = query.getMessage_class();

		List<String> list = new ArrayList<String>();

		if (message_class.equals("Data Send1")) {
			list = dataSend1(fileDataStr, locale);

		} else if (message_class.equals("Data Send2")) {
			list = dataSend2(fileDataStr, locale);

		} else if (message_class.equals("Data Send3")) {
			list = dataSend3(fileDataStr, locale);
		}
		return list;
	}

	/**
	 * センサー権限チェック用JSONパース(DataSend1)
	 *
	 * @param fileData
	 *            INパラメータ.ファイルデータ
	 * @return list(機種ID、シリアルNo、センサーID)
	 * @throws BadRequestException
	 * @throws JSONException
	 */
	public List<String> dataSend1(String fileData, Locale locale) throws BadRequestException {

		ArrayList<String> val = new ArrayList<String>();
		List<SubResponseModel> lstError = new ArrayList<>();

		String modelId = null;
		String serialNo = null;
		String sensorId = null;
		String measureTime = null;
		try {
			JSONObject json = new JSONObject(fileData);
			//bodyの必須チェック
			if (!json.has(fields.body.toString()) ||
					json.getJSONArray(fields.body.toString()).length() == 0){
				lstError.add(new SubResponseModel("body", _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				BadRequestException exp = new BadRequestException("");
				exp.setArgs(lstError);
				throw exp;
			}

			JSONArray keys = json.getJSONArray(fields.body.toString());

			for (int i = 0; i < keys.length(); i++) {
				JSONObject key = keys.getJSONObject(i);

				JSONArray timeListkeys = null;
				modelId = null;
				serialNo = null;

				//機種IDの必須チェック
				if (!key.has(fields.modelId.toString())) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.modelId.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					modelId = key.getString(fields.modelId.toString());
				}

				//シリアルNoの必須チェック
				if (!key.has(fields.serialNo.toString())) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.serialNo.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					serialNo = key.getString(fields.serialNo.toString());
				}
				//timeListの必須チェック
				if (!key.has(fields.timeList.toString()) ||
					key.getJSONArray(fields.timeList.toString()).length() == 0) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.timeList.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					timeListkeys = key.getJSONArray(fields.timeList.toString());
				}
				// 機種ID シリアルNo が 両方とも空白（""）の場合
				if (modelId!= null && serialNo != null){
					if(StringUtil.IsBlank(modelId) && StringUtil.IsBlank(serialNo)) {
					lstError.add(new SubResponseModel(String.format("[%d]%s, %s",i,fields.modelId.toString(),fields.serialNo.toString()), _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}

				if (timeListkeys != null){
					for (int j = 0; j < timeListkeys.length(); j++) {
						JSONObject timeListkey = timeListkeys.getJSONObject(j);

						measureTime = null;

						//measureTimeの必須チェック
						if (!timeListkey.has(fields.measureTime.toString()) ||
								StringUtil.IsBlank(timeListkey.getString(fields.measureTime.toString()))) {
							lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j ,fields.measureTime.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
						}else{
							measureTime = timeListkey.getString(fields.measureTime.toString());
							//フォーマットが不正の場合
							try{
								DateTimeUtil.toTimestamp(measureTime);
							}
							catch(Exception e){
								lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j, fields.measureTime.toString()), _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{"yyyyMMddHHmmssFFFFFFF"}, locale)));
							}
						}

						JSONArray DataListkeys = null;

						//dataListの必須チェック
						if (!timeListkey.has(fields.dataList.toString()) ||
								timeListkey.getJSONArray(fields.dataList.toString()).length() == 0) {
							lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j ,fields.dataList.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
						}else{
							 DataListkeys = timeListkey.getJSONArray(fields.dataList.toString());

							for (int k = 0; k < DataListkeys.length(); k++) {
								sensorId = null;
								JSONObject DataListkey = DataListkeys.getJSONObject(k);

								if (!DataListkey.has(fields.sensorId.toString()) ||
										StringUtil.IsBlank(DataListkey.getString(fields.sensorId.toString()))) {
									lstError.add(new SubResponseModel(String.format("[%d:%d:%d]%s",i ,j ,k ,fields.sensorId.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
								}else{
									sensorId = DataListkey.getString(fields.sensorId.toString());
								}

								if (!DataListkey.has(fields.data.toString()) ||
										StringUtil.IsBlank(DataListkey.getString(fields.data.toString()))) {
									lstError.add(new SubResponseModel(String.format("[%d:%d:%d]%s",i ,j ,k ,fields.data.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
								}

								if (modelId!= null && serialNo!= null && sensorId !=null){
									val.add(modelId + "$" + serialNo + "$" + sensorId);
								}
							}
						}
					}
				}
			}
			if (!lstError.isEmpty()) {
				BadRequestException exp = new BadRequestException("");
				exp.setArgs(lstError);
				throw exp;
			}
		} catch (JSONException e) {
			// 入力チェック
			lstError.add(
					new SubResponseModel("file_data", _msgSource.getMessage(Consts.MESSAGE_E000051, null, locale)));
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		List<String> val2 = new ArrayList<String>(new LinkedHashSet<>(val));
		return val2;
	}



	/**
	 * センサー権限チェック用JSONパース(DataSend2)
	 *
	 * @param fileData
	 *            INパラメータ.ファイルデータ
	 * @return list(機種ID、シリアルNo、センサーID)
	 * @throws BadRequestException
	 * @throws JSONException
	 */
	public List<String> dataSend2(String fileData, Locale locale) throws BadRequestException {

		ArrayList<String> val = new ArrayList<String>();
		List<SubResponseModel> lstError = new ArrayList<>();

		String modelId = null;
		String serialNo = null;
		String sensorId = null;
		String measureTime = null;
		try {
			JSONObject json = new JSONObject(fileData);
			//bodyの必須チェック
			if (!json.has(fields.body.toString()) ||
					json.getJSONArray(fields.body.toString()).length() == 0){
				lstError.add(new SubResponseModel("body", _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				BadRequestException exp = new BadRequestException("");
				exp.setArgs(lstError);
				throw exp;
			}

			JSONArray keys = json.getJSONArray(fields.body.toString());

			for (int i = 0; i < keys.length(); i++) {
				JSONObject key = keys.getJSONObject(i);

				JSONArray timeListkeys = null;
				modelId = null;
				serialNo = null;

				//機種IDの必須チェック
				if (!key.has(fields.modelId.toString())) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.modelId.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					modelId = key.getString(fields.modelId.toString());
				}

				//シリアルNoの必須チェック
				if (!key.has(fields.serialNo.toString())) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.serialNo.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					serialNo = key.getString(fields.serialNo.toString());
				}
				//timeListの必須チェック
				if (!key.has(fields.timeList.toString()) ||
						key.getJSONArray(fields.timeList.toString()).length() == 0) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.timeList.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					timeListkeys = key.getJSONArray(fields.timeList.toString());
				}
				// 機種ID シリアルNo が 両方とも空白（""）の場合
				if (modelId!= null && serialNo != null){
					if(StringUtil.IsBlank(modelId) && StringUtil.IsBlank(serialNo)) {
					lstError.add(new SubResponseModel(String.format("[%d]%s, %s",i,fields.modelId.toString(),fields.serialNo.toString()), _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}

				if (timeListkeys != null){
					for (int j = 0; j < timeListkeys.length(); j++) {
						JSONObject timeListkey = timeListkeys.getJSONObject(j);
						sensorId = null;
						JSONArray DataListkeys = null;

						//センサーIDの必須チェック
						if (!timeListkey.has(fields.sensorId.toString()) ||
								StringUtil.IsBlank(timeListkey.getString(fields.sensorId.toString()))) {
							lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j ,fields.sensorId.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
						}else{
							sensorId = timeListkey.getString(fields.sensorId.toString());
						}

						if (modelId!= null && serialNo!= null && sensorId !=null){
							val.add(modelId + "$" + serialNo + "$" + sensorId);
						}
						//dataListの必須チェック
						if (!timeListkey.has(fields.dataList.toString()) ||
								timeListkey.getJSONArray(fields.dataList.toString()).length() == 0) {
							lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j ,fields.dataList.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
						}else{
							 DataListkeys = timeListkey.getJSONArray(fields.dataList.toString());
							 //DataList配列分でLOOP
							for (int k = 0; k < DataListkeys.length(); k++) {
								JSONObject DataListkey = DataListkeys.getJSONObject(k);

								measureTime = null;

								//measureTimeの必須チェック
								if (!DataListkey.has(fields.measureTime.toString()) ||
										StringUtil.IsBlank(DataListkey.getString(fields.measureTime.toString()))) {
									lstError.add(new SubResponseModel(String.format("[%d:%d:%d]%s",i ,j ,k,fields.measureTime.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
								}else{
									measureTime = DataListkey.getString(fields.measureTime.toString());
									//フォーマットが不正の場合
									try{
										DateTimeUtil.toTimestamp(measureTime);
									}
									catch(Exception e){
										lstError.add(new SubResponseModel(String.format("[%d:%d:%d]%s",i ,j ,k, fields.measureTime.toString()), _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{"yyyyMMddHHmmssFFFFFFF"}, locale)));
									}
								}
								//dataの必須チェック
								if (!DataListkey.has(fields.data.toString()) ||
										StringUtil.IsBlank(DataListkey.getString(fields.data.toString()))) {
									lstError.add(new SubResponseModel(String.format("[%d:%d:%d]%s",i ,j ,k ,fields.data.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
								}else{
									sensorId = DataListkey.getString(fields.data.toString());
								}
							}
						}
					}
				}
			}
			if (!lstError.isEmpty()) {
				BadRequestException exp = new BadRequestException("");
				exp.setArgs(lstError);
				throw exp;
			}
		} catch (JSONException e) {
			// 入力チェック
			lstError.add(
					new SubResponseModel("file_data", _msgSource.getMessage(Consts.MESSAGE_E000051, null, locale)));
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}
		List<String> val2 = new ArrayList<String>(new LinkedHashSet<>(val));
		return val2;
	}

	/**
	 * センサー権限チェック用JSONパース(DataSend3)
	 *
	 * @param fileData
	 *            INパラメータ.ファイルデータ
	 * @return list(機種ID、シリアルNo、センサーID)
	 * @throws BadRequestException
	 * @throws JSONException
	 */
	public List<String> dataSend3(String fileData, Locale locale) throws BadRequestException {

		ArrayList<String> val = new ArrayList<String>();
		List<SubResponseModel> lstError = new ArrayList<>();

		String modelId = null;
		String serialNo = null;
		String sensorId = null;
		String measureStartTime = null;
		String measureInterval = null;
		try {
			JSONObject json = new JSONObject(fileData);
			//bodyの必須チェック
			if (!json.has(fields.body.toString()) ||
					json.getJSONArray(fields.body.toString()).length() == 0){
				lstError.add(new SubResponseModel("body", _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				BadRequestException exp = new BadRequestException("");
				exp.setArgs(lstError);
				throw exp;
			}

			JSONArray keys = json.getJSONArray(fields.body.toString());

			for (int i = 0; i < keys.length(); i++) {
				JSONObject key = keys.getJSONObject(i);

				JSONArray timeListkeys = null;
				modelId = null;
				serialNo = null;

				//機種IDの必須チェック
				if (!key.has(fields.modelId.toString())) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.modelId.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					modelId = key.getString(fields.modelId.toString());
				}

				//シリアルNoの必須チェック
				if (!key.has(fields.serialNo.toString())) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.serialNo.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					serialNo = key.getString(fields.serialNo.toString());
				}
				//timeListの必須チェック
				if (!key.has(fields.timeList.toString()) ||
						key.getJSONArray(fields.timeList.toString()).length() == 0) {
					lstError.add(new SubResponseModel(String.format("[%d]%s",i,fields.timeList.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}else{
					timeListkeys = key.getJSONArray(fields.timeList.toString());
				}
				// 機種ID シリアルNo が 両方とも空白（""）の場合
				if (modelId!= null && serialNo != null){
					if(StringUtil.IsBlank(modelId) && StringUtil.IsBlank(serialNo)) {
					lstError.add(new SubResponseModel(String.format("[%d]%s, %s",i,fields.modelId.toString(),fields.serialNo.toString()), _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}

				if (timeListkeys != null){
					for (int j = 0; j < timeListkeys.length(); j++) {
						JSONObject timeListkey = timeListkeys.getJSONObject(j);
						sensorId = null;

						//センサーIDの必須チェック
						if (!timeListkey.has(fields.sensorId.toString()) ||
								StringUtil.IsBlank(timeListkey.getString(fields.sensorId.toString()))) {
							lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j ,fields.sensorId.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
						}else{
							sensorId = timeListkey.getString(fields.sensorId.toString());
						}

						if (modelId!= null && serialNo!= null && sensorId !=null){
							val.add(modelId + "$" + serialNo + "$" + sensorId);
						}

						measureStartTime = null;

						//measureStartTimeの必須チェック
						if (!timeListkey.has(fields.measureStartTime.toString()) ||
								StringUtil.IsBlank(timeListkey.getString(fields.measureStartTime.toString()))) {
							lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j ,fields.measureStartTime.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
						}else{
							measureStartTime = timeListkey.getString(fields.measureStartTime.toString());
							//フォーマットが不正の場合
							try{
								DateTimeUtil.toTimestamp(measureStartTime);
							}
							catch(Exception e){
								lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j , fields.measureStartTime.toString()), _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{"yyyyMMddHHmmssFFFFFFF"}, locale)));
							}
						}

						//measureIntervalの必須チェック
						if (!timeListkey.has(fields.measureInterval.toString()) ||
								StringUtil.IsBlank(timeListkey.getString(fields.measureInterval.toString()))) {
							lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j ,fields.measureInterval.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
						}else{
							measureInterval = timeListkey.getString(fields.measureInterval.toString());
							//フォーマットが不正の場合
							try{
								Integer.parseInt(measureInterval);
							}
							catch(Exception e){
								lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j , fields.measureInterval.toString()), _msgSource.getMessage(Consts.MESSAGE_E000012, null, locale)));
							}
						}

						//dataListの必須チェック
						if (!timeListkey.has(fields.dataList.toString()) ||
								timeListkey.getJSONArray(fields.dataList.toString()).length() == 0) {
							lstError.add(new SubResponseModel(String.format("[%d:%d]%s",i ,j ,fields.dataList.toString()), _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
						}
					}
				}
			}
			if (!lstError.isEmpty()) {
				BadRequestException exp = new BadRequestException("");
				exp.setArgs(lstError);
				throw exp;
			}
		} catch (JSONException e) {
			// 入力チェック
			lstError.add(
					new SubResponseModel("file_data", _msgSource.getMessage(Consts.MESSAGE_E000051, null, locale)));
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}
		List<String> val2 = new ArrayList<String>(new LinkedHashSet<>(val));
		return val2;
	}
}

package com.app.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.ResponseFileModel;
import com.app.model.SensorFileModel;
import com.app.model.SensorModel1;
import com.app.model.SubResponseModel;
import com.app.service.GetSensorFileService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * センサーファイル情報取得コントローラクラス
 * @author（TOSCO）ウェイ
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags ={Consts.TAGS_SENSOR_DATA_FILE_MGT,}, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class GetSensorFileAPIController {

	@Autowired private GetSensorFileService _service;
	@Autowired private MessageSource _msgSource;

	public static final Logger logger = LoggerFactory.getLogger(GetSensorFileAPIController.class);

	/**
	 * センサーファイル情報取得処理
	 */
	@ApiOperation(value = Consts.MSG_SENSOR_FILE, notes = Consts.MSG_SENSOR_FILE_01, nickname = Consts.OPERATIONID_SENSOR_FILE_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseFileModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_SENSOR_FILE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    public ResponseEntity<List<ResponseFileModel>> index(Locale locale
    											, SensorFileModel reqModel, BindingResult errors) throws Exception {

		logger.info("【センサーファイル情報取得】Request：" + reqModel);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}

		// センサーファイル情報を取得する
		List<ResponseFileModel> lstResult =_service.getSensorFileInfo(reqModel);
		return new ResponseEntity<List<ResponseFileModel>>(lstResult, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale
												, SensorFileModel req
												, List<SubResponseModel> lstError){

		// リクエスト．検索区分が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(req.getGet_class()) || StringUtil.IsBlank(req.getGet_class())){
			lstError.add(new SubResponseModel("get_class"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		}else{
			// リクエスト．検索区分が 「1、2」以外の場合
			if(!StringUtil.IsChar1(req.getGet_class())){
				lstError.add(new SubResponseModel("get_class"
						, _msgSource.getMessage(Consts.MESSAGE_E000044, null, locale)));
			}
		}

		//Date mTimeTo = null;
		Date mTimeFrom = null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.");
		formatter.setLenient(false);

		// 対象期間(From)が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(req.getMeasure_time_from()) || StringUtil.IsBlank(req.getMeasure_time_from())){
			lstError.add(new SubResponseModel("measure_time_from"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		}else{
			if(!StringUtil.chkLength(req.getMeasure_time_from(), 27)){
				lstError.add(new SubResponseModel("measure_time_from"
						,_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));

			}else{
				try{
					Timestamp tsFrom = new Timestamp(formatter.parse(req.getMeasure_time_from().substring(0, 20)).getTime());
					tsFrom.setNanos(Integer.parseInt(req.getMeasure_time_from().substring(20, 27)) * 100);
					mTimeFrom = new Date(tsFrom.getTime());

					// 対象期間(From)が現在日時より未来の場合
					/*if(date.compareTo(mTimeFrom) < 0){
						lstError.add(new SubResponseModel("measure_time_from"
								, _msgSource.getMessage(Consts.MESSAGE_E000014
										, new String[]{_msgSource.getMessage(Consts.MESSAGE_SYSTEM_DATETIME, null, locale)
												,_msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_FROM, null, locale)}
								, locale)));
					}*/
				} catch (Exception e) {
					// 対象期間(From)のフォーマットが不正、又は 不正な日付の場合
					lstError.add(new SubResponseModel("measure_time_from"
							,_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
				}
			}
		}

		if(!StringUtil.IsNullOrEmpty(req.getMeasure_time_to()) && !StringUtil.IsBlank(req.getMeasure_time_to())){

			if(!StringUtil.chkLength(req.getMeasure_time_to(), 27)){
				lstError.add(new SubResponseModel("measure_time_to"
						, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));

			}else{
				try{
					Timestamp tsTo = new Timestamp(formatter.parse(req.getMeasure_time_to().substring(0, 20)).getTime());
					tsTo.setNanos(Integer.parseInt(req.getMeasure_time_to().substring(20, 27)) * 100);


					//mTimeTo = new Date(tsTo.getTime());

					// 対象期間(To)が現在日時より未来の場合
					/*if(mTimeTo.compareTo(date) > 0){
						lstError.add(new SubResponseModel("measure_time_to"
								, _msgSource.getMessage(Consts.MESSAGE_E000014
										, new String[]{_msgSource.getMessage(Consts.MESSAGE_SYSTEM_DATETIME, null, locale)
												,_msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_TO, null, locale)}
								, locale)));

					}else{*/
						// 対象期間(From)が対象期間(To)より未来の場合
						if(mTimeFrom != null ){
							Timestamp tsFrom = new Timestamp(formatter.parse(req.getMeasure_time_from().substring(0, 20)).getTime());
							tsFrom.setNanos(Integer.parseInt(req.getMeasure_time_from().substring(20, 27)) * 100);
							if(tsTo.compareTo(tsFrom) < 0){
								lstError.add(new SubResponseModel("measure_time_from, measure_time_to"
										, _msgSource.getMessage(Consts.MESSAGE_E000014
												, new String[]{_msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_TO, null, locale)
														, _msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_FROM, null, locale)}
										, locale)));
							}
						}
					//}
				} catch (Exception e) {
					// 対象期間(To)のフォーマットが不正、又は 不正な日付の場合
					lstError.add(new SubResponseModel("measure_time_to"
							,_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
				}
			}
		}

		int idx = 0;
		// リクエスト．センサーリストが null、又は 空リストの場合
		if(req.getSensor_list() == null || req.getSensor_list().size() <= 0){
			lstError.add(new SubResponseModel("sensor_list"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			for(SensorModel1 ssModel : req.getSensor_list()){

				boolean isNull = false;
				if(StringUtil.IsNullOrEmpty(ssModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				if(StringUtil.IsNullOrEmpty(ssModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				if(isNull == false){
					if(StringUtil.IsBlank(ssModel.getModel_id()) && StringUtil.IsBlank(ssModel.getSerial_no())){
						lstError.add(new SubResponseModel("[" + idx + "]model_id, serial_no"
								, _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}
				idx += 1;
			}
		}

		String sorts = req == null?null:req.getSort();
		String page = req == null?null:req.getPage();
		String limit = req == null?null:req.getLimit();
		String fields = req == null?null:req.getFields();

		//page指定あり不正の場合
		try{
			if (page != null && Integer.parseInt(page)<1){
	        	lstError.add(new SubResponseModel("page",
	        			_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
        	lstError.add(new SubResponseModel("page",
        			_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limit指定あり不正の場合
		try{
			if (limit != null && Integer.parseInt(limit)<1){
	        	lstError.add(new SubResponseModel("limit",
	        			_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
        	lstError.add(new SubResponseModel("limit",
        			_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if(sorts != null){
			List<String> sortParams = new ArrayList<String>();
			for (String item : sorts.split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(sortParams)
	        		|| !StringUtil.hasProperty(new ResponseFileModel(), sortParams)){
	        	lstError.add(new SubResponseModel("sort",
	        			_msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		// フィールドの指定が不正な場合
		if(fields != null){
			List<String> fieldParams = new ArrayList<String>();
			for (String item : fields.split(",")) {
				fieldParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(fieldParams)
	        		|| !StringUtil.hasProperty(new ResponseFileModel(), fieldParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			_msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		return lstError;
	}
}

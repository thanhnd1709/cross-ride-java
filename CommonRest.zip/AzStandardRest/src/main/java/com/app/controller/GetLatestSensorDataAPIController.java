package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.ResponseLatestSensorDataModel;
import com.app.model.SensorDataModel1;
import com.app.model.SensorModel1;
import com.app.model.SubResponseModel;
import com.app.service.GetLatestSensorDataService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * センサー最新値取得コントローラクラス
 * @author（TOSCO）ウェイ
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags ={Consts.TAGS_SENSOR_DATA_FILE_MGT,}, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class GetLatestSensorDataAPIController {

	@Autowired private GetLatestSensorDataService _service;
	@Autowired private MessageSource _msgSource;

	public static final Logger logger = LoggerFactory.getLogger(GetLatestSensorDataAPIController.class);

	/**
	 * センサー最新値取得処理
	 */
	@ApiOperation(value = Consts.MSG_LATEST_SENSOR_DATA, notes = Consts.MSG_LATEST_SENSOR_DATA_01, nickname = Consts.OPERATIONID_LATEST_SENSOR_DATA_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseLatestSensorDataModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_LATEST_SENSOR_DATA, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    public ResponseEntity<List<ResponseLatestSensorDataModel>> GetLatestSensorData(Locale locale
    															, SensorDataModel1 reqModel) throws Exception {
		//logger.debug("request：" + reqModel);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel.getSensor_list(), lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// センサー最新値取得処理
		List<ResponseLatestSensorDataModel> lstResult = _service.getLatestSensorData(reqModel.getSensor_list());
		//logger.debug("response：" + lstResult);
		return new ResponseEntity<List<ResponseLatestSensorDataModel>>(lstResult, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale
												, List<SensorModel1> sensorList
												, List<SubResponseModel> lstError){
		int idx = 0;
		// リクエスト．センサーリストが null、又は 空リストの場合
		if(sensorList == null || sensorList.size() <= 0){
			lstError.add(new SubResponseModel("sensor_list"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			for(SensorModel1 ssModel : sensorList){

				boolean isNull = false;

				// リクエスト．機種IDが null の場合
				if(StringUtil.IsNullOrEmpty(ssModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				// リクエスト．シリアルNoが null の場合
				if(StringUtil.IsNullOrEmpty(ssModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				if(isNull == false){
					// リクエスト．機種ID、リクエスト．シリアルNo 両方空白（""）の場合
					if(StringUtil.IsBlank(ssModel.getModel_id()) && StringUtil.IsBlank(ssModel.getSerial_no())){
						lstError.add(new SubResponseModel("[" + idx + "]model_id, serial_no"
								, _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}
				idx += 1;
			}
		}
		return lstError;
	}
}

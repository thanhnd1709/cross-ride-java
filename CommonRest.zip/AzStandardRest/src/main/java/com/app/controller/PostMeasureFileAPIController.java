package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.entity.PostExpansionFileEntity;
import com.app.exception.BadRequestException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.PostMeasureFileQueryModel;
import com.app.model.ResponseFileModel2;
import com.app.model.SubResponseModel;
import com.app.service.PostMeasureFileService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * 画像・音ファイル等登録コントローラクラス
 * @author（TOSCO）
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags ={Consts.TAGS_SENSOR_DATA_FILE_MGT,}, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class PostMeasureFileAPIController {

	@Autowired private PostMeasureFileService _service;
	@Autowired private MessageSource _msgSource;
	@Autowired private AuthUserInfoComponent authUserInfoComponent;

	public static final Logger logger = LoggerFactory.getLogger(PostMeasureFileAPIController.class);

	/**
	 * ファイル登録処理
	 */
	@ApiOperation(value = Consts.MSG_POST_MEASURE_FILE, notes = Consts.MSG_POST_MEASURE_FILE_01, nickname = Consts.OPERATIONID_POST_MEASURE_FILE_CREATE)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Created", response = ResponseFileModel2.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@ResponseStatus(HttpStatus.CREATED)
	@RequestMapping(value = Consts.REQUEST_URL_MEASURE_FILE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public ResponseEntity<ResponseFileModel2> PostMeasureFile(Locale locale,@RequestBody PostMeasureFileQueryModel reqModel) throws Exception {

		logger.info("request：" + reqModel);


		// 認証されたユーザIDを設定
		String userId = authUserInfoComponent.getPrincipalName();
		reqModel.setUser_id(userId);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}


		// ファイル登録処理
		String result = _service.postMeasureFile(reqModel);
		return new ResponseEntity<ResponseFileModel2>(new ResponseFileModel2(result), HttpStatus.CREATED);
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 * @throws Exception
	 */
	private List<SubResponseModel> Validation(Locale locale, PostMeasureFileQueryModel reqModel, List<SubResponseModel> lstError) throws Exception{

		// リクエスト．圧縮有無フラグが null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getZip_flg()) || StringUtil.IsBlank(reqModel.getZip_flg())){
			lstError.add(new SubResponseModel("zip_flg"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// リクエスト．ファイルデータが null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getFile_data()) || StringUtil.IsBlank(reqModel.getFile_data())){
			lstError.add(new SubResponseModel("file_data"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// 機種IDが nullの場合
		if(StringUtil.IsNullOrEmpty(reqModel.getModel_id())){
			lstError.add(new SubResponseModel("model_id"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// シリアルNoが nullの場合
		if(StringUtil.IsNullOrEmpty(reqModel.getSerial_no())){
			lstError.add(new SubResponseModel("serial_no"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// 機種ID、シリアルNoが共に空白（""）の場合
		if(((!StringUtil.IsNullOrEmpty(reqModel.getModel_id()) && !StringUtil.IsNullOrEmpty(reqModel.getSerial_no())))
				&& (StringUtil.IsBlank(reqModel.getModel_id()) && StringUtil.IsBlank(reqModel.getSerial_no()))){
			lstError.add(new SubResponseModel("model_id, serial_no"
					, _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
		}

		// センサーIDが nullの場合
		if((StringUtil.IsNullOrEmpty(reqModel.getSensor_id()))){
			lstError.add(new SubResponseModel("sensor_id"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// 計測時間が null の場合
		if((StringUtil.IsNullOrEmpty(reqModel.getMeasure_time()))){
			lstError.add(new SubResponseModel("measure_time"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}
		else if(!StringUtil.IsBlank(reqModel.getMeasure_time())){
			// 計測時間のフォーマットが不正な場合
			 if(!(StringUtil.IsHalfNumber(reqModel.getMeasure_time()) && reqModel.getMeasure_time().length()==21)){
				lstError.add(new SubResponseModel("measure_time"
						, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
			}
		}

		if(lstError.isEmpty()){
			List<PostExpansionFileEntity> authChk = _service.sensorAuthChk(reqModel,locale);
			if(!authChk.isEmpty()){
				for(PostExpansionFileEntity s : authChk){
					lstError.add(new SubResponseModel("model_id, serial_no, sensor_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000119,
									new String[] { s.getModel_id(), s.getSerial_no(),s.getSensor_id() }, locale)));
				}
			}
	}
		return lstError;
		}
	}

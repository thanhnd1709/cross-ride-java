package com.app.controller;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.app.common.Consts;
import com.app.common.utils.CustomTelemetryThreadLocal;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.ResponseModel;
import com.app.model.SubResponseModel;
import com.microsoft.azure.sdk.iot.service.exceptions.IotHubNotFoundException;

@RestControllerAdvice
public class ApiExceptionHandler {
	public static final Logger logger = LoggerFactory.getLogger(ApiExceptionHandler.class);
	public static final int WARN_LEVEL = 2;
	public static final int ERROR_LEVEL =3;


	@Autowired
	private MessageSource messageSource;




    /**
     * 400 - Bad Request (キー重複以外のDB制約違反)
     * 409 - Conflicted (キー重複)
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Object>  HandleDataIntegrityViolationException(DataIntegrityViolationException e, Locale locale){
		// DBの例外を取得
    	Throwable cause = getRootCause(e);
		String detail = messageSource.getMessage(Consts.MESSAGE_E000111, new String[]{cause.getMessage()}, locale);

		ResponseEntity<Object> res = null;
		if (cause.getMessage().toLowerCase().indexOf("duplicate") > -1) {
			// キー重複エラー
			setLogger(Consts.HTTP_CODE_409,detail,e,WARN_LEVEL);
			res = new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_409, Consts.HTTP_MESSAGE_409, detail)
					, HttpStatus.CONFLICT);
		} else {
			setLogger(Consts.HTTP_CODE_400,detail,e,WARN_LEVEL);
			res = new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_400, Consts.HTTP_MESSAGE_400, detail)
					, HttpStatus.BAD_REQUEST);

		}
		return res;
    }

	/**
     * 500 - Internal Server Error
     */
    @ExceptionHandler( TransactionSystemException.class)
    public ResponseEntity<Object>  HandleTransactionSystemException(TransactionSystemException e, Locale locale){
    	setLogger(Consts.HTTP_CODE_500,"Exception",e,ERROR_LEVEL);

        String detail = e.getMessage();
        if(StringUtil.IsNullOrEmpty(detail) || StringUtil.IsBlank(detail)){
     	   detail = " ";
        }

        return new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_500, Consts.HTTP_MESSAGE_500, detail)
 				, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
     * 400 - Bad Request
     */
    @ExceptionHandler(LockingFailureException.class)
    @ResponseBody
	public ResponseEntity<Object> HandleObjectOptimisticLockingFailureException(
			LockingFailureException e, Locale locale) {


		String detail = messageSource.getMessage(Consts.MESSAGE_E000110, e.getArgs(), locale);
    	setLogger(Consts.HTTP_CODE_400,detail,e,WARN_LEVEL);


		return new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_400, Consts.HTTP_MESSAGE_400, detail)
				, HttpStatus.BAD_REQUEST);
	}

    /**
     * 404 - Not Found
     */
    @ExceptionHandler(DataNotFoundException.class)
    @ResponseBody
	public ResponseEntity<Object> HandleDataNotFoundException(DataNotFoundException e, Locale locale) {

		String detail = messageSource.getMessage(Consts.MESSAGE_E000106, e.getArgs(), locale);
		setLogger(Consts.HTTP_CODE_404,detail,e,WARN_LEVEL);

		return new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_404, Consts.HTTP_MESSAGE_404, detail)
				, HttpStatus.NOT_FOUND);
	}

    /**
     * 400 - Bad Request
     */
    @ExceptionHandler(BadRequestException.class)
    @ResponseBody
	public ResponseEntity<Object> HandleBadRequestException(BadRequestException e) {

		List<SubResponseModel> errors = e.getArgs();
		StringBuffer errLog = new StringBuffer();
		if(errors != null) {

			for (SubResponseModel error : errors) {
				if(errLog.length() != 0){
					errLog.append(",");
				}
				errLog.append(String.format("{%s:%s}", error.fieldId, error.message));
			}
			setLogger(Consts.HTTP_CODE_400,errLog.toString(),e,WARN_LEVEL);
		} else {
			setLogger(Consts.HTTP_CODE_400,"BadRequestException",e,WARN_LEVEL);
		}

		return new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_400, Consts.HTTP_MESSAGE_400, errors)
				, HttpStatus.BAD_REQUEST);
	}

    /**
     * 400 - Bad Request　パースエラー対応
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object>  HandleHttpMessageNotReadableException(HttpMessageNotReadableException e, HttpServletRequest req){

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

       String message = "WARN(400) " + (sdf.format((Calendar.getInstance()).getTime()))
                + ": remoteAddr:" + req.getRemoteAddr()
                + ", remoteHost:" + req.getRemoteHost()
                + ", requestURL:" + req.getRequestURL();;
       setLogger(Consts.HTTP_CODE_400,message,e,WARN_LEVEL);

       String detail = e.getMessage();
       if(StringUtil.IsNullOrEmpty(detail) || StringUtil.IsBlank(detail)){
    	   detail = " ";
       }

       return new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_400, Consts.HTTP_MESSAGE_400, detail)
				, HttpStatus.BAD_REQUEST);
    }

    /**
     * 408 - Request Time-out
     */
    @ExceptionHandler(IotHubNotFoundException.class)
    @ResponseBody
	public ResponseEntity<Object> HandleIotHubNotFoundException(IotHubNotFoundException e, Locale locale) {


		String detail = messageSource.getMessage(Consts.MESSAGE_E000128, null, locale);
		setLogger(Consts.HTTP_CODE_408,detail,e,WARN_LEVEL);

		return new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_408,
				Consts.HTTP_MESSAGE_408, detail)
				, HttpStatus.REQUEST_TIMEOUT);
	}

    /**
     * その他例外
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object>  HandleException(Exception e, HttpServletRequest req){

       SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
       String errMessage = "ERROR(500) " + (sdf.format((Calendar.getInstance()).getTime()))
               + ": remoteAddr:" + req.getRemoteAddr()
               + ", remoteHost:" + req.getRemoteHost()
               + ", requestURL:" + req.getRequestURL();

       setLogger(Consts.HTTP_CODE_500,errMessage,e,ERROR_LEVEL);

       String detail = e.getMessage();
       if(StringUtil.IsNullOrEmpty(detail) || StringUtil.IsBlank(detail)){
    	   detail = " ";
       }

       return new ResponseEntity<Object>(new ResponseModel(Consts.HTTP_CODE_500, Consts.HTTP_MESSAGE_500, detail)
				, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    /**
     * 例外の根本例外を取得する。
     * @param th スローされた例外
     * @return 根本例外
     */
    private Throwable getRootCause(Throwable th) {
    	Throwable cause = th.getCause();
    	if (cause == null) return th;

    	return getRootCause(cause);
    }

    /**
     * 出力情報をセットする。
     * @param code
     * @param message
     * @param exception
     * @param output status
     */
    private void setLogger(int code,String message,Exception e,int status) {
    	//message + exception object
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        e.printStackTrace(new PrintStream(out));
        String ex = message +"\r\n"+ new String(out.toByteArray());

    	CustomTelemetryThreadLocal.setErrorCode(Integer.toString(code));
    	CustomTelemetryThreadLocal.setErrorMsg(ex);

    	if(status == Consts.LOG_ERROR_LEVEL){
    		logger.error(ex);
    	}else if(status == Consts.LOG_WARN_LEVEL){
    		logger.warn(ex);
    	}
    }
}

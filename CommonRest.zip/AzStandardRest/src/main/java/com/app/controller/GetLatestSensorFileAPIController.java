package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.ResponseFileModel;
import com.app.model.SensorLatestFileModel;
import com.app.model.SensorModel1;
import com.app.model.SubResponseModel;
import com.app.service.GetLatestSensorFileService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * 最新センサーファイル情報取得コントローラクラス
 * @author（TOSCO）ウェイ
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags ={Consts.TAGS_SENSOR_DATA_FILE_MGT,}, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class GetLatestSensorFileAPIController {

	@Autowired private GetLatestSensorFileService _service;
	@Autowired private MessageSource _msgSource;

	public static final Logger logger = LoggerFactory.getLogger(GetLatestSensorFileAPIController.class);

	/**
	 * 最新センサーファイル情報取得処理
	 */
	@ApiOperation(value = Consts.MSG_LATEST_SENSOR_FILE, notes = Consts.MSG_LATEST_SENSOR_FILE_01, nickname = Consts.OPERATIONID_LATEST_SENSOR_FILE_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseFileModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_LATEST_SENSOR_FILE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    public ResponseEntity<List<ResponseFileModel>> index(Locale locale
    										, SensorLatestFileModel reqModel, BindingResult errors) throws Exception {

		logger.info("【最新センサーファイル情報取得】Request：" + reqModel);

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}

		// センサーファイル情報を取得する
		List<ResponseFileModel> lstResult =_service.getLatestSensorFileInfo(reqModel);
		return new ResponseEntity<List<ResponseFileModel>>(lstResult, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale
												, SensorLatestFileModel req
												, List<SubResponseModel> lstError){
		int idx = 0;
		// リクエスト．センサーリストが null、又は 空リストの場合
		if(req.getSensor_list() == null || req.getSensor_list().size() <= 0){
			lstError.add(new SubResponseModel("sensor_list"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			for(SensorModel1 ssModel : req.getSensor_list()){

				boolean isNull = false;

				// リクエスト．機種IDが null の場合
				if(StringUtil.IsNullOrEmpty(ssModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]:model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				// リクエスト．シリアルNoが null の場合
				if(StringUtil.IsNullOrEmpty(ssModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]:serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				if(isNull == false){
					// リクエスト．機種ID、リクエスト．シリアルNo 両方空白（""）の場合
					if(StringUtil.IsBlank(ssModel.getModel_id()) && StringUtil.IsBlank(ssModel.getSerial_no())){
						lstError.add(new SubResponseModel("[" + idx + "]:model_id, serial_no"
								, _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}
				idx += 1;
			}
		}

		String sorts = req == null?null:req.getSort();
		String page = req == null?null:req.getPage();
		String limit = req == null?null:req.getLimit();
		String fields = req == null?null:req.getFields();

		//page指定あり不正の場合
		try{
			if (page != null && Integer.parseInt(page)<1){
	        	lstError.add(new SubResponseModel("page",
	        			_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
        	lstError.add(new SubResponseModel("page",
        			_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limit指定あり不正の場合
		try{
			if (limit != null && Integer.parseInt(limit)<1){
	        	lstError.add(new SubResponseModel("limit",
	        			_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
        	lstError.add(new SubResponseModel("limit",
        			_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if(sorts != null){
			List<String> sortParams = new ArrayList<String>();
			for (String item : sorts.split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(sortParams)
	        		|| !StringUtil.hasProperty(new ResponseFileModel(), sortParams)){
	        	lstError.add(new SubResponseModel("sort",
	        			_msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		// フィールドの指定が不正な場合
		if(fields != null){
			List<String> fieldParams = new ArrayList<String>();
			for (String item : fields.split(",")) {
				fieldParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(fieldParams)
	        		|| !StringUtil.hasProperty(new ResponseFileModel(), fieldParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			_msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}
		return lstError;
	}
}

package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * デバイス階層取得エンティティクラス
 * @author （TOSCO）9571
 */

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class DeviceStructureEntity {

	@Id
	private Integer id;
	private String parent_device_list;
	private Integer level;
	private String model_id;
	private String serial_no;
	private String device_mode;

}

package com.app.entity;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 計測データエンティティクラス
 * @author（TOSCO）ウェイ
 */
//@Embeddable
@Data
@EqualsAndHashCode
public class StdNewMeasureDataPkEntity implements Serializable{

	private String model_id;
	private String serial_no;
	private String sensor_id;


}

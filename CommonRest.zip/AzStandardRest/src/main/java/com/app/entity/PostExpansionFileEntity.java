package com.app.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ファイル登録用センサーチェック
 */
@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@IdClass(PostExpansionFileEntity.PK.class)
@NoArgsConstructor
public class PostExpansionFileEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String model_id;
	@Id
	private String serial_no;
	@Id
	private String sensor_id;
	
	@Embeddable
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	static class PK implements Serializable {
		private String model_id;
		private String serial_no;
		private String sensor_id;
	}

}


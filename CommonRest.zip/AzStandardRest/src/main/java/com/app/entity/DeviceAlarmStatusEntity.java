package com.app.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * デバイスアラーム状態取得用エンティティクラス
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@IdClass(DeviceAlarmStatusEntity.PK.class)
@EqualsAndHashCode
public class DeviceAlarmStatusEntity implements Serializable {
	@Id
	private String model_id;
	@Id
	private String serial_no;
	@Id
	private String detection_class;

	private String max_event_level;

	@Embeddable
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	static class PK implements Serializable {
		private String model_id;
		private String serial_no;
		private String detection_class;
	}
}


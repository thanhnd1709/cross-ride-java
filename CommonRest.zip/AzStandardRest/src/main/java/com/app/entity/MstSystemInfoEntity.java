package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * システムの設定情報エンティティクラス
 * @author（TOSCO）ウェイ
 */
@Entity
@Table(name="mst_system_info")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MstSystemInfoEntity{

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column(name="[key]")
	private String key;
	@Column
	private Long value_int;
	@Column
	private Double value_float;
	@Column
	private String value_string;
	@Column
	private Boolean value_flg;
}

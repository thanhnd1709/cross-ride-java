package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * デバイスグループアラーム状態取得エンティティクラス
 * @author（TOSCO）エヒー
 */

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class DeviceGroupAlarmStatusEntity {

	@Id
	private String device_group_id;
	private String detection_class;
	private String event_level;

}

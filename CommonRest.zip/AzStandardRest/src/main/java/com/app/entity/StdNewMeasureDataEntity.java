package com.app.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 計測データの最新値エンティティクラス
 * @author（TOSCO）ウェイ
 */
@Entity
@Table(name="std_new_measure_data")
@Data
@AllArgsConstructor
@NoArgsConstructor
@IdClass(value=StdNewMeasureDataPkEntity.class)
public class StdNewMeasureDataEntity implements Serializable{

	@Id
	private String model_id;
	@Id
	private String serial_no;
	@Id
	private String sensor_id;
	@Column
	private Timestamp measure_time;
	@Column
	private String measure_data;
	@Version
	@Column
	private Long version;
}

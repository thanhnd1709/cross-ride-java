package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * イベント・アラーム履歴検索エンティティクラス
 * @author（TOSCO）小川
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class EventHistoryEntity {

	@Id
	private Integer id;
	private String model_id;
	private String serial_no;
	private String detection_class;
	private String event_id;
	private String event_time;
	private String event_status;
	private String incident_class;
	private String event_level;
	private String detection_info;
	private String event_type;
	private String sensor_id;
	private String name_locale1;
	private String name_locale2;
	private String name_locale3;
	private String description_locale1;
	private String description_locale2;
	private String description_locale3;
	private String chk_app_name;
	private String chk_app_parameter;
	private String check_timing;
	private String note;

}


package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 11.4.1.	デバイスグループ階層情報取得エンティティクラス
 * @author（TOSCO）エー
 */

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class DeviceGroupStructureEntity {

	private String parent_device_group_list;
	private String level;
	@Id
	private String device_group_id;

}

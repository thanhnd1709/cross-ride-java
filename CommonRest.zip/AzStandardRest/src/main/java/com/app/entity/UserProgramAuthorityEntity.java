package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ユーザ・プログラム権限情報エンティティ
 * ※ユーザ・プログラム権限情報は実テーブルではなく、
 * ロール情報、ユーザ・ロール、プログラム権限情報、
 * ロール・プログラム権限をjoinしたデータ。
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserProgramAuthorityEntity {

	@Id
	private Integer id;
	@Column
	private String authority_id;
	@Column
	private String authority_type;
	@Column
	private String program_name_locale1;
	@Column
	private String program_name_locale2;
	@Column
	private String program_name_locale3;
	@Column
	private String program_description_locale1;
	@Column
	private String program_description_locale2;
	@Column
	private String program_description_locale3;
	@Column
	private String program_id;
	@Column
	private String url;
	@Column
	private String method;
	@Column
	private String program_note;
	@Column
	private String role_id;
	@Column
	private String role_name_locale1;
	@Column
	private String role_name_locale2;
	@Column
	private String role_name_locale3;
	@Column
	private String role_description_locale1;
	@Column
	private String role_description_locale2;
	@Column
	private String role_description_locale3;
	@Column
	private String role_note;
}


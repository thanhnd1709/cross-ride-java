package com.app.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 計測データエンティティクラス
 * @author（TOSCO）ウェイ
 */
@Entity
@Table(name="std_measure_data")
@Data
@AllArgsConstructor
@NoArgsConstructor
@IdClass(value=StdMeasureDataPkEntity.class)
public class StdMeasureDataEntity implements Serializable{

	@Id
	private String model_id;
	@Id
	private String serial_no;
	@Id
	private String sensor_id;
	@Id
	private Timestamp measure_time;

	@Column
	private String measure_data;
	@Column
	private char data_migrate_class;
	@Version
	@Column
	private Long version;
}

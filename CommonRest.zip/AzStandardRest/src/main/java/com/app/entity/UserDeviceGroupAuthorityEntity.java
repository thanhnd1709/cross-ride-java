package com.app.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ユーザ・デバイスグループ権限情報エンティティ
 * ※ユーザ・デバイスグループ権限情報は実テーブルではなく、
 * DB Functionユーザ・デバイスグループ取得(fn_UserDeviceGroup)から
 * 返却されるテーブル値。
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDeviceGroupAuthorityEntity {

	@Id
	private Integer id;
	@Column
	private String device_group_id;
	@Column
	private String device_group_type;
	@Column
	private String device_group_subtype;
	@Column
	private String device_group_name_locale1;
	@Column
	private String device_group_name_locale2;
	@Column
	private String device_group_name_locale3;
	@Column
	private String device_group_description_locale1;
	@Column
	private String device_group_description_locale2;
	@Column
	private String device_group_description_locale3;
	@Column
	private String parent_device_group_id;
	@Column
	private String setup_place;
	@Column
	private String setup_status;
	@Column
	private BigDecimal latitude;
	@Column
	private BigDecimal longitude;
	@Column
	private String device_group_note;
	@Column
	private String role_id;
	@Column
	private String root_group_id;
	@Column
	private String role_name_locale1;
	@Column
	private String role_name_locale2;
	@Column
	private String role_name_locale3;
	@Column
	private String role_description_locale1;
	@Column
	private String role_description_locale2;
	@Column
	private String role_description_locale3;
	@Column
	private String role_note;
	@Column
	private Integer hierarchy;
}


package com.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 */
@Entity
@Table(name="std_gw_command_history")
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class StdGwCommandHistoryEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer id;

	@Column
	private String gw_model_id;
	@Column
	private String gw_serial_no;
	@Column
	private String model_id;
	@Column
	private String serial_no;
	@Column
	private String operation;
	@Column
	private String argument;
	@Column
	private String exec_time;
	@Column
	private Integer wait_time;
	@CreatedBy
	@Column
	private String request_user_id;
	@Column
	private String remote_addr;
	@Column
	private String client_addr;
	@Column
	private String http_referer;
	@Column
	private String cors_origin;
	@Column
	private Timestamp request_time;
	@Column
	private String result_code;
	@Column
	private String result_detail_code;
	@Column
	private String result_message;
	@Column
	private String result_data;
	@Column
	private Timestamp result_time;
}


package com.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 */
@Entity
@Table(name="std_event_incidence")
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class StdEventIncidenceEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer id;

	@Column
	private String model_id;
	@Column
	private String serial_no;
	@Column
	private String detection_class;
	@Column
	private String event_id;
	@Column
	private Timestamp event_time;
	@Column
	private String event_status;
	@Column
	private String incident_class;
	@Column
	private String event_level;
	@Column
	private String cope_status;
	@Column
	private Timestamp incident_time;
	@Column
	private Timestamp return_time;
	@Version
	@Column
	private Long version;

	@Column
	private Timestamp insert_time;

	@PrePersist
    public void onPrePersist() {
        setInsert_time(new Timestamp(System.currentTimeMillis()));
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

	@Column
	private Timestamp update_time;

	@PreUpdate
    public void onPreUpdate() {
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

}


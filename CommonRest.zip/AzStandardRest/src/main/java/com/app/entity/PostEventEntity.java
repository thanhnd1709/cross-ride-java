package com.app.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * イベント・アラーム登録用イベント権限チェック
 */
@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@IdClass(PostEventEntity.PK.class)
@NoArgsConstructor
public class PostEventEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String model_id;
	@Id
	private String serial_no;
	@Id
	private String event_id;
	
	@Embeddable
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	static class PK implements Serializable {
		private String model_id;
		private String serial_no;
		private String event_id;
	}

}


package com.app.repository.impl;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

import com.app.entity.StdEventIncidenceEntity;
import com.app.repository.StatusManagementRepositoryCustom;

@Component
public class StatusManagementRepositoryImpl implements StatusManagementRepositoryCustom {
	@PersistenceContext
	EntityManager em;

	@Override
	public StdEventIncidenceEntity findOneForUpdate(int id) {
		return em.find(StdEventIncidenceEntity.class, id, LockModeType.PESSIMISTIC_WRITE);
	}

//	@Override
//	public Long countAll(UpdateEventStatusQueryModel query) {
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
//		Root<UpdateeventstatusEntity> root = criteriaQuery.from(UpdateeventstatusEntity.class);
//		criteriaQuery.select(builder.count(root));
//		List<Predicate> conditionList = buildConditionList(query, root);
//		if( conditionList.size() > 0 ){
//			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
//		}
//		return em.createQuery(criteriaQuery).getSingleResult().longValue();
//	}
//
//	@Override
//	public List<UpdateeventstatusEntity> findAll(UpdateEventStatusQueryModel query, List<String> sort, Integer limit, Integer offset) {
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		CriteriaQuery<UpdateeventstatusEntity> criteriaQuery = builder.createQuery(UpdateeventstatusEntity.class);
//		Root<UpdateeventstatusEntity> root = criteriaQuery.from(UpdateeventstatusEntity.class);
//		List<Predicate> conditionList = buildConditionList(query, root);
//		if(conditionList.size() > 0){
//			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
//		}
//
//		if (sort.size() > 0) {
//			List<Order> orderList = new ArrayList<Order>();
//			for (String col : sort) {
//				if (col.startsWith("-")) {
//					orderList.add(builder.desc(root.get(col.substring(1))));
//				} else {
//					orderList.add(builder.asc(root.get(col)));
//				}
//			}
//			criteriaQuery.orderBy(orderList);
//		}
//
//		TypedQuery<UpdateeventstatusEntity> q = em.createQuery(criteriaQuery);
//		if (offset != null) q.setFirstResult(offset);
//		if (limit != null) q.setMaxResults(limit);
//
//		return q.getResultList();
//	}
//
//	public <T> long count(List<Predicate> conditionList, Class<T> entity) {
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
//		Root<T> root = criteriaQuery.from(entity);
//		criteriaQuery.select(builder.count(root));
//		if( conditionList.size() > 0 ){
//			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
//		}
//		return em.createQuery(criteriaQuery).getSingleResult().longValue();
//	}

//	private List<Predicate> buildConditionList(UpdateEventStatusQueryModel query, Root<UpdateeventstatusEntity> root) {
//		List<Predicate> conditionList = new ArrayList<>();
//
//		if (query.getCope_status() != null && query.getCope_status().length > 0) {
//			conditionList.add(root.get("cope_status").in(Arrays.asList(query.getCope_status())));
//		}
//		if (query.getVersion() != null && query.getVersion().length > 0) {
//			Object[] arr = Stream.of(query.getVersion()).map(StringUtil.String2Long).toArray();
//			conditionList.add(root.get("version").in(Arrays.asList(arr)));
//		}		return conditionList;
//	}
}
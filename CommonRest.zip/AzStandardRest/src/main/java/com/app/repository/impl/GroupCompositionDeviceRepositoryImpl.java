package com.app.repository.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.MstGroupCompositionDeviceEntity;
import com.app.model.GroupCompositionDeviceQueryModel;
import com.app.repository.GroupCompositionDeviceRepositoryCustom;

@Component
public class GroupCompositionDeviceRepositoryImpl implements GroupCompositionDeviceRepositoryCustom {
	@Autowired EntityManager em;

	@Override
	public MstGroupCompositionDeviceEntity findOneForUpdate(int id) {
		return em.find(MstGroupCompositionDeviceEntity.class, id, LockModeType.PESSIMISTIC_WRITE);
	}

	@Override
	public Long countAll(GroupCompositionDeviceQueryModel query) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<MstGroupCompositionDeviceEntity> root = criteriaQuery.from(MstGroupCompositionDeviceEntity.class);
		criteriaQuery.select(builder.count(root));
		List<Predicate> conditionList = buildConditionList(query, root);
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	@Override
	public List<MstGroupCompositionDeviceEntity> findAll(GroupCompositionDeviceQueryModel query, List<String> sort, Integer limit, Integer offset) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MstGroupCompositionDeviceEntity> criteriaQuery = builder.createQuery(MstGroupCompositionDeviceEntity.class);
		Root<MstGroupCompositionDeviceEntity> root = criteriaQuery.from(MstGroupCompositionDeviceEntity.class);
		List<Predicate> conditionList = buildConditionList(query, root);
		if(conditionList.size() > 0){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}

		if (sort.size() > 0) {
			List<Order> orderList = new ArrayList<Order>();
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderList.add(builder.desc(root.get(col.substring(1))));
				} else {
					orderList.add(builder.asc(root.get(col)));
				}
			}
			criteriaQuery.orderBy(orderList);
		}

		TypedQuery<MstGroupCompositionDeviceEntity> q = em.createQuery(criteriaQuery);
		if (offset != null) q.setFirstResult(offset);
		if (limit != null) q.setMaxResults(limit);

		return q.getResultList();
	}

	public <T> long count(List<Predicate> conditionList, Class<T> entity) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<T> root = criteriaQuery.from(entity);
		criteriaQuery.select(builder.count(root));
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	private List<Predicate> buildConditionList(GroupCompositionDeviceQueryModel query, Root<MstGroupCompositionDeviceEntity> root) {
		List<Predicate> conditionList = new ArrayList<>();
		if (query.getId() != null && query.getId().length > 0) {
			Object[] arr = Stream.of(query.getId()).map(StringUtil.String2Integer).toArray();
			conditionList.add(root.get("id").in(Arrays.asList(arr)));
		}
		if (query.getDevice_group_id() != null && query.getDevice_group_id().length > 0) {
			conditionList.add(root.get("device_group_id").in(Arrays.asList(query.getDevice_group_id())));
		}
		if (query.getModel_id() != null && query.getModel_id().length > 0) {
			conditionList.add(root.get("model_id").in(Arrays.asList(query.getModel_id())));
		}
		if (query.getSerial_no() != null && query.getSerial_no().length > 0) {
			conditionList.add(root.get("serial_no").in(Arrays.asList(query.getSerial_no())));
		}
		if (query.getVersion() != null && query.getVersion().length > 0) {
			Object[] arr = Stream.of(query.getVersion()).map(StringUtil.String2Long).toArray();
			conditionList.add(root.get("version").in(Arrays.asList(arr)));
		}
		if (query.getInserted() != null && query.getInserted().length > 0) {
			conditionList.add(root.get("inserted").in(Arrays.asList(query.getInserted())));
		}
		if (query.getInsert_time() != null && query.getInsert_time().length > 0) {
			Object[] arr = Stream.of(query.getInsert_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("insert_time").in(Arrays.asList(arr)));
		}
		if (query.getUpdated() != null && query.getUpdated().length > 0) {
			conditionList.add(root.get("updated").in(Arrays.asList(query.getUpdated())));
		}
		if (query.getUpdate_time() != null && query.getUpdate_time().length > 0) {
			Object[] arr = Stream.of(query.getUpdate_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("update_time").in(Arrays.asList(arr)));
		}
		return conditionList;
	}
}
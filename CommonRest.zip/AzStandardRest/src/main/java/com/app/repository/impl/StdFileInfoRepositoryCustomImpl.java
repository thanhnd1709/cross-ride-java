package com.app.repository.impl;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.StdFileInfoEntity;
import com.app.model.SensorFileModel;
import com.app.model.SensorLatestFileModel;
import com.app.model.SensorModel3;
import com.app.repository.StdFileInfoRepositoryCustom;

/**
 * 計測ファイル情報リポジトリ実装クラス
 * @author（TOSCO）ウェイ
 */
@Component
public class StdFileInfoRepositoryCustomImpl implements StdFileInfoRepositoryCustom {

	@Autowired EntityManager em;

	@Override
	public List<StdFileInfoEntity> searchAll(SensorFileModel query, List<SensorModel3> sensorList
			, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) throws Exception {

		String baseSql = " SELECT"
						+  " fi.id,"
						+  " fi.model_id,"
						+  " fi.serial_no,"
						+  " fi.sensor_id,"
						+  " fi.measure_time,"
						+  " fi.upload_time,"
						+  " fi.zip_flg,"
						+  " fi.file_name,"
						+  " fi.hash,"
						+  " fi.sender_device_id,"
						+  " fi.notice_time,"
						+  " fi.reserve1,"
						+  " fi.reserve2,"
						+  " fi.reserve3,"
						+  " fi.reserve4,"
						+  " fi.reserve5,"
						+  " fi.other_metadata,"
						+  " fi.upload_user_id"
						+  " FROM std_fileinfo fi"
						+  " WHERE fi.measure_time >= :measure_time_from"
						+  "   AND fi.measure_time < :measure_time_to";

		// WHERE句作成
		Map<String, Object> params = new HashMap<String, Object>();
		baseSql += buildCondition( query, "fi.",params);

		//キー項目(model_id, serial_no, sensor_no)
		baseSql +=  this.buildConditionKeySet(sensorList, "fi.",params);


		boolean isNull = false;
		// ソート順が指定されている場合
		if(sort != null){
			baseSql = " SELECT * FROM (" + baseSql + ") b ORDER BY " + sort;
			isNull = true;
		}

		// ページングが指定されている場合
		if(limit != null && offset != null){
			// ソート順が指定されていない場合
			if(isNull == false){
				baseSql = " SELECT * FROM (" + baseSql + ") b"
						+ " ORDER BY model_id, serial_no, sensor_id, measure_time";
			}
			baseSql += " OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}

		Query q = em.createNativeQuery(baseSql, StdFileInfoEntity.class);
		q.setParameter("measure_time_from", dateFrom);
		q.setParameter("measure_time_to", dateTo);
		//検索条件可変の部分のバイト
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		if(limit != null && offset != null){
			q.setParameter("offset", offset);
			q.setParameter("limit", limit);
		}

		@SuppressWarnings("unchecked")
		List<StdFileInfoEntity> list = q.getResultList();
		return list;
	}

	@Override
	public List<StdFileInfoEntity> searchFirst(SensorFileModel query, List<SensorModel3> sensorList
			, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) throws Exception {

		// WHERE句作成
		Map<String, Object> params = new HashMap<String, Object>();


		String subQuery =
				 " ("
				+  " SELECT fi2.model_id,"
				+  "        fi2.serial_no,"
				+  "        fi2.sensor_id,"
				+  "        min(fi2.measure_time) measure_time"
				+  "   FROM  std_fileinfo fi2"
				+  "    where fi2.measure_time >= :measure_time_from"
				+  "    AND fi2.measure_time < :measure_time_to"
				+      this.buildCondition(query, "fi2.",params)
				+  "    group by  fi2.model_id, fi2.serial_no,fi2.sensor_id"
				+  "  ) sub";



		String baseSql = " SELECT"
						+  " fi.id,"
						+  " fi.model_id,"
						+  " fi.serial_no,"
						+  " fi.sensor_id,"
						+  " fi.measure_time,"
						+  " fi.upload_time,"
						+  " fi.zip_flg,"
						+  " fi.file_name,"
						+  " fi.hash,"
						+  " fi.sender_device_id,"
						+  " fi.notice_time,"
						+  " fi.reserve1,"
						+  " fi.reserve2,"
						+  " fi.reserve3,"
						+  " fi.reserve4,"
						+  " fi.reserve5,"
						+  " fi.other_metadata,"
						+  " fi.upload_user_id"
						+  " FROM std_fileinfo fi, " + subQuery
						+  " WHERE fi.model_id = sub.model_id "
						+  "    AND fi.serial_no = sub.serial_no "
						+  "    AND fi.sensor_id = sub.sensor_id"
						+  "    AND fi.measure_time = sub.measure_time" ;


		//キー項目(model_id, serial_no, sensor_no)
		baseSql +=  this.buildConditionKeySet(sensorList, "fi.",params);


		boolean isNull = false;
		// ソート順が指定されている場合
		if(sort != null){
			baseSql = " SELECT * FROM (" + baseSql + ") b ORDER BY " + sort;
			isNull = true;
		}

		// ページングが指定されている場合
		if(limit != null && offset != null){
			// ソート順が指定されていない場合
			if(isNull == false){
				baseSql = " SELECT * FROM (" + baseSql + ") b"
						+ " ORDER BY model_id, serial_no, sensor_id, measure_time";
			}
			baseSql += " OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}

		Query q = em.createNativeQuery(baseSql, StdFileInfoEntity.class);
		q.setParameter("measure_time_from", dateFrom);
		q.setParameter("measure_time_to", dateTo);

		//検索条件可変の部分のバイト
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		if(limit != null && offset != null){
			q.setParameter("offset", offset);
			q.setParameter("limit", limit);
		}

		@SuppressWarnings("unchecked")
		List<StdFileInfoEntity> list = q.getResultList();
		return list;
	}

	@Override
	public List<StdFileInfoEntity> searchLast(SensorLatestFileModel query, List<SensorModel3> sensorList, String sort,
			Integer limit, Integer offset) throws Exception {

		// WHERE句作成
		Map<String, Object> params = new HashMap<String, Object>();






		String baseSql = " SELECT"
				+  " fi.id,"
				+  " fi.model_id,"
				+  " fi.serial_no,"
				+  " fi.sensor_id,"
				+  " fi.measure_time,"
				+  " fi.upload_time,"
				+  " fi.zip_flg,"
				+  " fi.file_name,"
				+  " fi.hash,"
				+  " fi.sender_device_id,"
				+  " fi.notice_time,"
				+  " fi.reserve1,"
				+  " fi.reserve2,"
				+  " fi.reserve3,"
				+  " fi.reserve4,"
				+  " fi.reserve5,"
				+  " fi.other_metadata,"
				+  " fi.upload_user_id"
				+  " FROM std_fileinfo fi " ;

		if ( query.getMeasure_time() == null){
			String subQuery =
					 " ("
					+  " SELECT fi2.model_id,"
					+  "        fi2.serial_no,"
					+  "        fi2.sensor_id,"
					+  "        max(fi2.measure_time) measure_time"
					+  "   FROM  std_fileinfo fi2"
					+      this.buildCondition(query, "fi2.",params)
					+  "    group by  fi2.model_id, fi2.serial_no,fi2.sensor_id"
					+  "  ) sub";

			baseSql =  baseSql +  ", "  + subQuery
					+  " WHERE fi.model_id = sub.model_id "
					+  "    AND fi.serial_no = sub.serial_no "
					+  "    AND fi.sensor_id = sub.sensor_id"
					+  "    AND fi.measure_time = sub.measure_time" ;

		}else{
			String cond = this.buildCondition(query, "fi.",params);
			baseSql =  cond.length() == 0 ?baseSql + " WHERE 1=1 ": baseSql + cond;
		}

		//キー項目(model_id, serial_no, sensor_no)
		baseSql +=  this.buildConditionKeySet(sensorList, "fi.",params);



		boolean isNull = false;
		// ソート順が指定されている場合
		if(sort != null){
			baseSql = " SELECT * FROM (" + baseSql + ") b ORDER BY " + sort;
			isNull = true;
		}

		// ページングが指定されている場合
		if(limit != null && offset != null){
			// ソート順が指定されていない場合
			if(isNull == false){
				baseSql = " SELECT * FROM (" + baseSql + ") b"
						+ " ORDER BY model_id, serial_no, sensor_id, measure_time";
			}
			baseSql += " OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}

		Query q = em.createNativeQuery(baseSql, StdFileInfoEntity.class);

		//検索条件可変の部分のバイト
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		if(limit != null && offset != null){
			q.setParameter("offset", offset);
			q.setParameter("limit", limit);
		}

		@SuppressWarnings("unchecked")
		List<StdFileInfoEntity> list = q.getResultList();
		return list;
	}



	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildConditionKeySet(List<SensorModel3> sensorList, String tblNm, Map<String, Object> params) {
		StringBuffer where = new StringBuffer(" AND (");
		String[] cols ={"model_id", "serial_no", "sensor_id"};
		int i = 0;

		for (SensorModel3 sensor : sensorList) {
			if (where.length() > " AND (".length()) where.append(" OR ");
			where.append("(");
			for(String colName : cols){
				String bindName = colName + "_" + i;
				where.append(tblNm).append(colName).append("=").append(":").append(bindName);
				switch (colName){
				case "model_id":
					params.put(bindName, sensor.getModel_id());
					where.append( " AND ");
				break;
				case "serial_no":
					params.put(bindName, sensor.getSerial_no());
					where.append( " AND ");
				break;
				case "sensor_id":params.put(bindName, sensor.getSensor_id());
				break;
				}

			}
			i++;
			where.append(" ) ");
		}
		where.append(")");
		return where.toString();
	}

	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(SensorFileModel query, String tblNm, Map<String, Object> params) {
		StringBuffer where = new StringBuffer("");
		Object[] arr = null;

		if (query.getUpload_time() != null) {
			arr = Stream.of(query.getUpload_time()).map(StringUtil.String2Timestamp2).toArray();
			addCondition(where, params, tblNm + "upload_time", arr);
		}


		if (query.getZip_flg() != null) {
			arr = Stream.of(query.getZip_flg()).map(StringUtil.String2Boolean).toArray();
			addCondition(where, params, tblNm + "zip_flg", arr);
		}

		addCondition(where, params, tblNm + "file_name", query.getFile_name());
		addCondition(where, params, tblNm + "hash", query.getHash());
		addCondition(where, params, tblNm + "sender_device_id", query.getSender_device_id());
		if (query.getNotice_time() != null) {
			arr = Stream.of(query.getNotice_time()).map(StringUtil.String2Timestamp2).toArray();
			addCondition(where, params, tblNm + "notice_time", arr);
		}
		addCondition(where, params, tblNm + "reserve1", query.getReserve1());
		addCondition(where, params, tblNm + "reserve2", query.getReserve2());
		addCondition(where, params, tblNm + "reserve3", query.getReserve3());
		addCondition(where, params, tblNm + "reserve4", query.getReserve4());
		addCondition(where, params, tblNm + "reserve5", query.getReserve5());
		addCondition(where, params, tblNm + "other_metadata", query.getOther_metadata());
		addCondition(where, params, tblNm + "upload_user_id", query.getUpload_user_id());

		return where.length() == 0 ? "": " AND " + where.toString();
	}

	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(SensorLatestFileModel query, String tblNm, Map<String, Object> params) {
		StringBuffer where = new StringBuffer("");
		Object[] arr = null;

		if (query.getMeasure_time() != null) {
			arr = Stream.of(query.getMeasure_time()).map(StringUtil.String2Timestamp2).toArray();

			addCondition(where, params, tblNm + "measure_time", arr);
		}

		if (query.getUpload_time() != null) {
			arr = Stream.of(query.getUpload_time()).map(StringUtil.String2Timestamp2).toArray();
			addCondition(where, params, tblNm + "upload_time", arr);
		}


		if (query.getZip_flg() != null) {
			arr = Stream.of(query.getZip_flg()).map(StringUtil.String2Boolean).toArray();
			addCondition(where, params, tblNm + "zip_flg", arr);
		}

		addCondition(where, params, tblNm + "file_name", query.getFile_name());
		addCondition(where, params, tblNm + "hash", query.getHash());
		addCondition(where, params, tblNm + "sender_device_id", query.getSender_device_id());
		if (query.getNotice_time() != null) {
			arr = Stream.of(query.getNotice_time()).map(StringUtil.String2Timestamp2).toArray();
			addCondition(where, params, tblNm + "notice_time", arr);
		}
		addCondition(where, params, tblNm + "reserve1", query.getReserve1());
		addCondition(where, params, tblNm + "reserve2", query.getReserve2());
		addCondition(where, params, tblNm + "reserve3", query.getReserve3());
		addCondition(where, params, tblNm + "reserve4", query.getReserve4());
		addCondition(where, params, tblNm + "reserve5", query.getReserve5());
		addCondition(where, params, tblNm + "other_metadata", query.getOther_metadata());
		addCondition(where, params, tblNm + "upload_user_id", query.getUpload_user_id());

		return where.length() == 0 ? "": " WHERE " + where.toString();
	}

	/**
	 * WHERE句用検索条件追加
	 * 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0) return;
		if (where.length() > " AND ".length()) where.append(" AND ");
		where.append(col + " in (");
		for (int i = 0; i < values.length; i++) {
			String name = col + "_" + i;
			where.append(":").append(name).append(",");
			params.put(name, values[i]);
		}
		where.deleteCharAt(where.length()-1);
		where.append(")");
	}


}

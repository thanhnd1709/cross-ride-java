package com.app.repository;

import com.microsoft.azure.storage.blob.CloudBlobContainer;

/**
 * 日付別Blobファイルリポジトリクラス
 * @author（TOSCO）ウェイ
 */
public interface BlobDataRepositoryCustom{

	/**
	 * 日付別Blobファイルダウンロード処理を行います。
	 * @return 日付別Blobファイル
	 */
	String download(CloudBlobContainer container, String fileName, String filePath, String downloadDir)
			throws Exception;

	/**
	 * 日付別Blobファイルアップロード処理を行います。
	 */
	void upload(CloudBlobContainer container, String fileName, String filePath) throws Exception;
}

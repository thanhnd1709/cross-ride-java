package com.app.repository;

import java.util.Date;
import java.util.List;

import com.app.entity.StdNewMeasureDataEntity;

/**
 * 最新計測データリポジトリクラス
 * @author（TOSCO）ウェイ
 */
public interface StdNewMeasureDataRepositoryCustom{

	/**
	 * 最新計測データ取得処理を行います。
	 * @return 最新計測データ
	 */
	List<StdNewMeasureDataEntity> search(String modelId, String serialNo, String sensorId) throws Exception;

	/**
	 * 最新計測データのロック処理を行います。
	 * @return 最新計測データ
	 */
	List<StdNewMeasureDataEntity> lock(String modelId, String serialNo, String sensorId
													, Date dateFrom, Date dateTo) throws Exception;

	/**
	 * 最新計測データの更新処理を行います。
	 */
	void update(String modelId, String serialNo, String sensorId, Date dateFrom, Date dateTo
					, String measureTime, String measureData) throws Exception;
}
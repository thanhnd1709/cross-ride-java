package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstBaseDevconfigEntity;
import com.app.model.BaseDevconfigQueryModel;

public interface BaseDevconfigRepositoryCustom {
	List<MstBaseDevconfigEntity> findAll(BaseDevconfigQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(BaseDevconfigQueryModel query);

    MstBaseDevconfigEntity findOneForUpdate(@Param("id") int id);
}
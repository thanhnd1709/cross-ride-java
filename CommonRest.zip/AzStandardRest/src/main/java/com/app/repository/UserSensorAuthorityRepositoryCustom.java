package com.app.repository;

import java.util.List;

import com.app.entity.UserSensorAuthorityEntity;
import com.app.model.UserSensorAuthorityQueryModel;

/**
 * ユーザ・センサー権限情報カスタムリポジトリ
 * @author 9571
 *
 */
public interface UserSensorAuthorityRepositoryCustom {
	/**
	 * ユーザ・センサー権限情報検索
	 * @param query 検索条件オブジェクト
	 * @param sort ソート条件リスト
	 * @param limit 取得件数
	 * @param offset 取得開始オフセット値
	 * @return 検索結果リスト
	 */
	List<UserSensorAuthorityEntity> findAll(UserSensorAuthorityQueryModel query, List<String> sort, Integer limit, Integer offset);

	/**
	 * ユーザ・センサー権限情報件数取得
	 * @param query 検索条件オブジェクト
	 * @return 件数
	 */
	Long countAll(UserSensorAuthorityQueryModel query);
}
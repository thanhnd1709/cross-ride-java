package com.app.repository;

import java.util.List;

import com.app.entity.PostEventEntity;

public interface PostEventRepositoryCustom {
	List<PostEventEntity> eventAuthChk(List<String> modelList, String userId);
}

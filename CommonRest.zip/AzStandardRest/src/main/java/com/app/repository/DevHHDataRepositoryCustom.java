package com.app.repository;

import com.app.entity.DevHHDataEntity;
import com.app.entity.DevHourlyDataEntity;
import com.microsoft.azure.storage.table.CloudTable;

/**
 * 時間別計測データリポジトリクラス
 * @author（TOSCO）ウェイ
 */
public interface DevHHDataRepositoryCustom{

	/**
	 * 時間別計測データ（全データ）取得処理を行います。
	 * @return 時間別計測データ
	 */
	Iterable<DevHHDataEntity> searchAll(String partitionKey, String dateFrom, String dateTo, boolean hasMinSec,
			CloudTable cloudTable) throws Exception;

	/**
	 * 時間別計測データ（最初のデータ1件）取得処理を行います。
	 * @return 時間別計測データ
	 */
	DevHHDataEntity searchFirst(String partitionKey, String dateFrom, String dateTo, boolean hasMinSec,
			CloudTable cloudTable) throws Exception;

	/**
	 * 時間別計測データ（最後のデータ1件）取得処理を行います。
	 * @return 時間別計測データ
	 */
	DevHHDataEntity searchLast(String partitionKey, String dateFrom, String dateTo, boolean hasMinSec,
			CloudTable cloudTable) throws Exception;
	
	/**
	 * 時間別計測データ（全データ）取得処理を行います。
	 * @return 時間別計測データ
	 */
	Iterable<DevHourlyDataEntity> searchAllHourlyData(String partitionKey, String dateFrom, String dateTo, boolean hasMinSec,
			CloudTable cloudTable) throws Exception;
}
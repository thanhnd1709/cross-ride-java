package com.app.repository.impl;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.UserSensorAuthorityEntity;
import com.app.model.UserSensorAuthorityQueryModel;
import com.app.repository.UserSensorAuthorityRepositoryCustom;

/**
 * ユーザ・センサー権限情報取得リポジトリクラス
 * @author 9571
 *
 */
@Component
public class UserSensorAuthorityRepositoryImpl implements UserSensorAuthorityRepositoryCustom {

	private static final String SELECT_COUNT_STR = "SELECT count(*) FROM ";

	private static final String SELECT_STR = "SELECT row_number() over(ORDER BY (SELECT NULL) ASC) as id, tmp.* FROM ";

	private static final String SELECT_ALL_STR =
					"SELECT DISTINCT " +
					"s.model_id as model_id, "+
					"s.serial_no as serial_no, "+
					"s.sensor_id as sensor_id, "+
					"s.sensor_type as sensor_type, "+
					"s.name_locale1 as sensor_name_locale1, "+
					"s.name_locale2 as sensor_name_locale2, "+
					"s.name_locale3 as sensor_name_locale3, "+
					"s.unit_locale1 as unit_locale1, "+
					"s.unit_locale2 as unit_locale2, "+
					"s.unit_locale3 as unit_locale3, "+
					"s.transform_locale1 as transform_locale1, "+
					"s.transform_locale2 as transform_locale2, "+
					"s.transform_locale3 as transform_locale3, "+
					"s.decimal_num_locale1 as decimal_num_locale1, "+
					"s.decimal_num_locale1 as decimal_num_locale2, "+
					"s.decimal_num_locale3 as decimal_num_locale3, "+
					"s.max_value_locale1 as max_value_locale1, "+
					"s.max_value_locale2 as max_value_locale2, "+
					"s.max_value_locale3 as max_value_locale3, "+
					"s.min_value_locale1 as min_value_locale1, "+
					"s.min_value_locale2 as min_value_locale2, "+
					"s.min_value_locale3 as min_value_locale3, "+
					"s.description_locale1 as sensor_description_locale1, "+
					"s.description_locale2 as sensor_description_locale2, "+
					"s.description_locale3 as sensor_description_locale3, "+
					"s.measure_type as measure_type, "+
					"s.data_type as data_type, "+
					"s.fixed_length as fixed_length, "+
					"s.time_data_create_flg as time_data_create_flg, "+
					"s.short_term_minutes as short_term_minutes, "+
					"s.note as sensor_note, "+
					"gl.device_group_id as device_group_id, " +
					"gl.device_group_type as device_group_type, " +
					"gl.device_group_subtype as device_group_subtype, " +
					"gl.device_group_name_locale1 as device_group_name_locale1, " +
					"gl.device_group_name_locale2 as device_group_name_locale2, " +
					"gl.device_group_name_locale3 as device_group_name_locale3, " +
					"gl.device_group_description_locale1 as device_group_description_locale1, " +
					"gl.device_group_description_locale2 as device_group_description_locale2, " +
					"gl.device_group_description_locale3 as device_group_description_locale3,  " +
					"gl.parent_device_group_id as parent_device_group_id, " +
					"gl.setup_place as setup_place, " +
					"gl.setup_status as setup_status, " +
					"gl.latitude as latitude, " +
					"gl.longitude as longitude, " +
					"gl.device_group_note as device_group_note, " +
					"gl.role_id as role_id, " +
					"gl.root_group_id as root_group_id, " +
					"gl.role_name_locale1 as role_name_locale1, " +
					"gl.role_name_locale2 as role_name_locale2,  " +
					"gl.role_name_locale3 as role_name_locale3, " +
					"gl.role_description_locale1 as role_description_locale1, " +
					"gl.role_description_locale2 as role_description_locale2, " +
					"gl.role_description_locale3 as role_description_locale3, " +
					"gl.role_note as role_note, " +
					"gl.hierarchy as hierarchy ";

	private static final String FROM_STR = " FROM dbo.fn_UserDeviceGroup(:user_id, :url, :method) gl, "
											+ "mst_sensor s, "
											+ "mst_group_composition_device gcd ";
	private static final String FROM_ALL_STR = " FROM dbo.fn_UserDeviceGroup(:user_id, default, default) gl, "
												+ "mst_sensor s, "
												+ "mst_group_composition_device gcd ";
	private static final String WHERE_STR = " WHERE s.model_id = gcd.model_id "
											 + "AND s.serial_no = gcd.serial_no "
											 + "AND gcd.device_group_id = gl.device_group_id "
											 + "AND NOT EXISTS (SELECT 1 FROM mst_role_sensor_visual rv "
											 + "WHERE rv.role_id = gl.role_id "
											 + "AND rv.model_id = gcd.model_id "
											 + "AND rv.serial_no = gcd.serial_no "
											 + "AND rv.sensor_id = s.sensor_id "
											 + "AND rv.visual_auth_flg = 0) ";
	@Autowired EntityManager em;
	/**
	 * ユーザ・センサー権限情報取得検索
	 * @param query 検索条件オブジェクト
	 * @param sort ソート条件リスト
	 * @param limit 取得件数
	 * @param offset 取得開始オフセット値
	 * @return 検索結果リスト
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<UserSensorAuthorityEntity> findAll(UserSensorAuthorityQueryModel query, List<String> sort,
			Integer limit, Integer offset) {

		StringBuffer orderBy = new StringBuffer();
		if (sort.size() > 0) {
			orderBy.append(" ORDER BY ");
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderBy.append(col.substring(1) + " desc,");
				} else {
					orderBy.append(col + " asc,");
				}
			}
			orderBy.deleteCharAt(orderBy.length() - 1);
		}

		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_STR + "(" + buildSubQuery(query, params) +orderBy.toString() + ") as tmp ";
		if(limit == null && offset == null){
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + ") as tmp"+ orderBy.toString();
		}else{
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + orderBy.toString() + ") as tmp";
		}

		Query qry = em.createNativeQuery(sql, UserSensorAuthorityEntity.class);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			qry.setParameter(key, params.get(key));
		}
		if (offset != null) qry.setFirstResult(offset);
		if (limit != null) qry.setMaxResults(limit);

		return  qry.getResultList();
	}

	/**
	 * ユーザ・センサー権限情件数取得
	 * @param query 検索条件オブジェクト
	 * @return 件数
	 */
	@Override
	public Long countAll(UserSensorAuthorityQueryModel query) {

		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_COUNT_STR + "(" + buildSubQuery(query, params) + ") as tmp";

		Query qry = em.createNativeQuery(sql);
		Set<String> keys = params.keySet();
		for(String key : keys ){
			qry.setParameter(key, params.get(key));
		}
		return ((Integer) qry.getSingleResult()).longValue();
	}

	/**
	 * サブクエリ作成
	 * @param query
	 * @param params
	 * @return
	 */
	private String buildSubQuery(UserSensorAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer sql = new StringBuffer();

		if(query.getFields() == null){
			sql.append(SELECT_ALL_STR);
		} else {
			sql.append("SELECT DISTINCT ");

			// INパラメータのfieldsで指定された項目以外のカラムはnull固定値を取得する
			List<String> list = Arrays.asList(query.getFields().split(","));
			Field[] fields = UserSensorAuthorityEntity.class.getDeclaredFields();

			int idx = 0;
			for (Field f : fields) {
				idx++;
				if ("id".equals(f.getName())) {
					// idは親クエリのrow_numberで取得するため除外する。
					continue;
				}
				String item = list.contains(f.getName()) ? f.getName() : "null";
				if (!item.equals("null")) {
					item = buildSelect(item);
					if (idx <= 32)
						sql.append("s." + item + " as " + f.getName() + ",");
					if (idx > 32)
						sql.append("gl." + item + " as " + f.getName() + ",");
				}else{
					sql.append(item + " as " + f.getName() + ",");
				}
			}
			sql.deleteCharAt(sql.length() - 1); // 末端の,を削除
		}
		params.put("user_id", query.getUser_id());
		if (StringUtil.IsNullOrEmpty(query.getUrl())) {
			sql.append(FROM_ALL_STR);
		} else {
			sql.append(FROM_STR);
			params.put("url", query.getUrl());
			params.put("method", query.getMethod());
		}
		// WHERE句作成
		String where = buildCondition(query, params);
		sql.append(where);

		return sql.toString();
	}

	/**
	 * SELLECT変数を作成する。
	 * @param item 変数
	 * @return item 変数
	 */
	private String buildSelect(String item) {
		if(item.equals("sensor_name_locale1")) item = "name_locale1";
		if(item.equals("sensor_name_locale2")) item = "name_locale2";
		if(item.equals("sensor_name_locale3")) item = "name_locale3";
		if(item.equals("sensor_description_locale1")) item = "description_locale1";
		if(item.equals("sensor_description_locale2")) item = "description_locale2";
		if(item.equals("sensor_description_locale3")) item = "description_locale3";
		if(item.equals("sensor_note")) item = "note";
		return item;
	}

	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(UserSensorAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer where = new StringBuffer(WHERE_STR);
		Object[] arr = null;
		addCondition(where, params, "s.model_id", query.getModel_id());
		addCondition(where, params, "s.serial_no", query.getSerial_no());
		addCondition(where, params, "s.sensor_id", query.getSensor_id());
		addCondition(where, params, "s.sensor_type", query.getSensor_type());
		addCondition(where, params, "s.name_locale1", query.getSensor_name_locale1());
		addCondition(where, params, "s.name_locale2", query.getSensor_name_locale2());
		addCondition(where, params, "s.name_locale3", query.getSensor_name_locale3());
		addCondition(where, params, "s.unit_locale1", query.getUnit_locale1());
		addCondition(where, params, "s.unit_locale2", query.getUnit_locale2());
		addCondition(where, params, "s.unit_locale3", query.getUnit_locale3());
		addCondition(where, params, "s.transform_locale1", query.getTransform_locale1());
		addCondition(where, params, "s.transform_locale2", query.getTransform_locale2());
		addCondition(where, params, "s.transform_locale3", query.getTransform_locale3());
		if (query.getDecimal_num_locale1() != null) {
			arr = Stream.of(query.getDecimal_num_locale1()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "s.decimal_num_locale1", arr);
		}
		if (query.getDecimal_num_locale2() != null) {
			arr = Stream.of(query.getDecimal_num_locale2()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "s.decimal_num_locale2", arr);
		}
		if (query.getDecimal_num_locale3() != null) {
			arr = Stream.of(query.getDecimal_num_locale3()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "s.decimal_num_locale3", arr);
		}
		if (query.getMax_value_locale1() != null) {
			arr = Stream.of(query.getMax_value_locale1()).map(StringUtil.String2Double).toArray();
			addCondition(where, params, "s.max_value_locale1", arr);
		}
		if (query.getMax_value_locale2() != null) {
			arr = Stream.of(query.getMax_value_locale2()).map(StringUtil.String2Double).toArray();
			addCondition(where, params, "s.max_value_locale2", arr);
		}
		if (query.getMax_value_locale3() != null) {
			arr = Stream.of(query.getMax_value_locale3()).map(StringUtil.String2Double).toArray();
			addCondition(where, params, "s.max_value_locale3", arr);
		}
		if (query.getMin_value_locale1() != null) {
			arr = Stream.of(query.getMin_value_locale1()).map(StringUtil.String2Double).toArray();
			addCondition(where, params, "s.min_value_locale1", arr);
		}
		if (query.getMin_value_locale2() != null) {
			arr = Stream.of(query.getMin_value_locale2()).map(StringUtil.String2Double).toArray();
			addCondition(where, params, "s.min_value_locale2", arr);
		}
		if (query.getMin_value_locale3() != null) {
			arr = Stream.of(query.getMin_value_locale3()).map(StringUtil.String2Double).toArray();
			addCondition(where, params, "s.min_value_locale3", arr);
		}
		addCondition(where, params, "s.description_locale1", query.getSensor_description_locale1());
		addCondition(where, params, "s.description_locale2", query.getSensor_description_locale2());
		addCondition(where, params, "s.description_locale3", query.getSensor_description_locale3());
		addCondition(where, params, "s.measure_type", query.getMeasure_type());
		addCondition(where, params, "s.data_type", query.getData_type());
		if(query.getFixed_length() != null ){
			arr = Stream.of(query.getFixed_length()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "s.fixed_length", arr);
		}
		if(query.getTime_data_create_flg() != null ){
			arr = Stream.of(query.getTime_data_create_flg()).map(StringUtil.String2Boolean).toArray();
			addCondition(where, params, "s.time_data_create_flg", arr);
		}
		if(query.getShort_term_minutes() != null ){
			arr = Stream.of(query.getShort_term_minutes()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "s.short_term_minutes", arr);
		}
		addCondition(where, params, "s.note", query.getSensor_note());
		addCondition(where, params, "gl.device_group_id", query.getDevice_group_id());
		addCondition(where, params, "gl.device_group_type", query.getDevice_group_type());
		addCondition(where, params, "gl.device_group_subtype", query.getDevice_group_subtype());
		addCondition(where, params, "gl.device_group_name_locale1", query.getDevice_group_name_locale1());
		addCondition(where, params, "gl.device_group_name_locale2", query.getDevice_group_name_locale2());
		addCondition(where, params, "gl.device_group_name_locale3", query.getDevice_group_name_locale3());
		addCondition(where, params, "gl.device_group_description_locale1", query.getDevice_group_description_locale1());
		addCondition(where, params, "gl.device_group_description_locale2", query.getDevice_group_description_locale2());
		addCondition(where, params, "gl.device_group_description_locale3", query.getDevice_group_description_locale3());
		addCondition(where, params, "gl.parent_device_group_id", query.getParent_device_group_id());
		addCondition(where, params, "gl.setup_place", query.getSetup_place());
		addCondition(where, params, "gl.setup_status", query.getSetup_status());
		if (query.getLatitude() != null) {
			arr = Stream.of(query.getLatitude()).map(StringUtil.String2BigDecimal).toArray();
			addCondition(where, params, "gl.latitude", arr);
		}
		if (query.getLongitude() != null) {
			arr = Stream.of(query.getLongitude()).map(StringUtil.String2BigDecimal).toArray();
			addCondition(where, params, "gl.longitude", arr);
		}
		addCondition(where, params, "gl.device_group_note", query.getDevice_group_note());
		addCondition(where, params, "gl.role_id", query.getRole_id());
		addCondition(where, params, "gl.root_group_id", query.getRoot_group_id());
		addCondition(where, params, "gl.role_name_locale1", query.getRole_name_locale1());
		addCondition(where, params, "gl.role_name_locale2", query.getRole_name_locale2());
		addCondition(where, params, "gl.role_name_locale3", query.getRole_name_locale3());
		addCondition(where, params, "gl.role_description_locale1", query.getRole_description_locale1());
		addCondition(where, params, "gl.role_description_locale2", query.getRole_description_locale2());
		addCondition(where, params, "gl.role_description_locale3", query.getRole_description_locale3());
		addCondition(where, params, "gl.role_note", query.getRole_note());
		if (query.getHierarchy() != null && query.getHierarchy().length > 0) {
			arr = Stream.of(query.getHierarchy()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "gl.hierarchy", arr);
		}
		return where.toString();
	}

	/**
	 * WHERE句用検索条件追加
	 * 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {

		if (values == null || values.length == 0) return;
		where.append(" AND ");

		boolean isValue= false;
		int i= 0;

		if (col.equals("s.name_locale1") || col.equals("s.name_locale2") || col.equals("s.name_locale3")
				|| col.equals("s.description_locale1") || col.equals("s.description_locale2")
				|| col.equals("s.description_locale3") || col.equals("s.note")) {
			where.append("(");
			for (i = 0; i < values.length; i++) {
				if (isValue) where.append(" or ");
				String name = col + "_" + i;
				where.append(col).append(" like :").append(name);
				params.put(name, values[i]);
				isValue = true;
			}
			where.append(")");
		} else {
			where.append(col + " in (");
			for (i = 0; i < values.length; i++) {
				String name = col + "_" + i;
				where.append(":").append(name).append(",");
				params.put(name, values[i]);
			}
			where.deleteCharAt(where.length() - 1);
			where.append(")");
		}
	}
}
package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstRoleRootGroupEntity;
import com.app.model.RoleRootGroupQueryModel;

public interface RoleRootGroupRepositoryCustom {
	public List<MstRoleRootGroupEntity> findAll(RoleRootGroupQueryModel query, List<String> sort, Integer limit, Integer offset);
	public Long countAll(RoleRootGroupQueryModel query);

    public MstRoleRootGroupEntity findOneForUpdate(@Param("id") int id);
}
package com.app.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.DeviceGroupStructureEntity;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.DeviceGroupStructureModel;
import com.app.repository.DeviceGroupStructureRepositoryCustom;

/**
 * 11.4.1.	デバイスグループ階層情報取得リポジトリ実装クラス
 * @author（TOSCO）エー
 */
@Component
public class DeviceGroupStructureRepositoryCustomImpl implements DeviceGroupStructureRepositoryCustom {

	@Autowired EntityManager em;
	@Autowired AuthUserInfoComponent authUserInfo;

	@Override
	public List<DeviceGroupStructureEntity> getDeviceGroupStructure(DeviceGroupStructureModel model, String sort,Integer limit,Integer offset) {

		String sql = "WITH device_group_structure (parent_device_group_list, level, device_group_id) AS ( "
				+ "SELECT CONVERT(nvarchar(2000), '') AS parent_device_group_list, "
					+ "1 AS Level,  device_group_id "
					+ "FROM mst_device_group mf "
					+ "WHERE device_group_id = (:deviceGroupId) "
					+ "AND dbo.fn_DeviceGroupAuthChk(mf.device_group_id, (:userId), default, default) = 1 "
					+ "UNION ALL "
						+ "SELECT CONVERT(nvarchar(2000), fs.parent_device_group_list + "
						+ "(CASE level WHEN 1 THEN '' ELSE char(9) END) + fs.device_group_id) "
						+ "AS parent_device_group_list, level + 1 AS level,  mf.device_group_id "
						+ "FROM device_group_structure fs "
						+ "INNER JOIN mst_device_group mf "
				        + "ON fs.device_group_id = mf.parent_device_group_id "
				        + "AND fs.level < (:level) "
				        + "AND dbo.fn_DeviceGroupAuthChk(mf.device_group_id, (:userId), default, default) = 1) "
						+ "SELECT * FROM device_group_structure fs ";
		if (model.getGet_class().equals("2")) {
			sql += "WHERE fs.level = (:level)  OR NOT EXISTS "
					+ "(SELECT 1 FROM mst_device_group mf "
					+ "WHERE fs.device_group_id = mf.parent_device_group_id) ";
		} else if (model.getGet_class().equals("3")) {
			sql += "WHERE EXISTS "
					+ "(SELECT 1 FROM mst_group_composition_device mfd "
					+ "WHERE fs.device_group_id = mfd.device_group_id) ";
		}

		boolean isNull = false;
		if(sort != null){
			sql = sql + " ORDER BY " + sort;
			isNull = true;
		}
		if (limit != null && offset != null) {
			if(isNull == false){
				sql =  sql + " ORDER BY parent_device_group_list, level, device_group_id";
			}
			sql += " OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}

		Query qry = em.createNativeQuery(sql, DeviceGroupStructureEntity.class);

		// ユーザID設定
		qry.setParameter("userId", authUserInfo.getPrincipalName());
		// デバイスグループID設定
		qry.setParameter("deviceGroupId", model.getDevice_group_id());
		//階層数の設定
		qry.setParameter("level", model.getLevel());

		// limitとoffsetの設定
		if (limit != null && offset != null) {
			qry.setParameter("limit", limit);
			qry.setParameter("offset", offset);
		}

		@SuppressWarnings("unchecked")
		List<DeviceGroupStructureEntity> list = qry.getResultList();

		return list;
	}
}

package com.app.repository.impl;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.UserDeviceAuthorityEntity;
import com.app.model.UserDeviceAuthorityQueryModel;
import com.app.repository.UserDeviceAuthorityRepositoryCustom;

/**
 * ユーザ・デバイス権限情報リポジトリクラス
 * 
 * @author 1572
 *
 */
@Component
public class UserDeviceAuthorityRepositoryImpl implements UserDeviceAuthorityRepositoryCustom {
	private static final String SELECT_COUNT_STR = "SELECT count(*) FROM ";
	private static final String SELECT_STR = "SELECT row_number() over(ORDER BY (SELECT NULL) ASC) as id, tmp.* FROM ";
	private static final String SELECT_ALL_STR = "SELECT DISTINCT " + "d.model_id as model_id, "
			+ "d.serial_no as serial_no, " + "d.device_type as device_type, " + "d.iot_device_flg as iot_device_flg, "
			+ "d.communication_flg as communication_flg, " + "d.name_locale1 as device_name_locale1, "
			+ "d.name_locale2 as device_name_locale2, " + "d.name_locale3 as device_name_locale3, "
			+ "d.description_locale1 as device_description_locale1, "
			+ "d.description_locale2 as device_description_locale2, "
			+ "d.description_locale3 as device_description_locale3, " + "d.maker_code as maker_code, "
			+ "d.parent_model_id as parent_model_id, " + "d.parent_serial_no as parent_serial_no, "
			+ "d.setup_place as setup_place, " + "d.setup_status as setup_status, " + "d.time_zone as time_zone, "
			+ "d.latitude as latitude, " + "d.longitude as longitude, " + "d.device_mode as device_mode, "
			+ "d.unreceive_seconds as unreceive_seconds, " + "d.note as device_note, "
			+ "gl.device_group_id as device_group_id, " + "gl.device_group_type as device_group_type, "
			+ "gl.device_group_subtype as device_group_subtype, "
			+ "gl.device_group_name_locale1 as device_group_name_locale1, "
			+ "gl.device_group_name_locale2 as device_group_name_locale2, "
			+ "gl.device_group_name_locale3 as device_group_name_locale3, "
			+ "gl.device_group_description_locale1 as device_group_description_locale1, "
			+ "gl.device_group_description_locale2 as device_group_description_locale2, "
			+ "gl.device_group_description_locale3 as device_group_description_locale3, "
			+ "gl.parent_device_group_id as parent_device_group_id, " + "gl.device_group_note as device_group_note, "
			+ "gl.role_id as role_id, " + "gl.root_group_id as root_group_id, "
			+ "gl.role_name_locale1 as role_name_locale1, " + "gl.role_name_locale2 as role_name_locale2, "
			+ "gl.role_name_locale3 as role_name_locale3, "
			+ "gl.role_description_locale1 as role_description_locale1, "
			+ "gl.role_description_locale2 as role_description_locale2, "
			+ "gl.role_description_locale3 as role_description_locale3, " + "gl.role_note as role_note, "
			+ "gl.hierarchy as hierarchy ";
	private static final String FROM_STR = " FROM mst_device d "
			+ " INNER JOIN mst_group_composition_device gcd ON d.model_id = gcd.model_id AND d.serial_no = gcd.serial_no "
			+ " INNER JOIN dbo.fn_UserDeviceGroup(:user_id, :url, :method) gl ON gcd.device_group_id = gl.device_group_id ";
	private static final String FROM_STR_2 = " FROM mst_device d "
			+ " INNER JOIN mst_group_composition_device gcd ON d.model_id = gcd.model_id AND d.serial_no = gcd.serial_no "
			+ " INNER JOIN dbo.fn_UserDeviceGroup(:user_id, default, default) gl ON gcd.device_group_id = gl.device_group_id ";

	private static final String WHERE_STR = " WHERE ";

	@Autowired
	EntityManager em;

	/**
	 * ユーザ・デバイス権限情報件数取得
	 * 
	 * @param query
	 *            検索条件オブジェクト
	 * @return 件数
	 */
	@Override
	public Long countAll(UserDeviceAuthorityQueryModel query) {
		// SELECT文作成
		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_COUNT_STR + "(" + buildSubQuery(query, params) + ") as tmp";

		// クエリ作成
		Query q = em.createNativeQuery(sql);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// クエリ実行
		return ((Integer) q.getSingleResult()).longValue();
	}

	/**
	 * ユーザ・デバイス権限情報検索
	 * 
	 * @param query
	 *            検索条件オブジェクト
	 * @param sort
	 *            ソート条件リスト
	 * @param limit
	 *            取得件数
	 * @param offset
	 *            取得開始オフセット値
	 * @return 検索結果リスト
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<UserDeviceAuthorityEntity> findAll(UserDeviceAuthorityQueryModel query, List<String> sort,
			Integer limit, Integer offset) {
		// ORDER BY句作成
		StringBuffer orderBy = new StringBuffer();
		if (sort.size() > 0) {
			orderBy.append(" ORDER BY ");
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderBy.append(col.substring(1) + " desc,");
				} else {
					orderBy.append(col + " asc,");
				}
			}
			orderBy.deleteCharAt(orderBy.length() - 1);
		}

		// SELECT文作成
		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_STR + "(" + buildSubQuery(query, params) + orderBy.toString() + ") as tmp";
		if (offset == null && limit == null) {
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + ") as tmp " + orderBy.toString();
		} else {
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + orderBy.toString() + ") as tmp";
		}

		// クエリ作成
		Query q = em.createNativeQuery(sql, UserDeviceAuthorityEntity.class);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// ページング設定
		if (offset != null)
			q.setFirstResult(offset);
		if (limit != null)
			q.setMaxResults(limit);

		// クエリ実行
		return q.getResultList();
	}

	/**
	 * サブクエリ作成
	 * @param query
	 * @param params
	 * @return
	 */
	private String buildSubQuery(UserDeviceAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer sql = new StringBuffer();

		if(query.getFields() == null){
			sql.append(SELECT_ALL_STR);
		} else {
			sql.append("SELECT DISTINCT ");

			// INパラメータのfieldsで指定された項目以外のカラムはnull固定値を取得する
			List<String> list = Arrays.asList(query.getFields().split(","));
			Field[] fields = UserDeviceAuthorityEntity.class.getDeclaredFields();
			for (Field f : fields) {
				if ("id".equals(f.getName())) {
					// idは親クエリのrow_numberで取得するため除外する。
					continue;
				}

				String item = "";
				if(list.contains(f.getName())){
					item = f.getName();
					if (item == "model_id" ||
							item == "serial_no" ||
							item == "device_type" ||
							item == "iot_device_flg" ||
							item == "communication_flg" ||
							item == "maker_code" ||
							item == "parent_model_id" ||
							item == "parent_serial_no" ||
							item == "setup_place" ||
							item == "setup_status" ||
							item == "time_zone" ||
							item == "latitude" ||
							item == "longitude" ||
							item == "device_mode" ||
							item == "unreceive_seconds"){
						item = "d." + item;
					}else if(item == "device_group_id" ||
							item == "device_group_type" ||
							item == "device_group_subtype" ||
							item == "device_group_name_locale1" ||
							item == "device_group_name_locale2" ||
							item == "device_group_name_locale3" ||
							item == "device_group_description_locale1" ||
							item == "device_group_description_locale2" ||
							item == "device_group_description_locale3" ||
							item == "parent_device_group_id" ||
							item == "device_group_note" ||
							item == "role_id" ||
							item == "root_group_id" ||
							item == "role_name_locale1" ||
							item == "role_name_locale2" ||
							item == "role_name_locale3" ||
							item == "role_description_locale1" ||
							item == "role_description_locale2" ||
							item == "role_description_locale3" ||
							item == "role_note" ||
							item == "hierarchy "){
						item = "gl." + item;
						}
						else if(item == "device_name_locale1"){ item = "d.name_locale1";}
						else if(item == "device_name_locale2"){ item = "d.name_locale2";}
						else if(item == "device_name_locale3"){ item = "d.name_locale3";}
						else if(item == "device_description_locale1"){ item = "d.description_locale1";}
						else if(item == "device_description_locale2"){ item = "d.description_locale2";}
						else if(item == "device_description_locale3"){ item = "d.description_locale3";}
						else if(item == "device_note"){ item = "d.note";}
				}
				else{
					item = "null";
				}
//				String item = list.contains(f.getName()) ? f.getName() : "null";
				sql.append(item + " as " + f.getName() + ",");
			}
			sql.deleteCharAt(sql.length()-1);	// 末端の,を削除
		}

		params.put("user_id", query.getUser_id());
		if (StringUtil.IsNullOrEmpty(query.getUrl())) {
			sql.append(FROM_STR_2);
		} else {
			sql.append(FROM_STR);
			params.put("url", query.getUrl());
			params.put("method", query.getMethod());
		}

		// WHERE句作成
		String where = buildCondition(query, params);
		sql.append(where);

		return sql.toString();
	}

	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * 
	 * @param query
	 *            検索条件オブジェクト
	 * @param params
	 *            バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(UserDeviceAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer where = new StringBuffer(WHERE_STR);
		Object[] arr = null;

		addCondition(where, params, "d.model_id", query.getModel_id());
		addCondition(where, params, "d.serial_no", query.getSerial_no());
		addCondition(where, params, "d.device_type", query.getDevice_type());

		if (query.getIot_device_flg() != null) {
			arr = Stream.of(query.getIot_device_flg()).map(StringUtil.String2Boolean).toArray();
			addCondition(where, params, "d.iot_device_flg", arr);
		}

		if (query.getCommunication_flg() != null) {
			arr = Stream.of(query.getCommunication_flg()).map(StringUtil.String2Boolean).toArray();
			addCondition(where, params, "d.communication_flg", arr);
		}

		addPartialMatchCondition(where, params, "d.name_locale1", query.getDevice_name_locale1());
		addPartialMatchCondition(where, params, "d.name_locale2", query.getDevice_name_locale2());
		addPartialMatchCondition(where, params, "d.name_locale3", query.getDevice_name_locale3());
		addPartialMatchCondition(where, params, "d.description_locale1", query.getDevice_description_locale1());
		addPartialMatchCondition(where, params, "d.description_locale2", query.getDevice_description_locale2());
		addPartialMatchCondition(where, params, "d.description_locale3", query.getDevice_description_locale3());
		addCondition(where, params, "d.maker_code", query.getMaker_code());
		addCondition(where, params, "d.parent_model_id", query.getParent_model_id());
		addCondition(where, params, "d.parent_serial_no", query.getParent_serial_no());
		addPartialMatchCondition(where, params, "d.setup_place", query.getSetup_place());
		addCondition(where, params, "d.setup_status", query.getSetup_status());
		addCondition(where, params, "d.time_zone", query.getTime_zone());

		if (query.getLatitude() != null) {
			arr = Stream.of(query.getLatitude()).map(StringUtil.String2BigDecimal).toArray();
			addCondition(where, params, "d.latitude", arr);
		}

		if (query.getLongitude() != null) {
			arr = Stream.of(query.getLongitude()).map(StringUtil.String2BigDecimal).toArray();
			addCondition(where, params, "d.longitude", arr);
		}

		addCondition(where, params, "d.device_mode", query.getDevice_mode());

		if (query.getUnreceive_seconds() != null) {
			arr = Stream.of(query.getUnreceive_seconds()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "d.unreceive_seconds", arr);
		}

		addPartialMatchCondition(where, params, "d.note", query.getDevice_note());
		addCondition(where, params, "gl.device_group_id", query.getDevice_group_id());
		addCondition(where, params, "gl.device_group_type", query.getDevice_group_type());
		addCondition(where, params, "gl.device_group_subtype", query.getDevice_group_subtype());
		addPartialMatchCondition(where, params, "gl.device_group_name_locale1", query.getDevice_group_name_locale1());
		addPartialMatchCondition(where, params, "gl.device_group_name_locale2", query.getDevice_group_name_locale2());
		addPartialMatchCondition(where, params, "gl.device_group_name_locale3", query.getDevice_group_name_locale3());
		addPartialMatchCondition(where, params, "gl.device_group_description_locale1",
				query.getDevice_group_description_locale1());
		addPartialMatchCondition(where, params, "gl.device_group_description_locale2",
				query.getDevice_group_description_locale2());
		addPartialMatchCondition(where, params, "gl.device_group_description_locale3",
				query.getDevice_group_description_locale3());
		addCondition(where, params, "gl.parent_device_group_id", query.getParent_device_group_id());
		addPartialMatchCondition(where, params, "gl.device_group_note", query.getDevice_group_note());
		addCondition(where, params, "gl.role_id", query.getRole_id());
		addCondition(where, params, "gl.root_group_id", query.getRoot_group_id());
		addCondition(where, params, "gl.role_name_locale1", query.getRole_name_locale1());
		addCondition(where, params, "gl.role_name_locale2", query.getRole_name_locale2());
		addCondition(where, params, "gl.role_name_locale3", query.getRole_name_locale3());
		addCondition(where, params, "gl.role_description_locale1", query.getRole_description_locale1());
		addCondition(where, params, "gl.role_description_locale2", query.getRole_description_locale2());
		addCondition(where, params, "gl.role_description_locale3", query.getRole_description_locale3());
		addCondition(where, params, "gl.role_note", query.getRole_note());
		if (query.getHierarchy() != null && query.getHierarchy().length > 0) {
			arr = Stream.of(query.getHierarchy()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "hierarchy", arr);
		}

		String ret = where.toString();
		return (ret.equals(WHERE_STR) ? "" : ret);
	}

	/**
	 * WHERE句用検索条件追加 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。 paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * 
	 * @param where
	 *            WHERE句文字列
	 * @param params
	 *            バインド変数KVオブジェクト（返却用）
	 * @param col
	 *            検索条件列名
	 * @param values
	 *            検索条件値配列
	 */
	private void addCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0)
			return;
		if (where.length() > WHERE_STR.length())
			where.append(" AND ");
		where.append(col + " in (");
		for (int i = 0; i < values.length; i++) {
			String name = col + "_" + i;
			where.append(":").append(name).append(",");
			params.put(name, values[i]);
		}
		where.deleteCharAt(where.length() - 1);
		where.append(")");
	}

	/**
	 * WHERE句用部分一致検索条件追加 引数のwhere句文字列にAND (列名 like バインド変数 OR ...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。 paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * 
	 * @param where
	 *            WHERE句文字列
	 * @param params
	 *            バインド変数KVオブジェクト（返却用）
	 * @param col
	 *            検索条件列名
	 * @param values
	 *            検索条件値配列
	 */
	private void addPartialMatchCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0)
			return;
		if (where.length() > WHERE_STR.length())
			where.append(" AND ");
		where.append("(");
		for (int i = 0; i < values.length; i++) {
			if (i > 0)
				where.append(" OR ");

			String name = col + "_" + i;
			where.append(col).append(" like :").append(name);
			params.put(name, values[i]);
		}
		where.append(")");
	}

	/**
	 * WHERE句用検索条件追加 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。 paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * 
	 * @param where
	 *            WHERE句文字列
	 * @param params
	 *            バインド変数KVオブジェクト（返却用）
	 * @param col
	 *            検索条件列名
	 * @param values
	 *            検索条件値配列
	 */
	private void buildFields(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0)
			return;
		if (where.length() > WHERE_STR.length())
			where.append(" AND ");
		where.append(col + " in (");
		for (int i = 0; i < values.length; i++) {
			String name = col + "_" + i;
			where.append(":").append(name).append(",");
			params.put(name, values[i]);
		}
		where.deleteCharAt(where.length() - 1);
		where.append(")");
	}
}
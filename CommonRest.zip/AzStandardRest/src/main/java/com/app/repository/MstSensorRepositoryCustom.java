package com.app.repository;

import java.util.List;

import com.app.entity.MstSensorEntity;

public interface MstSensorRepositoryCustom {

	List<MstSensorEntity> find(String modelId, String serialNo, String sensorId, char measureType);
}

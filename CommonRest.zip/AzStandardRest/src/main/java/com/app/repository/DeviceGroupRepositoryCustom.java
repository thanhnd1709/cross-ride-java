package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstDeviceGroupEntity;
import com.app.model.DeviceGroupQueryModel;

public interface DeviceGroupRepositoryCustom {
	public List<MstDeviceGroupEntity> findAll(DeviceGroupQueryModel query, List<String> sort, Integer limit, Integer offset);
	public Long countAll(DeviceGroupQueryModel query);

	public MstDeviceGroupEntity findOneForUpdate(@Param("id") int id);
	public List<MstDeviceGroupEntity> getTopParentDeviceGroup(MstDeviceGroupEntity deviceGroup);
	public int getCirculationReference(MstDeviceGroupEntity deviceGroup);
}
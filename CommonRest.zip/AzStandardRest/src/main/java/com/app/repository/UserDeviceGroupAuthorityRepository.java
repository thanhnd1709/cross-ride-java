package com.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entity.UserDeviceGroupAuthorityEntity;

/**
 * ユーザ・デバイスグループ権限情報リポジトリ
 * @author 810
 *
 */
@Repository
public interface UserDeviceGroupAuthorityRepository extends JpaRepository<UserDeviceGroupAuthorityEntity, Integer>, UserDeviceGroupAuthorityRepositoryCustom {
}
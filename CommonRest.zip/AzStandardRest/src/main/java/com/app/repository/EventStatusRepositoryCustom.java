package com.app.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.app.entity.DeviceAlarmStatusEntity;
import com.app.entity.EventStatusEntity;
import com.app.model.DeviceAlarmStatusModel;
import com.app.model.EventStatusModel;

/**
 * イベント・アラーム状態取得リポジトリクラス
 * @author（TOSCO）エヒー
 */
@Repository
public interface EventStatusRepositoryCustom {

	/**
	 * ①デバイスグループID指定時 かつ 親子展開フラグがtrueの時、デバイスグループを親子展開し展開後のデバイスグループ群で対象のイベントIDを求めイベント履歴を検索する
	 */
	List<EventStatusEntity> searchDeviceGroupIdTrue(EventStatusModel query,String sort, Integer limit, Integer offset);

	/**
	 * ②デバイスグループID指定時 かつ 親子展開フラグがfalseの時、指定されたデバイスグループで対象のイベントIDを求めイベント履歴を検索する
	 */
	List<EventStatusEntity> searchDeviceGroupIdFalse(EventStatusModel query,String sort, Integer limit, Integer offset);

	/**
	 * ③[配列]デバイスリスト指定時 かつ 親子展開フラグがtrueの時、デバイスを親子展開し展開後のデバイス群で対象のイベントIDを求めイベント履歴を検索する
	 */
	List<EventStatusEntity> searchDeviceListTrue(EventStatusModel query,String sort, Integer limit, Integer offset);

	/**
	 * ④[配列]デバイスリスト指定時 かつ 親子展開フラグがfalseの時、指定されたデバイスで対象のイベントIDを求めイベント履歴を検索する
	 */
	List<EventStatusEntity> searchDeviceListFalse(EventStatusModel query,String sort, Integer limit, Integer offset);

	/**
	 * ⑤デバイスグループID、[配列]デバイスリスト未指定時、
	 */
	List<EventStatusEntity> search(EventStatusModel query,String sort, Integer limit, Integer offset);

	/**
	 * ⑥デバイスアラーム状態取得（デバイス直下のみ）
	 */
	List<DeviceAlarmStatusEntity> searchDeviceAlarmStatus(DeviceAlarmStatusModel query, List<String> sort, Integer limit, Integer offset);
	Long countDeviceAlarmStatus(DeviceAlarmStatusModel query);

	/**
	 * ⑦デバイスアラーム状態取得（デバイス配下を含む）
	 */
	List<DeviceAlarmStatusEntity> searchDeviceAlarmStatusRecursive(DeviceAlarmStatusModel query, List<String> sort, Integer limit, Integer offset);
	Long countDeviceAlarmStatusRecursive(DeviceAlarmStatusModel query);

}

package com.app.repository.imple;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.MstDeviceEntity;
import com.app.model.DeviceModel;
import com.app.model.DeviceQueryModel;
import com.app.repository.DeviceRepositoryCustom;

@Component
public class DeviceRepositoryCustomImple implements DeviceRepositoryCustom {
	@Autowired EntityManager em;

	/**
	 * ${inheritDoc}
	 */
	@Override
    public Boolean hasAuthority(String model_id, String serial_no, String user_id) {
		Query q = em.createNativeQuery("SELECT dbo.fn_DeviceAuthChk(:model_id, :serial_no, :user_id, default, default)");
		q.setParameter("model_id", model_id);
		q.setParameter("serial_no", serial_no);
		q.setParameter("user_id", user_id);
		return (Boolean)q.getSingleResult();
	}

	@Override
    public Boolean isCirculationReference(DeviceModel model) {
		StringBuffer buf = new StringBuffer();
		buf = buf.append(" WITH parent_device(parent_model_id, parent_serial_no, level) AS ("
				+ "          SELECT parent_model_id, parent_serial_no, 0 as level from mst_device"
				+"            WHERE model_id = :parent_model_id "
				+"              AND serial_no = :parent_serial_no "
				+"         UNION ALL "
				+"         SELECT d.parent_model_id, d.parent_serial_no,p.level+1 as level from parent_device p "
				+"          INNER JOIN mst_device d "
				+"                  ON d.model_id = p.parent_model_id "
				+"                 and d.serial_no = p.parent_serial_no "
				+"                 and d.parent_model_id IS NOT NULL where level < 40) "
				+"          Select 1 WHERE EXISTS ( SELECT 1 FROM parent_device "
				+"                                          WHERE parent_model_id = :model_id "
				+"                                            AND parent_serial_no = :serial_no ) " );

		Query q = em.createNativeQuery(buf.toString());

		q.setParameter("model_id", model.getModel_id());
		q.setParameter("serial_no", model.getSerial_no());
		q.setParameter("parent_model_id", model.getParent_model_id());
		q.setParameter("parent_serial_no", model.getParent_serial_no());
		int cnt = q.getResultList().size();
		return cnt>0?true:false;
	}
	@Override
	public MstDeviceEntity findOneForUpdate(int id) {
		return em.find(MstDeviceEntity.class, id, LockModeType.PESSIMISTIC_WRITE);
	}

	@Override
	public Long countAll(DeviceQueryModel query) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<MstDeviceEntity> root = criteriaQuery.from(MstDeviceEntity.class);
		criteriaQuery.select(builder.count(root));
		List<Predicate> conditionList = buildConditionList(query, root);
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	@Override
	public List<MstDeviceEntity> findAll(DeviceQueryModel query, List<String> sort, Integer limit, Integer offset) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MstDeviceEntity> criteriaQuery = builder.createQuery(MstDeviceEntity.class);
		Root<MstDeviceEntity> root = criteriaQuery.from(MstDeviceEntity.class);
		List<Predicate> conditionList = buildConditionList(query, root);
		if(conditionList.size() > 0){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}

		if (sort.size() > 0) {
			List<Order> orderList = new ArrayList<Order>();
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderList.add(builder.desc(root.get(col.substring(1))));
				} else {
					orderList.add(builder.asc(root.get(col)));
				}
			}
			criteriaQuery.orderBy(orderList);
		}

		TypedQuery<MstDeviceEntity> q = em.createQuery(criteriaQuery);
		if (offset != null) q.setFirstResult(offset);
		if (limit != null) q.setMaxResults(limit);

		return q.getResultList();
	}

	public <T> long count(List<Predicate> conditionList, Class<T> entity) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<T> root = criteriaQuery.from(entity);
		criteriaQuery.select(builder.count(root));
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	private List<Predicate> buildConditionList(DeviceQueryModel query, Root<MstDeviceEntity> root) {
		List<Predicate> conditionList = new ArrayList<>();
		if (query.getId() != null && query.getId().length > 0) {
			Object[] arr = Stream.of(query.getId()).map(StringUtil.String2Integer).toArray();
			conditionList.add(root.get("id").in(Arrays.asList(arr)));
		}
		if (query.getModel_id() != null && query.getModel_id().length > 0) {
			conditionList.add(root.get("model_id").in(Arrays.asList(query.getModel_id())));
		}
		if (query.getSerial_no() != null && query.getSerial_no().length > 0) {
			conditionList.add(root.get("serial_no").in(Arrays.asList(query.getSerial_no())));
		}
		if (query.getDevice_type() != null && query.getDevice_type().length > 0) {
			conditionList.add(root.get("device_type").in(Arrays.asList(query.getDevice_type())));
		}
		if (query.getIot_device_flg() != null && query.getIot_device_flg().length > 0) {
			Object[] arr = Stream.of(query.getIot_device_flg()).map(StringUtil.String2Boolean).toArray();
			conditionList.add(root.get("iot_device_flg").in(Arrays.asList(arr)));
		}
		if (query.getCommunication_flg() != null && query.getCommunication_flg().length > 0) {
			Object[] arr = Stream.of(query.getCommunication_flg()).map(StringUtil.String2Boolean).toArray();
			conditionList.add(root.get("communication_flg").in(Arrays.asList(arr)));
		}
		if (query.getName_locale1() != null && query.getName_locale1().length > 0) {
			conditionList.add(root.get("name_locale1").in(Arrays.asList(query.getName_locale1())));
		}
		if (query.getName_locale2() != null && query.getName_locale2().length > 0) {
			conditionList.add(root.get("name_locale2").in(Arrays.asList(query.getName_locale2())));
		}
		if (query.getName_locale3() != null && query.getName_locale3().length > 0) {
			conditionList.add(root.get("name_locale3").in(Arrays.asList(query.getName_locale3())));
		}
		if (query.getDescription_locale1() != null && query.getDescription_locale1().length > 0) {
			conditionList.add(root.get("description_locale1").in(Arrays.asList(query.getDescription_locale1())));
		}
		if (query.getDescription_locale2() != null && query.getDescription_locale2().length > 0) {
			conditionList.add(root.get("description_locale2").in(Arrays.asList(query.getDescription_locale2())));
		}
		if (query.getDescription_locale3() != null && query.getDescription_locale3().length > 0) {
			conditionList.add(root.get("description_locale3").in(Arrays.asList(query.getDescription_locale3())));
		}
		if (query.getMaker_code() != null && query.getMaker_code().length > 0) {
			conditionList.add(root.get("maker_code").in(Arrays.asList(query.getMaker_code())));
		}
		if (query.getParent_model_id() != null && query.getParent_model_id().length > 0) {
			conditionList.add(root.get("parent_model_id").in(Arrays.asList(query.getParent_model_id())));
		}
		if (query.getParent_serial_no() != null && query.getParent_serial_no().length > 0) {
			conditionList.add(root.get("parent_serial_no").in(Arrays.asList(query.getParent_serial_no())));
		}
		if (query.getSetup_place() != null && query.getSetup_place().length > 0) {
			conditionList.add(root.get("setup_place").in(Arrays.asList(query.getSetup_place())));
		}
		if (query.getSetup_status() != null && query.getSetup_status().length > 0) {
			conditionList.add(root.get("setup_status").in(Arrays.asList(query.getSetup_status())));
		}
		if (query.getTime_zone() != null && query.getTime_zone().length > 0) {
			conditionList.add(root.get("time_zone").in(Arrays.asList(query.getTime_zone())));
		}
		if (query.getLatitude() != null && query.getLatitude().length > 0) {
			Object[] arr = Stream.of(query.getLatitude()).map(StringUtil.String2BigDecimal).toArray();
			conditionList.add(root.get("latitude").in(Arrays.asList(arr)));
		}
		if (query.getLongitude() != null && query.getLongitude().length > 0) {
			Object[] arr = Stream.of(query.getLongitude()).map(StringUtil.String2BigDecimal).toArray();
			conditionList.add(root.get("longitude").in(Arrays.asList(arr)));
		}
		if (query.getDevice_mode() != null && query.getDevice_mode().length > 0) {
			conditionList.add(root.get("device_mode").in(Arrays.asList(query.getDevice_mode())));
		}
		if (query.getUnreceive_seconds() != null && query.getUnreceive_seconds().length > 0) {
			Object[] arr = Stream.of(query.getUnreceive_seconds()).map(StringUtil.String2Integer).toArray();
			conditionList.add(root.get("unreceive_seconds").in(Arrays.asList(arr)));
		}
		if (query.getNote() != null && query.getNote().length > 0) {
			conditionList.add(root.get("note").in(Arrays.asList(query.getNote())));
		}
		if (query.getVersion() != null && query.getVersion().length > 0) {
			Object[] arr = Stream.of(query.getVersion()).map(StringUtil.String2Long).toArray();
			conditionList.add(root.get("version").in(Arrays.asList(arr)));
		}
		if (query.getInserted() != null && query.getInserted().length > 0) {
			conditionList.add(root.get("inserted").in(Arrays.asList(query.getInserted())));
		}
		if (query.getInsert_time() != null && query.getInsert_time().length > 0) {
			Object[] arr = Stream.of(query.getInsert_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("insert_time").in(Arrays.asList(arr)));
		}
		if (query.getUpdated() != null && query.getUpdated().length > 0) {
			conditionList.add(root.get("updated").in(Arrays.asList(query.getUpdated())));
		}
		if (query.getUpdate_time() != null && query.getUpdate_time().length > 0) {
			Object[] arr = Stream.of(query.getUpdate_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("update_time").in(Arrays.asList(arr)));
		}
		return conditionList;
	}
}
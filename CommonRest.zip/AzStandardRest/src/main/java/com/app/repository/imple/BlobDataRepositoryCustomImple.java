package com.app.repository.imple;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.repository.BlobDataRepositoryCustom;
import com.microsoft.azure.storage.blob.CloudBlob;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlobDirectory;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.ListBlobItem;

/**
 * 日付別Blobファイルリポジトリ実装クラス
 * @author（TOSCO）ウェイ
 */
@Component
public class BlobDataRepositoryCustomImple implements BlobDataRepositoryCustom {

	@Override
	public String download(CloudBlobContainer container,String fileName, String filePath, String downloadDir)
			throws Exception {

		String downloadPath = "";
		CloudBlobDirectory directory = container.getDirectoryReference(filePath);

		for (ListBlobItem blobItem : directory.listBlobs()){

			CloudBlob blob = (CloudBlob) blobItem;
			String blobFile = blob.getName();
			Path p = Paths.get(blobFile);

			File file = new File(downloadDir
									+ Consts.DELIMITER
									+ blobFile.substring(0, blobFile.lastIndexOf(Consts.DELIMITER)));

			// ファイルディレクトリを作成する
			if (!file.exists()) file.mkdirs();

			// 対象ファイルがある場合、ファイルをダウンロードする
			if(fileName.equals(p.getFileName().toString())){
				downloadPath = downloadDir + Consts.DELIMITER + blobFile;
				blob.download(new FileOutputStream(downloadPath));
			}
		}
		return downloadPath;
	}

	@Override
	public void upload(CloudBlobContainer container, String fileName, String filePath) throws Exception {

		CloudBlockBlob blob = container.getBlockBlobReference(fileName);
		File source = new File(filePath);
		blob.upload(new FileInputStream(source), source.length());
	}
}

package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstDeviceEntity;
import com.app.model.DeviceModel;
import com.app.model.DeviceQueryModel;

public interface DeviceRepositoryCustom {
	List<MstDeviceEntity> findAll(DeviceQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(DeviceQueryModel query);

    MstDeviceEntity findOneForUpdate(@Param("id") int id);

	/**
	 * デバイス権限チェック
	 * @param 機種ID
	 * @param シリアルNo
	 * @param ユーザID
	 * @return true=参照権限有り、false=参照権限無し
	 */
    Boolean hasAuthority(String model_id, String serial_no, String user_id);

	/**
	 * 循環参照チェック
	 * @param 機種ID
	 * @param シリアルNo
	 * @param ユーザID
	 * @return true=参照権限有り、false=参照権限無し
	 */
    Boolean isCirculationReference(DeviceModel model);
}
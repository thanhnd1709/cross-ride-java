	package com.app.repository;

import java.sql.Timestamp;
import java.util.List;

import com.app.entity.StdFileInfoEntity;
import com.app.model.SensorFileModel;
import com.app.model.SensorLatestFileModel;
import com.app.model.SensorModel3;

/**
 * 計測ファイル情報リポジトリクラス
 * @author（TOSCO）ウェイ
 */
public interface StdFileInfoRepositoryCustom{


	/**
	 * 計測ファイル情報（全データ）取得処理を行います。
	 * @return 計測データ
	 */
	List<StdFileInfoEntity> searchAll(SensorFileModel query, List<SensorModel3> sensorList
			, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) throws Exception;

	/**
	 * 計測ファイル情報（最初のデータ１件）取得処理を行います。
	 * @return 計測データ
	 */
	List<StdFileInfoEntity> searchFirst(SensorFileModel query, List<SensorModel3> sensorList
			, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) throws Exception;


	/**
	 * 計測ファイル情報（最後のデータ１件）取得処理を行います。
	 * @return 計測データ
	 */
	List<StdFileInfoEntity> searchLast(SensorLatestFileModel query, List<SensorModel3> sensorList
			, String sort, Integer limit, Integer offset) throws Exception;
}
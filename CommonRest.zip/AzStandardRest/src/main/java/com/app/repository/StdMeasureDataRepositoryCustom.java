package com.app.repository;

import java.sql.Timestamp;
import java.util.List;

import com.app.entity.StdMeasureDataEntity;
import com.app.model.MeasureDataEntity;
import com.microsoft.azure.storage.table.CloudTable;

/**
 * 計測データリポジトリクラス
 * @author（TOSCO）ウェイ
 */
public interface StdMeasureDataRepositoryCustom{

	/**
	 * 計測データ（全データ）取得処理を行います。
	 * @return 計測データ
	 */
	List<StdMeasureDataEntity> searchAll(String modelId, String serialNo, String sensorId, Timestamp dateFrom, Timestamp dateTo)
			throws Exception;

	/**
	 * 計測データ（データ移行区分”E"以外の全データ）取得処理を行います。
	 * @return 計測データ
	 */
	List<StdMeasureDataEntity> searchAllExcluceE(String modelId, String serialNo, String sensorId, Timestamp dateFrom, Timestamp dateTo)
			throws Exception;
	/**
	 * 計測データ（最初のデータ１件）取得処理を行います。
	 * @return 計測データ
	 */
	List<StdMeasureDataEntity> searchFirst(String modelId, String serialNo, String sensorId, Timestamp dateFrom, Timestamp dateTo)
			throws Exception;

	/**
	 * 計測データ（最後のデータ１件）取得処理を行います。
	 * @return 計測データ
	 */
	List<StdMeasureDataEntity> searchLast(String modelId, String serialNo, String sensorId)
			throws Exception;
	
	
	List<MeasureDataEntity> searchMeasureFromTableStorage(String modelId, String serialNo, String sensorId, String dateFrom, String dateTo, CloudTable paramCloudTable2)
			throws Exception;
}
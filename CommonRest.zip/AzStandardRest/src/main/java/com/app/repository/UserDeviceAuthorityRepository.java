package com.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entity.UserDeviceAuthorityEntity;

/**
 * ユーザ・デバイス権限情報リポジトリ
 * @author 1572
 *
 */
@Repository
public interface UserDeviceAuthorityRepository extends JpaRepository<UserDeviceAuthorityEntity, Integer>, UserDeviceAuthorityRepositoryCustom {
}
package com.app.repository.imple;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.entity.EventHistoryEntity;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.DeviceListModel;
import com.app.model.EventHistoryModel;
import com.app.model.EventListModel2;
import com.app.repository.EventHistoryRepositoryCustom;

/**
 * イベント・アラーム履歴検索リポジトリ実装クラス
 * @author（TOSCO）小川
 */
@Component
public class EventHistoryRepositoryCustomImple implements EventHistoryRepositoryCustom {

	private static final String SELECT_STR = " SELECT";

	private static final String SELECT_FIELDS_STR =" eh.id,"
													+  " eh.model_id,"
													+  " eh.serial_no,"
													+  " eh.detection_class,"
													+  " eh.event_id,"
													+  " eh.event_time,"
													+  " eh.event_status,"
													+  " eh.incident_class,"
													+  " eh.event_level,"
													+  " eh.detection_info,"
													+  " me.event_type,"
													+  " me.sensor_id,"
													+  " me.name_locale1,"
													+  " me.name_locale2,"
													+  " me.name_locale3,"
													+  " me.description_locale1,"
													+  " me.description_locale2,"
													+  " me.description_locale3,"
													+  " me.chk_app_name,"
													+  " me.chk_app_parameter,"
													+  " me.check_timing,"
													+  " me.note";

	private static final String FROM_STR = " FROM std_event_incidence_history eh,"
											+ " mst_event me";

	private static final String WHERE = " WHERE ";

	private static final String WHERE_STR = "eh.model_id = me.model_id"
											+ " AND eh.serial_no = me.serial_no"
											+ " AND eh.event_id = me.event_id"
											+ " AND eh.event_time >= :event_time_from"
											+ " AND eh.event_time < :event_time_to"
											+ " AND dbo.fn_EventAuthChk(me.model_id, me.serial_no, me.event_id, (:userId), default, default) = 1";

	private String baseSql = null;
	private String fromSql = null;
	private String whereSql = null;

	@Autowired EntityManager em;
	@Autowired AuthUserInfoComponent authUserInfo;

	/**
	 * ①デバイスグループID指定時 かつ 親子展開フラグがtrueの時、
	 * デバイスグループを親子展開し展開後のデバイスグループ群で対象のイベントIDを求めイベント履歴を検索する
	 */
	@Override
	public List<EventHistoryEntity> searchDeviceGroupIdTrue(EventHistoryModel query
								, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) {

		String withSql = " WITH all_structure_group (device_group_id,level) AS ("
						+ "  SELECT device_group_id,"
						+ "  0 as level"
						+ "    FROM mst_device_group mg"
						+ "   WHERE device_group_id = :device_group_id"
						+ "  UNION ALL"
						+ "  SELECT mg.device_group_id,"
						+ "  ag.level+1 as level"
						+ "    FROM all_structure_group ag"
						+ "   INNER JOIN mst_device_group mg ON ag.device_group_id = mg.parent_device_group_id"
						+ "  WHERE level<10)";

		baseSql = SELECT_STR;


		fromSql = FROM_STR + ", (SELECT DISTINCT mgd.model_id, mgd.serial_no"
							+ " FROM all_structure_group ag, mst_group_composition_device mgd"
							+ " WHERE ag.device_group_id = mgd.device_group_id) el";

		whereSql = WHERE + " eh.model_id = el.model_id"
						  + " AND eh.serial_no = el.serial_no"
						  + " AND " + WHERE_STR;

		baseSql = baseSql + SELECT_FIELDS_STR + fromSql + whereSql;

		//WHERE句用検索条件追加
		baseSql = addCondition(baseSql, query);

		//ORDER BY句を作成する
		baseSql = orderBy(baseSql, sort, limit, offset);

		baseSql = withSql + baseSql;

		Query q = em.createNativeQuery(baseSql, EventHistoryEntity.class);

		//デバイスグルップIDの設定
		q.setParameter("device_group_id", query.getDevice_group_id());

		//各バインド変数にパラメータを設定
		q = setParameters(q, query, dateFrom, dateTo, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventHistoryEntity> list = q.getResultList();

		return list;
	}

	/**
	 * ②デバイスグループID指定時 かつ 親子展開フラグがfalseの時、
	 * 指定されたデバイスグループで対象のイベントIDを求めイベント履歴を検索する
	 */
	@Override
	public List<EventHistoryEntity> searchDeviceGroupIdFalse(EventHistoryModel query
								, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) {

		baseSql = SELECT_STR;

		fromSql = FROM_STR + ", mst_group_composition_device mgd";

		whereSql = WHERE + " mgd.device_group_id = :device_group_id"
				 		  + " AND eh.model_id = mgd.model_id"
				 		  + " AND eh.serial_no = mgd.serial_no"
				 		  + " AND " + WHERE_STR;

		baseSql = baseSql + SELECT_FIELDS_STR + fromSql + whereSql;

		//WHERE句用検索条件追加
		baseSql = addCondition(baseSql, query);

		//ORDER BY句を作成
		baseSql = orderBy(baseSql, sort, limit, offset);

		Query q = em.createNativeQuery(baseSql, EventHistoryEntity.class);

		//デバイスグルップIDの設定
		q.setParameter("device_group_id", query.getDevice_group_id());

		//各バインド変数にパラメータを設定
		q = setParameters(q, query, dateFrom, dateTo, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventHistoryEntity> list = q.getResultList();

		return list;
	}

	/**
	 * ③[配列]デバイスリスト指定時 かつ 親子展開フラグがtrueの時、
	 * デバイスを親子展開し展開後のデバイス群で対象のイベントIDを求めイベント履歴を検索する
	 */
	@Override
	public List<EventHistoryEntity> searchDeviceLitsTrue(EventHistoryModel query
								, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) {


		String withSql = "WITH all_structure_device (model_id, serial_no, level) AS ("
						+ " SELECT model_id, serial_no, 0 as level"
						+ " FROM mst_device md";

		// [配列]デバイスリスト処理
		boolean deviceListFlg = false;
		withSql += " WHERE (";
		for (DeviceListModel device : query.getDevice_list()) {
			if (deviceListFlg) withSql += " OR ";
				withSql += " (model_id = '" + device.getModel_id()
						+  "' AND serial_no = '" + device.getSerial_no() + "')";
				deviceListFlg = true;
			}
			withSql += ")";

		withSql += " UNION ALL"
				+  " SELECT md.model_id, md.serial_no, ad.level+1 as level"
				+  " FROM all_structure_device ad"
				+  " INNER JOIN mst_device md"
				+  "  ON (ad.model_id = md.parent_model_id"
				+  "  AND ad.serial_no = md.parent_serial_no)"
				+  " WHERE level < 10)";

		baseSql = SELECT_STR;


		fromSql = FROM_STR +", (SELECT DISTINCT me.model_id, me.serial_no, me.event_id"
							+ " FROM all_structure_device ad, mst_event me"
							+ " WHERE (ad.model_id = me.model_id AND ad.serial_no = me.serial_no)) el";

		whereSql = WHERE + " eh.model_id = el.model_id"
						  + " AND eh.serial_no = el.serial_no"
						  + " AND eh.event_id = el.event_id"
						  + " AND " + WHERE_STR;

		baseSql = baseSql + SELECT_FIELDS_STR + fromSql + whereSql;

		//WHERE句用検索条件追加
		baseSql = addCondition(baseSql, query);

		//ORDER BY句を作成
		baseSql = orderBy(baseSql, sort, limit, offset);

		baseSql = withSql + baseSql;

		Query q = em.createNativeQuery(baseSql, EventHistoryEntity.class);

		//各バインド変数にパラメータを設定
		q = setParameters(q, query, dateFrom, dateTo, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventHistoryEntity> list = q.getResultList();

		return list;
	}

	/**
	 * ④[配列]デバイスリスト指定時 かつ 親子展開フラグがfalseの時、
	 * 指定されたデバイスで対象のイベントIDを求めイベント履歴を検索する
	 */
	@Override
	public List<EventHistoryEntity> searchDeviceListFalse(EventHistoryModel query
								, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) {

		baseSql = SELECT_STR;

		baseSql = baseSql + SELECT_FIELDS_STR + FROM_STR + WHERE + WHERE_STR;

		//WHERE句用検索条件追加
		baseSql = addCondition(baseSql, query);

		// [配列]デバイスリスト処理
		boolean deviceListFlg = false;
		baseSql += " AND (";
		for (DeviceListModel device : query.getDevice_list()) {
			if (deviceListFlg) baseSql += " OR ";
			baseSql += " (me.model_id = '" + device.getModel_id()
					+  "' AND me.serial_no = '" + device.getSerial_no() + "')";
			deviceListFlg = true;
		}
		baseSql += ")";

		//ORDER BY句を作成
		baseSql = orderBy(baseSql, sort, limit, offset);

		Query q = em.createNativeQuery(baseSql, EventHistoryEntity.class);

		//各バインド変数にパラメータを設定
		q = setParameters(q, query, dateFrom, dateTo, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventHistoryEntity> list = q.getResultList();

		return list;
	}

	/**
	 * ⑤デバイスグループID、[配列]デバイスリスト未指定時、イベント時刻(From-To)等でイベント履歴を検索する
	 */
	@Override
	public List<EventHistoryEntity> searchEventTime(EventHistoryModel query
								, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset) {

		baseSql = SELECT_STR;


		baseSql = baseSql + SELECT_FIELDS_STR + FROM_STR + WHERE + WHERE_STR;

		//WHERE句用検索条件追加
		baseSql = addCondition(baseSql, query);

		// [配列]イベントリストが指定されている場合
		if(query.getEvent_list() != null){
			boolean eventListFlg = false;
			baseSql += " AND (";
			for(EventListModel2 event : query.getEvent_list()){
				if(eventListFlg) baseSql += " OR ";
				baseSql += "(me.model_id = '" + event.getModel_id()
						+  "' AND me.serial_no = '" + event.getSerial_no()
						+  "' AND me.event_id = '" + event.getEvent_id() + "')";
				eventListFlg = true;
			}
			baseSql += ")";
		}

		//ORDER BY句を作成
		baseSql = orderBy(baseSql, sort, limit, offset);

		Query q = em.createNativeQuery(baseSql, EventHistoryEntity.class);

		//各バインド変数にパラメータを設定
		q = setParameters(q, query, dateFrom, dateTo, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventHistoryEntity> list = q.getResultList();

		return list;
	}

	/**
	 * WHERE句用検索条件追加
	 *
	 * @param baseSql
	 * @param query
	 */
	private String addCondition(String baseSql, EventHistoryModel query){

		boolean hasVal = false;
		// イベント状態
		if(query.getEvent_status() != null){
			baseSql += " AND eh.event_status IN ('";
			hasVal = false;
			for(String eventStatus : query.getEvent_status()){
				if(hasVal) baseSql += "','";
				baseSql += eventStatus;
				hasVal = true;
			}
			baseSql += "')";
		}
		// イベントレベル
		if(query.getEvent_level() != null){
			baseSql += " AND eh.event_level IN ('";
			hasVal = false;
			for(String eventLevel : query.getEvent_level()){
				if(hasVal) baseSql += "','";
				baseSql += eventLevel;
				hasVal = true;
			}
			baseSql += "')";
		}
		// 検出情報
		if(query.getDetection_info() != null){
			baseSql += " AND eh.detection_info IN ('";
			hasVal = false;
			for(String detectInfo : query.getDetection_info()){
				if(hasVal) baseSql += "','";
				baseSql += detectInfo;
				hasVal = true;
			}
			baseSql += "')";
		}
		// 検出区分処理
		baseSql += " AND eh.detection_class IN (";
		boolean flg = false;
		for(String getClass : query.getGet_class()){
			if(flg) baseSql += ",";
			baseSql += "'" + getClass + "'";
			flg = true;
		}
		baseSql += ")";

		// 発生復帰区分が指定されている場合
		if(query.getIncident_class() != null && !query.getIncident_class().equals(Consts.INCIDENT_CLASS_3)){
			baseSql += " AND eh.incident_class = :incident_class";
		}

		return baseSql;
	}

	/**
	 * ORDER BY句を作成する
	 *
	 * @param baseSql
	 * @param sort
	 * @param limit
	 * @param offset
	 */
	private String orderBy(String baseSql, String sort, Integer limit, Integer offset){

		// ソート順が指定されている場合
		if(sort != null){
			//baseSql = " SELECT * FROM (" + baseSql + ") b ORDER BY " + sort;
			baseSql = baseSql + " ORDER BY " + sort;
		}

		// ページングが指定されている場合
		if(limit != null && offset != null){
			// ソート順が指定されていない場合
			if(sort == null){
				//baseSql = " SELECT * FROM (" + baseSql + ") b"
				baseSql = baseSql + " ORDER BY model_id, serial_no, detection_class, event_id, event_time ";
			}
			baseSql =  baseSql + " OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}
		return baseSql;
	}

	/**
	 * 各バインド変数にパラメータを設定する。
	 * @param q
	 * @param query
	 * @param dateFrom
	 * @param dateTo
	 * @param limit
	 * @param offset
	 */
	private Query setParameters(Query q, EventHistoryModel query,Timestamp dateFrom, Timestamp dateTo, Integer limit, Integer offset){


		q.setParameter("userId", authUserInfo.getPrincipalName());
		q.setParameter("event_time_from", dateFrom);
		q.setParameter("event_time_to", dateTo);

		if (query.getIncident_class() != null && !query.getIncident_class().equals(Consts.INCIDENT_CLASS_3)) {
			q.setParameter("incident_class", query.getIncident_class());
		}
		if (limit != null && offset != null) {
			q.setParameter("offset", offset);
			q.setParameter("limit", limit);
		}
		return q;
	}
}

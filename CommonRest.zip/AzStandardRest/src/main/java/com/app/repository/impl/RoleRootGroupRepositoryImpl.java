package com.app.repository.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.MstRoleRootGroupEntity;
import com.app.model.RoleRootGroupQueryModel;
import com.app.repository.RoleRootGroupRepositoryCustom;

@Component
public class RoleRootGroupRepositoryImpl implements RoleRootGroupRepositoryCustom {
	@PersistenceContext
	EntityManager em;

	@Override
	public MstRoleRootGroupEntity findOneForUpdate(int id) {
		return em.find(MstRoleRootGroupEntity.class, id, LockModeType.PESSIMISTIC_WRITE);
	}

	@Override
	public Long countAll(RoleRootGroupQueryModel query) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<MstRoleRootGroupEntity> root = criteriaQuery.from(MstRoleRootGroupEntity.class);
		criteriaQuery.select(builder.count(root));
		List<Predicate> conditionList = buildConditionList(query, root);
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	@Override
	public List<MstRoleRootGroupEntity> findAll(RoleRootGroupQueryModel query, List<String> sort, Integer limit, Integer offset) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MstRoleRootGroupEntity> criteriaQuery = builder.createQuery(MstRoleRootGroupEntity.class);
		Root<MstRoleRootGroupEntity> root = criteriaQuery.from(MstRoleRootGroupEntity.class);
		List<Predicate> conditionList = buildConditionList(query, root);
		if(conditionList.size() > 0){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}

		if (sort.size() > 0) {
			List<Order> orderList = new ArrayList<Order>();
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderList.add(builder.desc(root.get(col.substring(1))));
				} else {
					orderList.add(builder.asc(root.get(col)));
				}
			}
			criteriaQuery.orderBy(orderList);
		}

		TypedQuery<MstRoleRootGroupEntity> q = em.createQuery(criteriaQuery);
		if (offset != null) q.setFirstResult(offset);
		if (limit != null) q.setMaxResults(limit);

		return q.getResultList();
	}

	public <T> long count(List<Predicate> conditionList, Class<T> entity) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<T> root = criteriaQuery.from(entity);
		criteriaQuery.select(builder.count(root));
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	private List<Predicate> buildConditionList(RoleRootGroupQueryModel query, Root<MstRoleRootGroupEntity> root) {
		List<Predicate> conditionList = new ArrayList<>();
		if (query.getId() != null && query.getId().length > 0) {
			Object[] arr = Stream.of(query.getId()).map(StringUtil.String2Integer).toArray();
			conditionList.add(root.get("id").in(Arrays.asList(arr)));
		}
		if (query.getRole_id() != null && query.getRole_id().length > 0) {
			conditionList.add(root.get("role_id").in(Arrays.asList(query.getRole_id())));
		}
		if (query.getRoot_group_id() != null && query.getRoot_group_id().length > 0) {
			conditionList.add(root.get("root_group_id").in(Arrays.asList(query.getRoot_group_id())));
		}
		if (query.getVersion() != null && query.getVersion().length > 0) {
			Object[] arr = Stream.of(query.getVersion()).map(StringUtil.String2Long).toArray();
			conditionList.add(root.get("version").in(Arrays.asList(arr)));
		}
		if (query.getInserted() != null && query.getInserted().length > 0) {
			conditionList.add(root.get("inserted").in(Arrays.asList(query.getInserted())));
		}
		if (query.getInsert_time() != null && query.getInsert_time().length > 0) {
			Object[] arr = Stream.of(query.getInsert_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("insert_time").in(Arrays.asList(arr)));
		}
		if (query.getUpdated() != null && query.getUpdated().length > 0) {
			conditionList.add(root.get("updated").in(Arrays.asList(query.getUpdated())));
		}
		if (query.getUpdate_time() != null && query.getUpdate_time().length > 0) {
			Object[] arr = Stream.of(query.getUpdate_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("update_time").in(Arrays.asList(arr)));
		}
		return conditionList;
	}
}
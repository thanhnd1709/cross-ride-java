package com.app.repository.impl;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.UserDeviceGroupAuthorityEntity;
import com.app.model.UserDeviceGroupAuthorityQueryModel;
import com.app.repository.UserDeviceGroupAuthorityRepositoryCustom;

/**
 * ユーザ・デバイスグループ権限情報リポジトリクラス
 * @author 810
 *
 */
@Component
public class UserDeviceGroupAuthorityRepositoryImpl implements UserDeviceGroupAuthorityRepositoryCustom {
	private static final String SELECT_COUNT_STR = "SELECT count(*) FROM ";
	private static final String SELECT_STR = "SELECT row_number() over(ORDER BY (SELECT NULL) ASC) as id, tmp.* FROM ";
	private static final String SELECT_ALL_STR =
			"SELECT DISTINCT " +
			"device_group_id as device_group_id, " +
			"device_group_type as device_group_type, " +
			"device_group_subtype as device_group_subtype, " +
			"device_group_name_locale1 as device_group_name_locale1, " +
			"device_group_name_locale2 as device_group_name_locale2, " +
			"device_group_name_locale3 as device_group_name_locale3, " +
			"device_group_description_locale1 as device_group_description_locale1, " +
			"device_group_description_locale2 as device_group_description_locale2, " +
			"device_group_description_locale3 as device_group_description_locale3,  " +
			"parent_device_group_id as parent_device_group_id, " +
			"setup_place as setup_place, " +
			"setup_status as setup_status, " +
			"latitude as latitude, " +
			"longitude as longitude, " +
			"device_group_note as device_group_note, " +
			"role_id as role_id, " +
			"root_group_id as root_group_id, " +
			"role_name_locale1 as role_name_locale1, " +
			"role_name_locale2 as role_name_locale2,  " +
			"role_name_locale3 as role_name_locale3, " +
			"role_description_locale1 as role_description_locale1, " +
			"role_description_locale2 as role_description_locale2, " +
			"role_description_locale3 as role_description_locale3, " +
			"role_note as role_note, " +
			"hierarchy as hierarchy ";
	private static final String FROM_STR =
			" FROM dbo.fn_UserDeviceGroup(:user_id, :url, :method) ";
	private static final String FROM_STR_2 =
			" FROM dbo.fn_UserDeviceGroup(:user_id, default, default) ";
	private static final String WHERE_STR = " WHERE ";

	@Autowired EntityManager em;

	/**
	 * ユーザ・デバイスグループ権限情報件数取得
	 * @param query 検索条件オブジェクト
	 * @return 件数
	 */
	@Override
	public Long countAll(UserDeviceGroupAuthorityQueryModel query) {
		// SELECT文作成
		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_COUNT_STR + "(" + buildSubQuery(query, params) + ") as tmp";

		// クエリ作成
		Query q = em.createNativeQuery(sql);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// クエリ実行
		return ((Integer)q.getSingleResult()).longValue();
	}

	/**
	 * ユーザ・デバイスグループ権限情報検索
	 * @param query 検索条件オブジェクト
	 * @param sort ソート条件リスト
	 * @param limit 取得件数
	 * @param offset 取得開始オフセット値
	 * @return 検索結果リスト
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<UserDeviceGroupAuthorityEntity> findAll(UserDeviceGroupAuthorityQueryModel query, List<String> sort, Integer limit, Integer offset) {
		// ORDER BY句作成
		StringBuffer orderBy = new StringBuffer();
		if (sort.size() > 0) {
			orderBy.append(" ORDER BY ");
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderBy.append(col.substring(1) + " desc,");
				} else {
					orderBy.append(col + " asc,");
				}
			}
			orderBy.deleteCharAt(orderBy.length()-1);
		}

		// SELECT文作成
		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_STR + "(" + buildSubQuery(query, params) + orderBy.toString() + ") as tmp";
		if (offset == null && limit == null) {
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + ") as tmp " + orderBy.toString();
		} else {
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + orderBy.toString() + ") as tmp";
		}

		// クエリ作成
		Query q = em.createNativeQuery(sql, UserDeviceGroupAuthorityEntity.class);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// ページング設定
		if (offset != null) q.setFirstResult(offset);
		if (limit != null) q.setMaxResults(limit);

		// クエリ実行
		return q.getResultList();
	}

	/**
	 * サブクエリ作成
	 * @param query
	 * @param params
	 * @return
	 */
	private String buildSubQuery(UserDeviceGroupAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer sql = new StringBuffer();

		if(query.getFields() == null){
			sql.append(SELECT_ALL_STR);
		} else {
			sql.append("SELECT DISTINCT ");

			// INパラメータのfieldsで指定された項目以外のカラムはnull固定値を取得する
			List<String> list = Arrays.asList(query.getFields().split(","));
			Field[] fields = UserDeviceGroupAuthorityEntity.class.getDeclaredFields();
			for (Field f : fields) {
				if ("id".equals(f.getName())) {
					// idは親クエリのrow_numberで取得するため除外する。
					continue;
				}
				String item = list.contains(f.getName()) ? f.getName() : "null";
				sql.append(item + " as " + f.getName() + ",");
			}
			sql.deleteCharAt(sql.length()-1);	// 末端の,を削除
		}

		params.put("user_id", query.getUser_id());
		if (StringUtil.IsNullOrEmpty(query.getUrl())) {
			sql.append(FROM_STR_2);
		} else {
			sql.append(FROM_STR);
			params.put("url", query.getUrl());
			params.put("method", query.getMethod());
		}

		// WHERE句作成
		String where = buildCondition(query, params);
		sql.append(where);

		return sql.toString();
	}

	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(UserDeviceGroupAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer where = new StringBuffer(WHERE_STR);
		Object[] arr = null;
		addCondition(where, params, "device_group_id", query.getDevice_group_id());
		addCondition(where, params, "device_group_type", query.getDevice_group_type());
		addCondition(where, params, "device_group_subtype", query.getDevice_group_subtype());
		addPartialMatchCondition(where, params, "device_group_name_locale1", query.getDevice_group_name_locale1());
		addPartialMatchCondition(where, params, "device_group_name_locale2", query.getDevice_group_name_locale2());
		addPartialMatchCondition(where, params, "device_group_name_locale3", query.getDevice_group_name_locale3());
		addPartialMatchCondition(where, params, "device_group_description_locale1", query.getDevice_group_description_locale1());
		addPartialMatchCondition(where, params, "device_group_description_locale2", query.getDevice_group_description_locale2());
		addPartialMatchCondition(where, params, "device_group_description_locale3", query.getDevice_group_description_locale3());
		addCondition(where, params, "parent_device_group_id", query.getParent_device_group_id());
		addPartialMatchCondition(where, params, "setup_place", query.getSetup_place());
		addCondition(where, params, "setup_status", query.getSetup_status());
		if (query.getLatitude() != null) {
			arr = Stream.of(query.getLatitude()).map(StringUtil.String2BigDecimal).toArray();
			addCondition(where, params, "latitude", arr);
		}
		if (query.getLongitude() != null) {
			arr = Stream.of(query.getLongitude()).map(StringUtil.String2BigDecimal).toArray();
			addCondition(where, params, "longitude", arr);
		}
		addPartialMatchCondition(where, params, "device_group_note", query.getDevice_group_note());
		addCondition(where, params, "role_id", query.getRole_id());
		addCondition(where, params, "root_group_id", query.getRoot_group_id());
		addCondition(where, params, "role_name_locale1", query.getRole_name_locale1());
		addCondition(where, params, "role_name_locale2", query.getRole_name_locale2());
		addCondition(where, params, "role_name_locale3", query.getRole_name_locale3());
		addCondition(where, params, "role_description_locale1", query.getRole_description_locale1());
		addCondition(where, params, "role_description_locale2", query.getRole_description_locale2());
		addCondition(where, params, "role_description_locale3", query.getRole_description_locale3());
		addCondition(where, params, "role_note", query.getRole_note());
		if (query.getHierarchy() != null && query.getHierarchy().length > 0) {
			arr = Stream.of(query.getHierarchy()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "hierarchy", arr);
		}

		String ret = where.toString();
		return (ret.equals(WHERE_STR) ? "" : ret);
	}

	/**
	 * WHERE句用検索条件追加
	 * 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0) return;
		if (where.length() > WHERE_STR.length()) where.append(" AND ");
		where.append(col + " in (");
		for (int i = 0; i < values.length; i++) {
			String name = col + "_" + i;
			where.append(":").append(name).append(",");
			params.put(name, values[i]);
		}
		where.deleteCharAt(where.length()-1);
		where.append(")");
	}

	/**
	 * WHERE句用部分一致検索条件追加
	 * 引数のwhere句文字列にAND (列名 like バインド変数 OR ...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addPartialMatchCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0) return;
		if (where.length() > WHERE_STR.length()) where.append(" AND ");
		where.append("(");
		for (int i = 0; i < values.length; i++) {
			if (i > 0) where.append(" OR ");

			String name = col + "_" + i;
			where.append(col).append(" like :").append(name);
			params.put(name, values[i]);
		}
		where.append(")");
	}
}
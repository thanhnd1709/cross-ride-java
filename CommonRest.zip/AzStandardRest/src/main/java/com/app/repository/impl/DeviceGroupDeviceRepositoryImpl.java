package com.app.repository.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.DeviceGroupDeviceEntity;
import com.app.model.DeviceGroupDeviceQueryModel;
import com.app.repository.DeviceGroupDeviceRepositoryCustom;

@Component
public class DeviceGroupDeviceRepositoryImpl implements DeviceGroupDeviceRepositoryCustom {

	private static final String SELECT_STR01 = "WITH device_group_structure (parent_device_group_list, level, device_group_id) AS ("
				+ " SELECT CONVERT(nvarchar(2000), '') AS parent_device_group_list,"
				+ " 1 AS Level,"
				+ " device_group_id"
				+ " FROM mst_device_group mf";
	
//				+ " WHERE device_group_id = :device_group_id"
	private static final String SELECT_STR02 =	
				" AND dbo.fn_DeviceGroupAuthChk(mf.device_group_id, (:user_id), default, default) = 1"
				+ " UNION ALL"
				+ " SELECT CONVERT(nvarchar(2000),"
				+ " fs.parent_device_group_list + (CASE level WHEN 1 THEN '' ELSE char(9) END) + fs.device_group_id) "
				+ " AS parent_device_group_list,"
				+ " level + 1 AS level, mf.device_group_id"
				+ " FROM device_group_structure fs"
				+ " INNER JOIN mst_device_group mf"
				+ " ON fs.device_group_id = mf.parent_device_group_id"
				+ " AND fs.level < :level"
				+ " AND dbo.fn_DeviceGroupAuthChk(mf.device_group_id, (:user_id), default, default) = 1"
				+ " )";
	private static final String SELECT_STR03 =
				" SELECT CONVERT(nvarchar(2000), "
				+ " fs.parent_device_group_list + (CASE level WHEN 1 THEN '' ELSE char(9) END) + fs.device_group_id)"
				+ " AS device_group_list,"
				+ " fs.level,  mfd.model_id,  mfd.serial_no";
	private static final String FROM_STR=
				" FROM device_group_structure fs,"
				+ " mst_group_composition_device mfd"
				+ " WHERE fs.device_group_id = mfd.device_group_id"
				+ " AND dbo.fn_DeviceAuthChk(mfd.model_id,  mfd.serial_no, (:user_id), default, default)= 1";

	@Autowired
	EntityManager em;

	@SuppressWarnings("unchecked")
	@Override
	public List<DeviceGroupDeviceEntity> findAll(DeviceGroupDeviceQueryModel query, List<String> sort, Integer limit, Integer offset) {

		// SELECT句、FROM句作成
		StringBuffer sql = new StringBuffer(SELECT_STR01);
		
		// WHERE句作成
		Map<String, Object> params = new HashMap<String, Object>();
		String where = buildCondition(query, params);
		sql.append(where);
		
		sql.append(SELECT_STR02);
		sql.append(SELECT_STR03);
		sql.append(FROM_STR);
		
		// ORDER BY句作成
		boolean isNull = false;
		if (sort.size() > 0) {
			sql.append(" ORDER BY ");
			for (String col : sort) {
				if (col.startsWith("-")) {
					sql.append(col.substring(1) + " desc,");
				} else {
					sql.append(col + " asc,");
				}
			}
			isNull = true;
			sql.deleteCharAt(sql.length()-1);
		}
		
		// ページング設定
		if (limit != null && offset != null) {
			if(isNull ==false){
				sql.append(" ORDER BY device_group_list, level, model_id, serial_no ");
				}
			sql.append(" OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY");
			}

		// クエリ作成
		Query q = em.createNativeQuery(sql.toString(), DeviceGroupDeviceEntity.class);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// ページング設定
		if (limit != null && offset != null) {
			q.setParameter("limit", limit);
			q.setParameter("offset", offset);
			}

		
//		q.setParameter("device_group_id", query.getDevice_group_id());
		if(query.getLevel() != null){
			q.setParameter("level", query.getLevel());
		}
		else{
			q.setParameter("level", "40");
		}
		q.setParameter("user_id", query.getUser_id());


		// クエリ実行
		return q.getResultList();
	}
	
	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(DeviceGroupDeviceQueryModel query, Map<String, Object> params) {
		StringBuffer where = new StringBuffer(" WHERE ");

		addCondition(where, params, "device_group_id", query.getDevice_group_id());

		return where.toString();
	}

	/**
	 * WHERE句用検索条件追加
	 * 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0) return;
		if (where.length() > " WHERE ".length()) where.append(" AND ");
		where.append(col + " in (");
		for (int i = 0; i < values.length; i++) {
			String name = col + "_" + i;
			where.append(":").append(name).append(",");
			params.put(name, values[i]);
		}
		where.deleteCharAt(where.length()-1);
		where.append(")");
	}
}
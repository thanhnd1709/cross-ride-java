package com.app.repository.imple;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Iterator;

import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.common.utils.BitConverter;
import com.app.entity.DevHHDataEntity;
import com.app.entity.DevHourlyDataEntity;
import com.app.model.HourlySensorData;
import com.app.repository.DevHHDataRepositoryCustom;
import com.microsoft.azure.storage.table.CloudTable;
import com.microsoft.azure.storage.table.TableQuery;
import com.microsoft.azure.storage.table.TableQuery.Operators;
import com.microsoft.azure.storage.table.TableQuery.QueryComparisons;

/**
 * 時間別計測データリポジトリ実装クラス
 * 
 * @author（TOSCO）ウェイ
 */
@Component
public class DevHHDataRepositoryCustomImple implements DevHHDataRepositoryCustom {

	@Override
	public Iterable<DevHHDataEntity> searchAll(String partitionKey, String dateFrom, String dateTo, boolean hasMinSec,
			CloudTable cloudTable) throws Exception {

		String filter2;
		String partitionFilter = TableQuery.generateFilterCondition(Consts.PARTITION_KEY, QueryComparisons.EQUAL,
				partitionKey);
		String filter1 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.GREATER_THAN_OR_EQUAL,
				dateFrom);
		if (hasMinSec == true || dateFrom.equals(dateTo)) {
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.LESS_THAN_OR_EQUAL, dateTo);
		} else {
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.LESS_THAN, dateTo);
		}
		String rowFilter = TableQuery.combineFilters(filter1, Operators.AND, filter2);
		String combinedFilter = TableQuery.combineFilters(partitionFilter, Operators.AND, rowFilter);

		TableQuery<DevHHDataEntity> partitionQuery = TableQuery.from(DevHHDataEntity.class).where(combinedFilter);

		return cloudTable.execute(partitionQuery);
	}

	@Override
	public DevHHDataEntity searchFirst(String partitionKey, String dateFrom, String dateTo, boolean hasMinSec,
			CloudTable cloudTable) throws Exception {
		String filter2;

		DevHHDataEntity result = null;
		String partitionFilter = TableQuery.generateFilterCondition(Consts.PARTITION_KEY, QueryComparisons.EQUAL,
				partitionKey);
		String filter1 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.GREATER_THAN_OR_EQUAL,
				dateFrom);
		if (hasMinSec == true || dateFrom.equals(dateTo)) {
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.LESS_THAN_OR_EQUAL, dateTo);
		} else {
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.LESS_THAN, dateTo);
		}
		String rowFilter = TableQuery.combineFilters(filter1, Operators.AND, filter2);
		String combinedFilter = TableQuery.combineFilters(partitionFilter, Operators.AND, rowFilter);

		TableQuery<DevHHDataEntity> partitionQuery = TableQuery.from(DevHHDataEntity.class).where(combinedFilter);

		for (DevHHDataEntity entity : cloudTable.execute(partitionQuery)) {
			result = entity;
			break;
		}

		return result;
	}

	@Override
	public DevHHDataEntity searchLast(String partitionKey, String dateFrom, String dateTo, boolean hasMinSec,
			CloudTable cloudTable) throws Exception {
		String filter2;

		DevHHDataEntity result = null;
		String partitionFilter = TableQuery.generateFilterCondition(Consts.PARTITION_KEY, QueryComparisons.EQUAL,
				partitionKey);
		String filter1 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.GREATER_THAN_OR_EQUAL,
				dateFrom);
		if (hasMinSec == true || dateFrom.equals(dateTo)) {
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.LESS_THAN_OR_EQUAL, dateTo);
		} else {
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.LESS_THAN, dateTo);
		}
		String rowFilter = TableQuery.combineFilters(filter1, Operators.AND, filter2);
		String combinedFilter = TableQuery.combineFilters(partitionFilter, Operators.AND, rowFilter);

		TableQuery<DevHHDataEntity> partitionQuery = TableQuery.from(DevHHDataEntity.class).where(combinedFilter);

		for (DevHHDataEntity entity : cloudTable.execute(partitionQuery)) {
			result = entity;
		}

		return result;
	}

	public Iterable<DevHourlyDataEntity> searchAllHourlyData(String partitionKey, String dateFrom, String dateTo,
			boolean hasMinSec, CloudTable cloudTable) throws Exception {
		Iterable<DevHourlyDataEntity> hhDataEntityList = new Iterable<DevHourlyDataEntity>() {

			@Override
			public Iterator<DevHourlyDataEntity> iterator() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		String filter2;
		// String partitionFilter =
		// TableQuery.generateFilterCondition(Consts.PARTITION_KEY,
		// QueryComparisons.EQUAL, partitionKey);

		char lastChar = partitionKey.charAt(partitionKey.length() - 1); // partitionKey[partitionKey.length() - 1];
		char nextLastChar = (char) ((int) lastChar + 1);
		String nextSearchStr = partitionKey.substring(0, partitionKey.length() - 1) + nextLastChar;

		String partitionFilter = TableQuery.combineFilters(
				TableQuery.generateFilterCondition(Consts.PARTITION_KEY, QueryComparisons.GREATER_THAN_OR_EQUAL,
						partitionKey),
				Operators.AND,
				TableQuery.generateFilterCondition(Consts.PARTITION_KEY, QueryComparisons.LESS_THAN, nextSearchStr));

		String filter1 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.GREATER_THAN_OR_EQUAL,
				dateFrom);
		if (hasMinSec == true || dateFrom.equals(dateTo)) {
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.LESS_THAN_OR_EQUAL, dateTo);
		} else {
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY, QueryComparisons.LESS_THAN, dateTo);
		}
		String rowFilter = TableQuery.combineFilters(filter1, Operators.AND, filter2);
		String combinedFilter = TableQuery.combineFilters(partitionFilter, Operators.AND, rowFilter);

		TableQuery<DevHourlyDataEntity> partitionQuery = TableQuery.from(DevHourlyDataEntity.class)
				.where(combinedFilter);

		Iterable<DevHourlyDataEntity> hourlyDataList = cloudTable.execute(partitionQuery);
		return hourlyDataList;

	}

}

package com.app.repository;

import org.springframework.data.repository.query.Param;

import com.app.entity.StdEventIncidenceEntity;

public interface StatusManagementRepositoryCustom {
	StdEventIncidenceEntity findOneForUpdate(@Param("id") int id);
}
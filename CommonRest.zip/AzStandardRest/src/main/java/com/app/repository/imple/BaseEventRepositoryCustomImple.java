package com.app.repository.imple;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.MstBaseEventEntity;
import com.app.model.BaseEventQueryModel;
import com.app.repository.BaseEventRepositoryCustom;

@Component
public class BaseEventRepositoryCustomImple implements BaseEventRepositoryCustom {
	@Autowired EntityManager em;

	@Override
	public MstBaseEventEntity findOneForUpdate(int id) {
		return em.find(MstBaseEventEntity.class, id, LockModeType.PESSIMISTIC_WRITE);
	}

	@Override
	public Long countAll(BaseEventQueryModel query) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<MstBaseEventEntity> root = criteriaQuery.from(MstBaseEventEntity.class);
		criteriaQuery.select(builder.count(root));
		List<Predicate> conditionList = buildConditionList(query, root);
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	@Override
	public List<MstBaseEventEntity> findAll(BaseEventQueryModel query, List<String> sort, Integer limit, Integer offset) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MstBaseEventEntity> criteriaQuery = builder.createQuery(MstBaseEventEntity.class);
		Root<MstBaseEventEntity> root = criteriaQuery.from(MstBaseEventEntity.class);
		List<Predicate> conditionList = buildConditionList(query, root);
		if(conditionList.size() > 0){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}

		if (sort.size() > 0) {
			List<Order> orderList = new ArrayList<Order>();
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderList.add(builder.desc(root.get(col.substring(1))));
				} else {
					orderList.add(builder.asc(root.get(col)));
				}
			}
			criteriaQuery.orderBy(orderList);
		}

		TypedQuery<MstBaseEventEntity> q = em.createQuery(criteriaQuery);
		if (offset != null) q.setFirstResult(offset);
		if (limit != null) q.setMaxResults(limit);

		return q.getResultList();
	}

	public <T> long count(List<Predicate> conditionList, Class<T> entity) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<T> root = criteriaQuery.from(entity);
		criteriaQuery.select(builder.count(root));
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	private List<Predicate> buildConditionList(BaseEventQueryModel query, Root<MstBaseEventEntity> root) {
		List<Predicate> conditionList = new ArrayList<>();
		if (query.getId() != null && query.getId().length > 0) {
			Object[] arr = Stream.of(query.getId()).map(StringUtil.String2Integer).toArray();
			conditionList.add(root.get("id").in(Arrays.asList(arr)));
		}
		if (query.getModel_id() != null && query.getModel_id().length > 0) {
			conditionList.add(root.get("model_id").in(Arrays.asList(query.getModel_id())));
		}
		if (query.getEvent_id() != null && query.getEvent_id().length > 0) {
			conditionList.add(root.get("event_id").in(Arrays.asList(query.getEvent_id())));
		}
		if (query.getEvent_type() != null && query.getEvent_type().length > 0) {
			conditionList.add(root.get("event_type").in(Arrays.asList(query.getEvent_type())));
		}
		if (query.getEvent_level() != null && query.getEvent_level().length > 0) {
			conditionList.add(root.get("event_level").in(Arrays.asList(query.getEvent_level())));
		}
		if (query.getSensor_id() != null && query.getSensor_id().length > 0) {
			conditionList.add(root.get("sensor_id").in(Arrays.asList(query.getSensor_id())));
		}
		if (query.getName_locale1() != null && query.getName_locale1().length > 0) {
			conditionList.add(root.get("name_locale1").in(Arrays.asList(query.getName_locale1())));
		}
		if (query.getName_locale2() != null && query.getName_locale2().length > 0) {
			conditionList.add(root.get("name_locale2").in(Arrays.asList(query.getName_locale2())));
		}
		if (query.getName_locale3() != null && query.getName_locale3().length > 0) {
			conditionList.add(root.get("name_locale3").in(Arrays.asList(query.getName_locale3())));
		}
		if (query.getDescription_locale1() != null && query.getDescription_locale1().length > 0) {
			conditionList.add(root.get("description_locale1").in(Arrays.asList(query.getDescription_locale1())));
		}
		if (query.getDescription_locale2() != null && query.getDescription_locale2().length > 0) {
			conditionList.add(root.get("description_locale2").in(Arrays.asList(query.getDescription_locale2())));
		}
		if (query.getDescription_locale3() != null && query.getDescription_locale3().length > 0) {
			conditionList.add(root.get("description_locale3").in(Arrays.asList(query.getDescription_locale3())));
		}
		if (query.getChk_app_name() != null && query.getChk_app_name().length > 0) {
			conditionList.add(root.get("chk_app_name").in(Arrays.asList(query.getChk_app_name())));
		}
		if (query.getChk_app_parameter() != null && query.getChk_app_parameter().length > 0) {
			conditionList.add(root.get("chk_app_parameter").in(Arrays.asList(query.getChk_app_parameter())));
		}
		if (query.getCheck_timing() != null && query.getCheck_timing().length > 0) {
			conditionList.add(root.get("check_timing").in(Arrays.asList(query.getCheck_timing())));
		}
		if (query.getNote() != null && query.getNote().length > 0) {
			conditionList.add(root.get("note").in(Arrays.asList(query.getNote())));
		}
		if (query.getAttribute_sync_flg() != null && query.getAttribute_sync_flg().length > 0) {
			Object[] arr = Stream.of(query.getAttribute_sync_flg()).map(StringUtil.String2Boolean).toArray();
			conditionList.add(root.get("attribute_sync_flg").in(Arrays.asList(arr)));
		}
		if (query.getVersion() != null && query.getVersion().length > 0) {
			Object[] arr = Stream.of(query.getVersion()).map(StringUtil.String2Long).toArray();
			conditionList.add(root.get("version").in(Arrays.asList(arr)));
		}
		if (query.getInserted() != null && query.getInserted().length > 0) {
			conditionList.add(root.get("inserted").in(Arrays.asList(query.getInserted())));
		}
		if (query.getInsert_time() != null && query.getInsert_time().length > 0) {
			Object[] arr = Stream.of(query.getInsert_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("insert_time").in(Arrays.asList(arr)));
		}
		if (query.getUpdated() != null && query.getUpdated().length > 0) {
			conditionList.add(root.get("updated").in(Arrays.asList(query.getUpdated())));
		}
		if (query.getUpdate_time() != null && query.getUpdate_time().length > 0) {
			Object[] arr = Stream.of(query.getUpdate_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("update_time").in(Arrays.asList(arr)));
		}
		return conditionList;
	}
}
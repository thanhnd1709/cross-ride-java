package com.app.repository.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.entity.DeviceGroupAlarmStatusEntity;
import com.app.entity.DeviceGroupAlarmStatusEntity1;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.DeviceGroupAlarmStatusModel;
import com.app.repository.DeviceGroupAlarmStatusRepositoryCustom;

/**
 * デバイスグループアラーム状態取得リポジトリ実装クラス
 * @author（TOSCO）エヒー
 */
@Component
public class DeviceGroupAlarmStatusRepositoryCustomImpl implements DeviceGroupAlarmStatusRepositoryCustom {

	@Autowired EntityManager em;
	@Autowired AuthUserInfoComponent authUserInfo;

	@Override
	public List<DeviceGroupAlarmStatusEntity> getParentEventLevel(DeviceGroupAlarmStatusModel query, String sort, Integer limit,
			Integer offset) {

		String sql ="SELECT "
				+ " mg.device_group_id,"
				+ " ei.detection_class,";

			if (query.getCompare_class().equals(Consts.COMPARE_CLASS_1)) {
				sql += " MAX(ei.event_level) event_level";
			} else {
				// 比較区分=2の時、TRY_CONVERT (float, ei.event_level)を設定
				sql += " MAX(TRY_CONVERT (float, ei.event_level)) event_level";
			}

		sql +=" FROM mst_group_composition_device mg,"
			+ " std_event_incidence ei"
			+ " WHERE mg.model_id = ei.model_id"
			+ " AND mg.serial_no = ei.serial_no";

		boolean flg = false;
		// デバイスグループID
		sql += " AND mg.device_group_id IN (";
		for (String getDeviceGroupID : query.getDevice_group_id()) {
			if (flg) sql += ",";
			sql += "'" + getDeviceGroupID + "'";
			flg = true;
		}
		sql += ")";

		// 検出区分
		sql += " AND ei.detection_class IN (";
		flg = false;
		for (String getClass : query.getGet_class()) {
			if (flg) sql += ",";
			sql += "'" + getClass + "'";
			flg = true;
		}
		sql += ")";

		//発生復帰区分の値が3の時は当該行削除(条件にしない)
		if (query.getIncident_class() != null && !query.getIncident_class().equals(Consts.INCIDENT_CLASS_3)) {
			sql += "  AND ei.incident_class = :incident_class";
		}

		sql += "  AND (ei.detection_class IN ("+"'4'"+","+"'5'"+") AND dbo.fn_EventAuthChk(ei.model_id, ei.serial_no, ei.event_id, (:userId), default, default) = 1"
				+ "  OR ei.detection_class NOT IN ("+"'4'"+","+"'5'"+") AND dbo.fn_DeviceAuthChk(ei.model_id, ei.serial_no, (:userId), default, default) = 1)";

		sql+=" GROUP BY mg.device_group_id, ei.detection_class";

		boolean isNull = false;
		// ソート順が指定されている場合
		if (sort != null) {
			sql = "  SELECT * FROM (" + sql + ") b ORDER BY " + sort;
			isNull = true;
		}

		// ページングが指定されている場合
		if (limit != null && offset != null) {
			// ソート順が指定されていない場合
			if (isNull == false) {
				sql = "  SELECT * FROM ( " + sql + ") b" + " ORDER BY device_group_id,detection_class";
			}
			sql += "  OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}

		Query qry = em.createNativeQuery(sql, DeviceGroupAlarmStatusEntity.class);

		// 発生復帰区分の設定
		if (query.getIncident_class() != null&& !query.getIncident_class().equals(Consts.INCIDENT_CLASS_3)) {
			qry.setParameter("incident_class", query.getIncident_class());
		}

		// ユーザID設定
		qry.setParameter("userId", authUserInfo.getPrincipalName());

		// リミットとオフセットの設定
		if (limit != null && offset != null) {
			qry.setParameter("offset", offset);
			qry.setParameter("limit", limit);
		}

		@SuppressWarnings("unchecked")
		List<DeviceGroupAlarmStatusEntity> list = qry.getResultList();

		return list;
	}

	@Override
	public List<DeviceGroupAlarmStatusEntity> getChildEventLevel(DeviceGroupAlarmStatusModel query, String sort, Integer limit,
			Integer offset) {

		List<String> devGrpList = getDeviceGroupIdList(query);

		String withSql = "WITH all_structure_device (device_group_id, model_id, serial_no) AS ("
				+ "  SELECT md.device_group_id, md.model_id, md.serial_no"
				+ "  FROM mst_group_composition_device md"
				+ "  WHERE";

		boolean flg = false;
		// デバイスグループID
		withSql += "  md.device_group_id IN (";

		if(!devGrpList.isEmpty()){
			for (String getDeviceGroupID : devGrpList) {
				if (flg) withSql += ",";
				withSql += "'" + getDeviceGroupID + "'";
				flg = true;
			}
		}else{
			withSql += "'"+ "'";
		}

		withSql += ")";

		withSql+="  UNION ALL"
				+ "  SELECT ad.device_group_id, md.model_id, md.serial_no"
				+ "  FROM all_structure_device ad"
				+ "  INNER JOIN mst_device md"
				+ "  ON (md.parent_model_id = ad.model_id AND md.parent_serial_no = ad.serial_no))";

		String sql ="  SELECT "
				+ "  ad.device_group_id,"
				+ "  ei.detection_class,";

			if (query.getCompare_class().equals(Consts.COMPARE_CLASS_1)) {
				sql += "  MAX(ei.event_level) event_level";
			} else {
				// 比較区分=2の時、TRY_CONVERT (float, ei.event_level)を設定
				sql += "  MAX(TRY_CONVERT (float, ei.event_level)) event_level";
			}

		sql += "  FROM all_structure_device ad,"
			+ " std_event_incidence ei"
			+ " WHERE ad.model_id = ei.model_id"
			+ " AND ad.serial_no = ei.serial_no";

		// 検出区分
		sql += " AND ei.detection_class IN (";
		flg = false;
		for (String getClass : query.getGet_class()) {
			if (flg) sql += ",";
			sql += "'" + getClass + "'";
			flg = true;
		}
		sql += ")";

		//発生復帰区分の値が3の時は当該行削除(条件にしない)
		if (query.getIncident_class() != null && !query.getIncident_class().equals(Consts.INCIDENT_CLASS_3)) {
			sql += "  AND ei.incident_class = :incident_class";
		}

		sql += "  AND (ei.detection_class IN ("+"'4'"+","+"'5'"+") AND dbo.fn_EventAuthChk(ei.model_id, ei.serial_no, ei.event_id, (:userId), default, default) = 1"
				+ "  OR ei.detection_class NOT IN ("+"'4'"+","+"'5'"+") AND dbo.fn_DeviceAuthChk(ei.model_id, ei.serial_no, (:userId), default, default) = 1)";

		sql+="  GROUP BY ad.device_group_id, ei.detection_class";

		boolean isNull = false;
		// ソート順が指定されている場合
		if (sort != null ) {
			sql = "  SELECT * FROM (" + sql + ") b ORDER BY " + sort;
			isNull = true;
		}

		// ページングが指定されている場合
		if (limit != null && offset != null) {
			// ソート順が指定されていない場合
			if (isNull == false) {
				sql = "  SELECT * FROM ( " + sql + ") b" + " ORDER BY device_group_id,detection_class";
			}
			sql += "  OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}

		sql = withSql + sql;

		Query qry = em.createNativeQuery(sql, DeviceGroupAlarmStatusEntity.class);

		// 発生復帰区分の設定
		if (query.getIncident_class() != null&& !query.getIncident_class().equals(Consts.INCIDENT_CLASS_3)) {
			qry.setParameter("incident_class", query.getIncident_class());
		}

		// ユーザID設定
		qry.setParameter("userId", authUserInfo.getPrincipalName());

		// リミットとオフセットの設定
		if (limit != null && offset != null) {
			qry.setParameter("offset", offset);
			qry.setParameter("limit", limit);
		}

		@SuppressWarnings("unchecked")
		List<DeviceGroupAlarmStatusEntity> list = qry.getResultList();

		return list;
	}

	public List<String> getDeviceGroupIdList(DeviceGroupAlarmStatusModel query){

		List<String> devGroupIdList = new ArrayList<>();
		String sql ="WITH all_structure_group (device_group_id) AS ("
				+ "  SELECT device_group_id "
				+ "  FROM mst_device_group mg"
				+ "  WHERE ";

		boolean flg = false;
		// デバイスグループID
		sql += "  mg.device_group_id IN (";
		for (String getDeviceGroupID : query.getDevice_group_id()) {
			if (flg) sql += ",";
			sql += "'" + getDeviceGroupID + "'";
			flg = true;
		}
		sql += ")";

		sql+="  UNION ALL"
				+ "  SELECT mg.device_group_id"
				+ "  FROM all_structure_group ag"
				+ "  INNER JOIN mst_device_group mg"
				+ "  ON ag.device_group_id = mg.parent_device_group_id"
				+ "  )"
				+ "  SELECT DISTINCT device_group_id"
				+ "  FROM all_structure_group ";

		Query qry = em.createNativeQuery(sql, DeviceGroupAlarmStatusEntity1.class);

		@SuppressWarnings("unchecked")
		List<DeviceGroupAlarmStatusEntity1> devGrpList= qry.getResultList();
		for (DeviceGroupAlarmStatusEntity1 deviceEntity : devGrpList) {
			devGroupIdList.add(deviceEntity.getDevice_group_id());
		}
		return devGroupIdList;
	}
}

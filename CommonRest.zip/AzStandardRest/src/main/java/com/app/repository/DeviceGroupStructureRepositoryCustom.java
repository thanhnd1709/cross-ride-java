package com.app.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.app.entity.DeviceGroupStructureEntity;
import com.app.model.DeviceGroupStructureModel;

/**
 * 11.4.1.	デバイスグループ階層情報取得リポジトリクラス
 * @author（TOSCO）エ
 */
@Repository
public interface DeviceGroupStructureRepositoryCustom {

	/**
	 * デバイスグループ直下のデバイスのイベントレベル最大値を取得する
	 */
	List<DeviceGroupStructureEntity> getDeviceGroupStructure(DeviceGroupStructureModel model, String sort,Integer limit,Integer offset);

}

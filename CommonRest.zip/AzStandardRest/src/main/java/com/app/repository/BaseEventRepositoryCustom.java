package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstBaseEventEntity;
import com.app.model.BaseEventQueryModel;

public interface BaseEventRepositoryCustom {
	List<MstBaseEventEntity> findAll(BaseEventQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(BaseEventQueryModel query);

    MstBaseEventEntity findOneForUpdate(@Param("id") int id);
}
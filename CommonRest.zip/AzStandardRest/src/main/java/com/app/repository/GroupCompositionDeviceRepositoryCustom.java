package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstGroupCompositionDeviceEntity;
import com.app.model.GroupCompositionDeviceQueryModel;

public interface GroupCompositionDeviceRepositoryCustom {
	List<MstGroupCompositionDeviceEntity> findAll(GroupCompositionDeviceQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(GroupCompositionDeviceQueryModel query);

    MstGroupCompositionDeviceEntity findOneForUpdate(@Param("id") int id);
}
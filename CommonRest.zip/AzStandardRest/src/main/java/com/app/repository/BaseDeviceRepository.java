package com.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entity.MstBaseDeviceEntity;

@Repository
public interface BaseDeviceRepository extends JpaRepository<MstBaseDeviceEntity, Integer> {

}
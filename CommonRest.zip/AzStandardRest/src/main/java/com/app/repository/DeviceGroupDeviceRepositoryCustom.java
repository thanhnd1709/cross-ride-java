package com.app.repository;

import java.util.List;

import com.app.entity.DeviceGroupDeviceEntity;
import com.app.model.DeviceGroupDeviceQueryModel;

public interface DeviceGroupDeviceRepositoryCustom {
	List<DeviceGroupDeviceEntity> findAll(DeviceGroupDeviceQueryModel query, List<String> sort, Integer limit, Integer offset);
}
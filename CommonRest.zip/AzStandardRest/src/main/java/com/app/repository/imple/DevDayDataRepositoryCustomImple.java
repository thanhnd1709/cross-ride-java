package com.app.repository.imple;

import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.entity.DevDayDataEntity;
import com.app.repository.DevDayDataRepositoryCustom;
import com.microsoft.azure.storage.table.CloudTable;
import com.microsoft.azure.storage.table.TableQuery;
import com.microsoft.azure.storage.table.TableQuery.Operators;
import com.microsoft.azure.storage.table.TableQuery.QueryComparisons;

/**
 * 日別計測データリポジトリ実装クラス
 * @author（TOSCO）ウェイ
 */
@Component
public class DevDayDataRepositoryCustomImple implements DevDayDataRepositoryCustom {

	@Override
	public Iterable<DevDayDataEntity> searchAll(String partitionKey, String dateFrom, String dateTo,
			boolean hasHrMinSec, CloudTable cloudTable) throws Exception {

		String filter2;

		String partitionFilter = TableQuery.generateFilterCondition(Consts.PARTITION_KEY,
				QueryComparisons.EQUAL, partitionKey);
		String filter1 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
				QueryComparisons.GREATER_THAN_OR_EQUAL, dateFrom);
		if(hasHrMinSec == true || dateFrom.equals(dateTo)){
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
					QueryComparisons.LESS_THAN_OR_EQUAL, dateTo);
		}else{
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
					QueryComparisons.LESS_THAN, dateTo);
		}
		String rowFilter = TableQuery.combineFilters(filter1, Operators.AND, filter2);
		String combinedFilter = TableQuery.combineFilters(partitionFilter, Operators.AND, rowFilter);

		TableQuery<DevDayDataEntity> partitionQuery =
				TableQuery.from(DevDayDataEntity.class).where(combinedFilter);

		return cloudTable.execute(partitionQuery);
	}

	@Override
	public DevDayDataEntity searchFirst(String partitionKey, String dateFrom, String dateTo, boolean hasHrMinSec,
			CloudTable cloudTable) throws Exception {
		String filter2;

		DevDayDataEntity result = null;

		String partitionFilter = TableQuery.generateFilterCondition(Consts.PARTITION_KEY,
				QueryComparisons.EQUAL, partitionKey);
		String filter1 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
				QueryComparisons.GREATER_THAN_OR_EQUAL, dateFrom);
		if(hasHrMinSec == true || dateFrom.equals(dateTo)){
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
					QueryComparisons.LESS_THAN_OR_EQUAL, dateTo);
		}else{
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
					QueryComparisons.LESS_THAN, dateTo);
		}
		String rowFilter = TableQuery.combineFilters(filter1, Operators.AND, filter2);
		String combinedFilter = TableQuery.combineFilters(partitionFilter, Operators.AND, rowFilter);

		TableQuery<DevDayDataEntity> partitionQuery =
				TableQuery.from(DevDayDataEntity.class).where(combinedFilter);

		for (DevDayDataEntity entity : cloudTable.execute(partitionQuery)) {
			result = entity;
			break;
		}

		return result;
	}

	@Override
	public DevDayDataEntity searchLast(String partitionKey, String dateFrom, String dateTo, boolean hasHrMinSec,
			CloudTable cloudTable) throws Exception {
		String filter2;

		DevDayDataEntity result = null;

		String partitionFilter = TableQuery.generateFilterCondition(Consts.PARTITION_KEY,
				QueryComparisons.EQUAL, partitionKey);
		String filter1 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
				QueryComparisons.GREATER_THAN_OR_EQUAL, dateFrom);
		if(hasHrMinSec == true || dateFrom.equals(dateTo)){
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
					QueryComparisons.LESS_THAN_OR_EQUAL, dateTo);
		}else{
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
					QueryComparisons.LESS_THAN, dateTo);
		}
		String rowFilter = TableQuery.combineFilters(filter1, Operators.AND, filter2);
		String combinedFilter = TableQuery.combineFilters(partitionFilter, Operators.AND, rowFilter);

		TableQuery<DevDayDataEntity> partitionQuery =
				TableQuery.from(DevDayDataEntity.class).where(combinedFilter);

		for (DevDayDataEntity entity : cloudTable.execute(partitionQuery)) {
			result = entity;
		}

		return result;
	}


}

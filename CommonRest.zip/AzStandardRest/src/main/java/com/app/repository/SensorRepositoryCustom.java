package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstSensorEntity;
import com.app.model.SensorQueryModel;

public interface SensorRepositoryCustom {
	List<MstSensorEntity> findAll(SensorQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(SensorQueryModel query);

    MstSensorEntity findOneForUpdate(@Param("id") int id);
}
package com.app.repository.imple;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.MstRollEntity;
import com.app.model.RollQueryModel;
import com.app.repository.RoleRepositoryCustom;

@Component
public class RoleRepositoryCustomImple implements RoleRepositoryCustom {

	private static final String SELECT_COUNT_STR = "SELECT count(1) FROM mst_role r ";
	private static final String SELECT_STR = "SELECT "+
													"r.id as id, " +
													"r.role_id as role_id, " +
													"r.base_role_flg as base_role_flg, " +
													"r.authority_role_id as authority_role_id, " +
													"r.name_locale1 as name_locale1, " +
													"r.name_locale2 as name_locale2, " +
													"r.name_locale3 as name_locale3, " +
													"r.description_locale1 as description_locale1, " +
													"r.description_locale2 as description_locale2, " +
													"r.description_locale3 as description_locale3, " +
													"r.note as note, " +
													"r.version as version, " +
													"r.inserted as inserted, " +
													"r.insert_time as insert_time, " +
													"r.updated as updated, " +
													"r.update_time as update_time " +
												"FROM mst_role r " ;

	private static final String WHERE_STR_ALL = " where EXISTS( "+
																"SELECT 1 FROM mst_system_info " +
																" WHERE [key] = :user_id_key)" +
														" OR EXISTS ( "+
																"SELECT 1 FROM mst_user_role "+
																"where user_id = :user_id and role_id =  r.role_id ) "  ;


	private static final String WHERE_STR = " where EXISTS( "+
																"SELECT 1 FROM mst_system_info " +
																" WHERE [key] = :user_id_key)" +
														" OR EXISTS ( "+
																"SELECT 1 FROM mst_user_role "+
																"where user_id = :user_id and role_id =  :role_id ) "  ;
	@Autowired EntityManager em;


	@Override
	public MstRollEntity findOneForUpdate(int id) {
		return em.find(MstRollEntity.class, id, LockModeType.PESSIMISTIC_WRITE);
	}


	/**
	 * ${inheritDoc}
	 */
	@Override
    public Boolean hasAuthorityByRoleId(String user_id, String role_id) {
		Query q = em.createNativeQuery("SELECT 1 " + WHERE_STR);
		q.setParameter("user_id_key", "SysAdmin_" + user_id);
		q.setParameter("user_id",  user_id);
		q.setParameter("role_id",  role_id);
		try{
			q.getSingleResult();
		}catch (NoResultException e) {
			return false;
		}
		return true;
	}

	/**
	 * ${inheritDoc}
	 */
	@Override
    public Boolean isRoleExist(String role_id) {
		Query q = em.createNativeQuery("SELECT 1 FROM mst_role " +
										" WHERE role_id = :role_id " );
		try{
			q.setParameter("role_id", role_id);
			q.getSingleResult();
		}catch (NoResultException e) {
			return false;
		}
		return true;
	}

	/**
	 * ${inheritDoc}
	 */
	@Override
    public Boolean isSystemAdmin(String user_id) {
		Query q = em.createNativeQuery("SELECT 1 FROM mst_system_info " +
										" WHERE [key] = :user_id_key" );
		try{
			q.setParameter("user_id_key", "SysAdmin_" + user_id);
			q.getSingleResult();
		}catch (NoResultException e) {
			return false;
		}
		return true;
	}

	@Override
	public Long countAll(RollQueryModel query) {
		// SELECT文作成
		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_COUNT_STR + WHERE_STR_ALL;
		String cond = buildCondition(query, params);

		// クエリ作成
		Query q = em.createNativeQuery(sql + cond);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// クエリ実行
		return ((Integer) q.getSingleResult()).longValue();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MstRollEntity> findAll(RollQueryModel query, List<String> sort, Integer limit, Integer offset) {


		Map<String, Object> params = new HashMap<String, Object>();
		String cond = buildCondition(query, params);
		// ORDER BY句作成
		StringBuffer orderBy = new StringBuffer();
		if (sort.size() > 0) {
			orderBy.append(" ORDER BY ");
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderBy.append(col.substring(1) + " desc,");
				} else {
					orderBy.append(col + " asc,");
				}
			}
			orderBy.deleteCharAt(orderBy.length() - 1);
		}

		// クエリ作成
		Query q = em.createNativeQuery(SELECT_STR + WHERE_STR_ALL + cond +  orderBy.toString(), MstRollEntity.class);

		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}



		// ページング設定
		if (offset != null) q.setFirstResult(offset);
		if (limit != null) q.setMaxResults(limit);

		// クエリ実行
		return q.getResultList();

	}

	public <T> long count(List<Predicate> conditionList, Class<T> entity) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<T> root = criteriaQuery.from(entity);
		criteriaQuery.select(builder.count(root));
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	/*private List<Predicate> buildConditionList(RollQueryModel query, Root<MstRollEntity> root) {
		List<Predicate> conditionList = new ArrayList<>();
		if (query.getId() != null && query.getId().length > 0) {
			Object[] arr = Stream.of(query.getId()).map(StringUtil.String2Integer).toArray();
			conditionList.add(root.get("id").in(Arrays.asList(arr)));
		}
		if (query.getRole_id() != null && query.getRole_id().length > 0) {
			conditionList.add(root.get("role_id").in(Arrays.asList(query.getRole_id())));
		}

		if (query.getBase_role_flg() != null && query.getBase_role_flg().length > 0) {
			conditionList.add(root.get("base_role_flg").in(Arrays.asList(query.getBase_role_flg())));
		}
		if (query.getAuthority_role_id() != null && query.getAuthority_role_id().length > 0) {
			conditionList.add(root.get("authority_role_id").in(Arrays.asList(query.getAuthority_role_id())));
		}
		if (query.getName_locale1() != null && query.getName_locale1().length > 0) {
			conditionList.add(root.get("name_locale1").in(Arrays.asList(query.getName_locale1())));
		}
		if (query.getName_locale2() != null && query.getName_locale2().length > 0) {
			conditionList.add(root.get("name_locale2").in(Arrays.asList(query.getName_locale2())));
		}
		if (query.getName_locale3() != null && query.getName_locale3().length > 0) {
			conditionList.add(root.get("name_locale3").in(Arrays.asList(query.getName_locale3())));
		}
		if (query.getDescription_locale1() != null && query.getDescription_locale1().length > 0) {
			conditionList.add(root.get("description_locale1").in(Arrays.asList(query.getDescription_locale1())));
		}
		if (query.getDescription_locale2() != null && query.getDescription_locale2().length > 0) {
			conditionList.add(root.get("description_locale2").in(Arrays.asList(query.getDescription_locale2())));
		}
		if (query.getDescription_locale3() != null && query.getDescription_locale3().length > 0) {
			conditionList.add(root.get("description_locale3").in(Arrays.asList(query.getDescription_locale3())));
		}
		if (query.getNote() != null && query.getNote().length > 0) {
			conditionList.add(root.get("note").in(Arrays.asList(query.getNote())));
		}
		if (query.getVersion() != null && query.getVersion().length > 0) {
			Object[] arr = Stream.of(query.getVersion()).map(StringUtil.String2Long).toArray();
			conditionList.add(root.get("version").in(Arrays.asList(arr)));
		}
		if (query.getInserted() != null && query.getInserted().length > 0) {
			conditionList.add(root.get("inserted").in(Arrays.asList(query.getInserted())));
		}
		if (query.getInsert_time() != null && query.getInsert_time().length > 0) {
			Object[] arr = Stream.of(query.getInsert_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("insert_time").in(Arrays.asList(arr)));
		}
		if (query.getUpdated() != null && query.getUpdated().length > 0) {
			conditionList.add(root.get("updated").in(Arrays.asList(query.getUpdated())));
		}
		if (query.getUpdate_time() != null && query.getUpdate_time().length > 0) {
			Object[] arr = Stream.of(query.getUpdate_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("update_time").in(Arrays.asList(arr)));
		}
		return conditionList;
	}*/
	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(RollQueryModel query, Map<String, Object> params) {
		params.put("user_id_key", "SysAdmin_"+ query.getUser_id());
		params.put("user_id",  query.getUser_id());
		StringBuffer where = new StringBuffer("");

		addCondition(where, params, "id", query.getId());
		addCondition(where, params, "role_id", query.getRole_id());
		addCondition(where, params, "base_role_flg", query.getBase_role_flg());
		addCondition(where, params, "authority_role_id", query.getAuthority_role_id());
		addCondition(where, params, "name_locale1", query.getName_locale1());
		addCondition(where, params, "name_locale2", query.getName_locale2());
		addCondition(where, params, "name_locale3", query.getName_locale3());
		addCondition(where, params, "description_locale1", query.getDescription_locale1());
		addCondition(where, params, "description_locale2", query.getDescription_locale2());
		addCondition(where, params, "description_locale3", query.getDescription_locale3());
		addCondition(where, params, "note", query.getNote());
		addCondition(where, params, "version", query.getVersion());
		addCondition(where, params, "inserted", query.getInserted());
		addCondition(where, params, "insert_time", query.getInsert_time());
		addCondition(where, params, "updated", query.getUpdated());
		addCondition(where, params, "update_time", query.getUpdate_time());

		return where.toString();
	}
	/**
	 * WHERE句用検索条件追加
	 * 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0) return;
		where.append(" AND ");
		where.append(col + " in (");
		for (int i = 0; i < values.length; i++) {
			String name = col + "_" + i;
			where.append(":").append(name).append(",");
			params.put(name, values[i]);
		}
		where.deleteCharAt(where.length()-1);
		where.append(")");
	}

}
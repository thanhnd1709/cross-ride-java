package com.app.repository.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.PostExpansionFileEntity;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.PostMeasureFileQueryModel;
import com.app.repository.PostFileRepositoryCustom;
import com.app.service.PostExpansionFileService;

/**
 * ファイル登録センサー権限チェックリポジトリ実装クラス
 * @author 1572
 */
@Component
public class PostFileRepositoryImpl implements PostFileRepositoryCustom {
	private static final String SELECT_STR1 = "SELECT ";
	private static final String SELECT_STR2 = " (:model_id) as model_id,"
												+ "(:serial_no) as serial_no,"
												+ "(:sensor_id) as sensor_id "
												+ "WHERE dbo.fn_SensorAuthChk("
												+ "(:model_id),"
												+ "(:serial_no),"
												+ "(:sensor_id),"
												+ "(:user_id),"
												+ "(:url),"
												+ "(:method)) IS NULL ";
	
	private static final String MODEL_STR1 = " (:model_id";
	private static final String SERIAL_STR1 = ") as model_id,(:serial_no";
	private static final String SENSOR_STR1 = ") as serial_no,(:sensor_id";
	private static final String MODEL_STR2 = ") as sensor_id WHERE dbo.fn_SensorAuthChk((:model_id";
	private static final String SERIAL_STR2 ="),(:serial_no";
	private static final String SENSOR_STR2 ="),(:sensor_id";
	private static final String WHERE_STR ="),(:user_id),(:url),(:method)) IS NULL ";

	@PersistenceContext EntityManager em;
	@Autowired PostExpansionFileService s;
	@Autowired AuthUserInfoComponent authUserInfo;

	@SuppressWarnings("unchecked")
	@Override
	public List<PostExpansionFileEntity> sensorAuthChk(PostMeasureFileQueryModel query, Locale locale) {
		// SELECT句、FROM句作成
		StringBuffer sql = new StringBuffer(SELECT_STR1);
		sql.append(SELECT_STR2);

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("model_id", query.getModel_id());
		params.put("serial_no", query.getSerial_no());
		params.put("sensor_id", query.getSensor_id());
		params.put("user_id", query.getUser_id());
		params.put("url", "/v1/sensor-data-file-mgt/measureFile");
		params.put("method", "POST");

		// クエリ作成
		Query q = em.createNativeQuery(sql.toString(),PostExpansionFileEntity.class);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// クエリ実行
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PostExpansionFileEntity> sensorAuthChk( List<String> list, String userId) {
		// SELECT句、FROM句作成
		StringBuffer sql = new StringBuffer(SELECT_STR1);

		for (int i = 0; i < list.size(); i++) {
			sql.append(MODEL_STR1 + i);
			sql.append(SERIAL_STR1 + i);
			sql.append(SENSOR_STR1 + i);
			sql.append(MODEL_STR2 + i);
			sql.append(SERIAL_STR2 + i);
			sql.append(SENSOR_STR2 + i);
			sql.append(WHERE_STR);

			if(i+1 < list.size()) sql.append(" UNION SELECT ");
		}

		Query q = em.createNativeQuery(sql.toString(),PostExpansionFileEntity.class);

		Map<String, Object> params = new HashMap<String, Object>();
		String strVal = "";
		String modelId = "";
		String serialNo = "";
		String sensorId = "";
		for (int i = 0; i < list.size(); i++) {
			strVal = list.get(i);
			modelId = (strVal.substring(0, strVal.indexOf("$")));
			strVal = (strVal.substring(strVal.indexOf("$")+1));
			serialNo = (strVal.substring(0, strVal.indexOf("$")));
			sensorId = (strVal.substring(strVal.indexOf("$")+1));
			params.put("model_id" + i, modelId);
			params.put("serial_no" + i, serialNo);
			params.put("sensor_id" + i, sensorId);
			params.put("user_id", userId);
			params.put("url", "/v1/sensor-data-file-mgt/expansionFile");
			params.put("method", "POST");

			// クエリ作成
			Set<String> keys = params.keySet();
			for (String key : keys) {
				q.setParameter(key, params.get(key));
			}
			params.clear();
		}
		// クエリ実行
		return q.getResultList();
	}
}

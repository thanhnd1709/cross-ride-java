package com.app.repository;

import com.app.entity.DevDayDataEntity;
import com.microsoft.azure.storage.table.CloudTable;

/**
 * 日別計測データリポジトリクラス
 * @author（TOSCO）ウェイ
 */
public interface DevDayDataRepositoryCustom{

	/**
	 * 日別別計測データ（全データ）取得処理を行います。
	 * @return 日別別計測データ
	 */
	Iterable<DevDayDataEntity> searchAll(String partitionKey, String dateFrom, String dateTo,
			boolean hasHrMinSec, CloudTable cloudTable) throws Exception;

	/**
	 * 日別別計測データ（最初のデータ1件）取得処理を行います。
	 * @return 日別別計測データ
	 */
	DevDayDataEntity searchFirst(String partitionKey, String dateFrom, String dateTo,
			boolean hasHrMinSec, CloudTable cloudTable) throws Exception;

	/**
	 * 日別別計測データ（最後のデータ1件）取得処理を行います。
	 * @return 日別別計測データ
	 */
	DevDayDataEntity searchLast(String partitionKey, String dateFrom, String dateTo,
			boolean hasHrMinSec, CloudTable cloudTable) throws Exception;
}
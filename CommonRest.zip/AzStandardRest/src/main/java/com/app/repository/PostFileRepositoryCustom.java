package com.app.repository;

import java.util.List;
import java.util.Locale;

import com.app.entity.PostExpansionFileEntity;
import com.app.model.PostMeasureFileQueryModel;

public interface PostFileRepositoryCustom {

	List<PostExpansionFileEntity> sensorAuthChk(PostMeasureFileQueryModel query, Locale locale);
	List<PostExpansionFileEntity> sensorAuthChk(List<String> list, String userId);
}

package com.app.repository.imple;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.StdNewMeasureDataEntity;
import com.app.repository.StdNewMeasureDataRepositoryCustom;

/**
 * 計測データの最新値リポジトリ実装クラス
 * @author（TOSCO）ウェイ
 */
@Component
public class StdNewMeasureDataRepositoryCustomImple implements StdNewMeasureDataRepositoryCustom {

	@Autowired EntityManager em;

	@Override
	public List<StdNewMeasureDataEntity> search(String modelId, String serialNo, String sensorId)
			throws Exception {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<StdNewMeasureDataEntity> query = builder.createQuery(StdNewMeasureDataEntity.class);
		Root<StdNewMeasureDataEntity> root = query.from(StdNewMeasureDataEntity.class);

		List<Predicate> where = new ArrayList<>();
		// 機種ID
		if (modelId != null) where.add(builder.equal(root.get("model_id"), modelId));
		// シリアルNo
		if (serialNo != null) where.add(builder.equal(root.get("serial_no"), serialNo));
		// センサーID
		if (sensorId != null) where.add(builder.equal(root.get("sensor_id"), sensorId));
		if( where.size() > 0 ) query.where(where.toArray(new Predicate[where.size()]));

		return em.createQuery(query).getResultList();
	}

	@Override
	public List<StdNewMeasureDataEntity> lock(String modelId, String serialNo, String sensorId
														, Date dateFrom, Date dateTo) throws Exception {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<StdNewMeasureDataEntity> query = builder.createQuery(StdNewMeasureDataEntity.class);
		Root<StdNewMeasureDataEntity> root = query.from(StdNewMeasureDataEntity.class);

		List<Predicate> where = new ArrayList<>();
		// 機種ID
		if (modelId != null) where.add(builder.equal(root.get("model_id"), modelId));
		// シリアルNo
		if (serialNo != null) where.add(builder.equal(root.get("serial_no"), serialNo));
		// センサーID
		if (sensorId != null) where.add(builder.equal(root.get("sensor_id"), sensorId));
		// 計測時間
		if(dateFrom.compareTo(dateTo) == 0){
			where.add(builder.equal(root.get("measure_time"), dateFrom));
		}else{
			where.add(builder.greaterThanOrEqualTo(root.get("measure_time"), dateFrom));
			where.add(builder.lessThan(root.get("measure_time"), dateTo));
		}
		if( where.size() > 0 ) query.where(where.toArray(new Predicate[where.size()]));

		TypedQuery<StdNewMeasureDataEntity> typedQuery = em.createQuery(query);
		typedQuery.setLockMode(LockModeType.PESSIMISTIC_WRITE);

		return em.createQuery(query).getResultList();
	}

	@Override
	public void update(String modelId, String serialNo, String sensorId, Date dateFrom,
			Date dateTo, String measureTime, String measureData) throws Exception {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaUpdate<StdNewMeasureDataEntity> query = builder.createCriteriaUpdate(StdNewMeasureDataEntity.class);
		Root<StdNewMeasureDataEntity> root = query.from(StdNewMeasureDataEntity.class);

		query.set("measure_time", DateTimeUtil.toTimestamp(measureTime));
		query.set("measure_data", measureData);

		List<Predicate> where = new ArrayList<>();
		// 機種ID
		if (modelId != null) where.add(builder.equal(root.get("model_id"), modelId));
		// シリアルNo
		if (serialNo != null) where.add(builder.equal(root.get("serial_no"), serialNo));
		// センサーID
		if (sensorId != null) where.add(builder.equal(root.get("sensor_id"), sensorId));
		// 計測時間
		if(dateFrom.compareTo(dateTo) == 0){
			where.add(builder.equal(root.get("measure_time"), dateFrom));
		}else{
			where.add(builder.greaterThanOrEqualTo(root.get("measure_time"), dateFrom));
			where.add(builder.lessThan(root.get("measure_time"), dateTo));
		}
		if( where.size() > 0 ) query.where(where.toArray(new Predicate[where.size()]));

		em.createQuery(query).executeUpdate();
	}
}

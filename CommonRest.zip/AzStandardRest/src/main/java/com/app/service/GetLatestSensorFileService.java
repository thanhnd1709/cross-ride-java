package com.app.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.common.Consts;
import com.app.entity.MstSensorEntity;
import com.app.entity.StdFileInfoEntity;
import com.app.exception.IoTSQLException;
import com.app.model.ResponseFileModel;
import com.app.model.SensorLatestFileModel;
import com.app.model.SensorModel1;
import com.app.model.SensorModel2;
import com.app.model.SensorModel3;
import com.app.repository.MstSensorRepositoryCustom;
import com.app.repository.StdFileInfoRepositoryCustom;

/**
 * センサー最新ファイル情報取得サービスクラス
 * @author（TOSCO）ウェイ
 */
@Service
public class GetLatestSensorFileService {

	@Autowired
	private MstSensorRepositoryCustom _sensorRepoCustom;
	@Autowired
	private StdFileInfoRepositoryCustom _stdFileRepoCustom;

	/**
	 * 最新センサーファイル情報取得処理
	 * @return 最新センサーファイル情報リスト
	 */
	public List<ResponseFileModel> getLatestSensorFileInfo(SensorLatestFileModel reqModel) throws Exception{

		// 取得フィールド処理
		ModelFilter mf = makeModelFilter(reqModel.getFields());

		// ソート処理
		String sort = null;
		if (reqModel.getSort() != null) {
			for (String item : reqModel.getSort().split(",")) {
				if(sort != null){
					sort += ", ";
				}else{
					sort ="";
				}
				if(item.startsWith("-")){
					sort += (item.toLowerCase()).replace("-", "") + " DESC";
				}else{
					sort += item.toLowerCase();
				}
			}
		}

		// ページング処理
		Integer limit = null;
		Integer offset = null;
		if (reqModel.getPage() != null && reqModel.getLimit() != null) {
			limit = Integer.parseInt(reqModel.getLimit());
			offset = (Integer.parseInt(reqModel.getPage()) - 1) * limit;
		}

		/***********************************
		 * 最新センサーファイル情報取得処理
		 ***********************************/
		List<ResponseFileModel> lstResponse = new ArrayList<>();
		String modelId = "";
		String serialNo = "";

		try {
			// センサー情報を整理する
			List<SensorModel2> ssModel = this.arrangeSensorInfo(reqModel.getSensor_list());

			List<SensorModel3> sensorList = new ArrayList<>();

			// センサーデータ取得処理
			for(SensorModel2 model : ssModel){
				// 機種ID、シリアルNo
				modelId = model.getModel_id();
				serialNo = model.getSerial_no();

				for(String ssId : model.getSensor_id_list()){
					// センサー情報取得
					List<MstSensorEntity> lstSensorEntity = _sensorRepoCustom.find(modelId, serialNo, ssId, Consts.MEASURE_TYPE_2);

					// 該当センサー情報が存在しない場合、
					if(lstSensorEntity == null || lstSensorEntity.size() <= 0){
						continue;
					}

					// 該当センサー情報が存在する場合
					for(MstSensorEntity sensorEntity : lstSensorEntity){
						sensorList.add(new SensorModel3(modelId, serialNo, sensorEntity.getSensor_id()));
					}
				}
			}
			if (sensorList.size() == 0) return new ArrayList<>();

			// 計測ファイル情報取得
			List<StdFileInfoEntity> lstEntity= new ArrayList<>();
			lstEntity = _stdFileRepoCustom.searchLast(reqModel, sensorList, sort, limit, offset);

			for (StdFileInfoEntity entity : lstEntity){
				ResponseFileModel resFileModel = new ResponseFileModel();

				if (mf.id) resFileModel.setId(String.valueOf(entity.getId()));
				if (mf.model_id) resFileModel.setModel_id(String.valueOf(entity.getModel_id()));
				if (mf.serial_no) resFileModel.setSerial_no(String.valueOf(entity.getSerial_no()));
				if (mf.sensor_id) resFileModel.setSensor_id(String.valueOf(entity.getSensor_id()));
				if (mf.measure_time) resFileModel.setMeasure_time(entity.getMeasure_time());
				if (mf.upload_time) resFileModel.setUpload_time(entity.getUpload_time());
				if (mf.zip_flg) resFileModel.setZip_flg(entity.getZip_flg());
				if (mf.file_name) resFileModel.setFile_name(entity.getFile_name());
				if (mf.hash) resFileModel.setHash(entity.getHash());
				if (mf.sender_device_id) resFileModel.setSender_device_id(entity.getSender_device_id());
				if (mf.notice_time) resFileModel.setNotice_time(entity.getNotice_time());
				if (mf.reserve1) resFileModel.setReserve1(entity.getReserve1());
				if (mf.reserve2) resFileModel.setReserve2(entity.getReserve2());
				if (mf.reserve3) resFileModel.setReserve3(entity.getReserve3());
				if (mf.reserve4) resFileModel.setReserve4(entity.getReserve4());
				if (mf.reserve5) resFileModel.setReserve5(entity.getReserve5());
				if (mf.other_metadata) resFileModel.setOther_metadata(entity.getOther_metadata());
				if (mf.upload_user_id) resFileModel.setUpload_user_id(entity.getUpload_user_id());
				lstResponse.add(resFileModel);
			}
		}catch (Exception e) {
			throw new IoTSQLException(e);
		}

		return lstResponse;

	}

	/**
	 * センサー情報整理処理
	 * @return 整理したセンサー情報リスト
	 */
	private List<SensorModel2> arrangeSensorInfo(List<SensorModel1> sensorList){

		// センサーリストをソートする
		Collections.sort(sensorList, new BeanComparator<SensorModel1>("serial_no"));
		Collections.sort(sensorList, new BeanComparator<SensorModel1>("model_id"));

		// センサー情報を整理する
		List<SensorModel2> ssModel = new ArrayList<>();
		String modelId = "";
		String serialNo = "";
		List<String> ssIdList = null;
		for(SensorModel1 sensor : sensorList){

			if("".equals(modelId) && "".equals(serialNo)) {
				modelId = sensor.getModel_id();
				serialNo = sensor.getSerial_no();
				ssIdList = new ArrayList<>();
			}else{
				if(!modelId.equals(sensor.getModel_id()) || !serialNo.equals(sensor.getSerial_no())){
					ssModel.add(new SensorModel2(modelId, serialNo
							, ssIdList.stream().distinct().collect(Collectors.toList())));
					modelId = sensor.getModel_id();
					serialNo = sensor.getSerial_no();
					ssIdList = new ArrayList<>();
				}
			}
			ssIdList.add(sensor.getSensor_id());
		}
		ssModel.add(new SensorModel2(modelId, serialNo, ssIdList.stream().distinct().collect(Collectors.toList())));
		return ssModel;
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("sensor_id".equals(str)) mf.sensor_id = true;
				if ("measure_time".equals(str)) mf.measure_time = true;
				if ("upload_time".equals(str)) mf.upload_time = true;
				if ("zip_flg".equals(str)) mf.zip_flg = true;
				if ("file_name".equals(str)) mf.file_name = true;
				if ("hash".equals(str)) mf.hash = true;
				if ("sender_device_id".equals(str)) mf.sender_device_id = true;
				if ("notice_time".equals(str)) mf.notice_time = true;
				if ("reserve1".equals(str)) mf.reserve1 = true;
				if ("reserve2".equals(str)) mf.reserve2 = true;
				if ("reserve3".equals(str)) mf.reserve3 = true;
				if ("reserve4".equals(str)) mf.reserve4 = true;
				if ("reserve5".equals(str)) mf.reserve5 = true;
				if ("other_metadata".equals(str)) mf.other_metadata = true;
				if ("upload_user_id".equals(str)) mf.upload_user_id = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			model_id = b;
			serial_no = b;
			sensor_id = b;
			measure_time = b;
			upload_time = b;
			zip_flg = b;
			file_name = b;
			hash = b;
			sender_device_id = b;
			notice_time = b;
			reserve1 = b;
			reserve2 = b;
			reserve3 = b;
			reserve4 = b;
			reserve5 = b;
			other_metadata = b;
			upload_user_id = b;
		}
		public boolean id = true;
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean sensor_id = true;
		public boolean measure_time = true;
		public boolean upload_time = true;
		public boolean zip_flg = true;
		public boolean file_name = true;
		public boolean hash = true;
		public boolean sender_device_id = true;
		public boolean notice_time = true;
		public boolean reserve1 = true;
		public boolean reserve2 = true;
		public boolean reserve3 = true;
		public boolean reserve4 = true;
		public boolean reserve5 = true;
		public boolean other_metadata = true;
		public boolean upload_user_id = true;
	}
}

package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.StringUtil;
import com.app.entity.EventStatusEntity;
import com.app.model.EventStatusListModel;
import com.app.model.EventStatusModel;
import com.app.model.ResponseEventStatusModel;
import com.app.repository.EventStatusRepositoryCustom;

/**
 * イベント・アラーム状態取得コントローラクラス
 * @author（TOSCO）エヒー
 */
@Service
@Transactional(readOnly = true)
public class EventStatusService {

	@Autowired private EventStatusRepositoryCustom eventStatusRepositoryCustom;

	public List<ResponseEventStatusModel> GetEventStatus(EventStatusModel reqModel) throws Exception{

		List<ResponseEventStatusModel> eventStatusLst = new ArrayList<>();

		// 取得フィールド処理
		ModelFilter mf = makeModelFilter(reqModel.getFields());

		// ソート処理
		String sort = null;
		if (reqModel.getSort() != null) {
			for (String item : reqModel.getSort().split(",")) {
				if (sort != null) {
					sort += ", ";
				} else {
					sort = "";
				}
				if (item.startsWith("-")) {
					sort += (item.toLowerCase()).replace("-", "") + " DESC";
				} else {
					sort += item.toLowerCase();
				}
			}
		}


		// ページング処理
		Integer limit2 = null;
		Integer limit = null;
		Integer offset = null;
		if (reqModel.getMax_number() != null && reqModel.getPage() == null && reqModel.getLimit() == null){
			 offset = 0;
			 limit = (reqModel.getMax_number());
		}
		if (reqModel.getPage() != null && reqModel.getLimit() != null) {

			if (reqModel.getMax_number() != null && reqModel.getMax_number() < Integer.parseInt(reqModel.getLimit())){
				limit = reqModel.getMax_number();
			}else{
				limit = Integer.parseInt(reqModel.getLimit());
			}
			limit2 =  Integer.parseInt(reqModel.getLimit());
			offset = (Integer.parseInt(reqModel.getPage()) - 1) * limit2;
		}

		// イベント・アラーム状態取得処理
		ResponseEventStatusModel model = new  ResponseEventStatusModel();
		List<EventStatusListModel> modelList= new ArrayList<>();
		List<EventStatusEntity> entList = new ArrayList<>();

		if (!StringUtil.IsNullOrEmpty(reqModel.getDevice_group_id()) && !StringUtil.IsBlank(reqModel.getDevice_group_id())) {

			// ①デバイスグループID指定時 かつ 親子展開フラグがtrueの時、
			if (reqModel.getParent_flg() != null && reqModel.getParent_flg() == true) {
				entList = eventStatusRepositoryCustom.searchDeviceGroupIdTrue(reqModel, sort, limit, offset);
			}
			// ②デバイスグループID指定時 かつ 親子展開フラグがfalseの時、
			else if (reqModel.getParent_flg() == null || reqModel.getParent_flg() == false) {
				entList = eventStatusRepositoryCustom.searchDeviceGroupIdFalse(reqModel, sort, limit, offset);
			}
		}

		else if (reqModel.getDevice_list() != null && reqModel.getDevice_list().size() > 0) {

			// ③[配列]デバイスリスト指定時 かつ 親子展開フラグがtrueの時、
			if (reqModel.getParent_flg() != null && reqModel.getParent_flg() == true) {
				entList = eventStatusRepositoryCustom.searchDeviceListTrue(reqModel, sort, limit, offset);
			}

			// ④[配列]デバイスリスト指定時 かつ 親子展開フラグがfalseの時、
			else if (reqModel.getParent_flg() == null || reqModel.getParent_flg() == false) {
				entList = eventStatusRepositoryCustom.searchDeviceListFalse(reqModel, sort, limit, offset);
			}
		}

		// ⑤デバイスグループID、[配列]デバイスリスト未指定時、
		else if (reqModel.getDevice_group_id() == null && reqModel.getDevice_list() == null) {
			entList = eventStatusRepositoryCustom.search(reqModel, sort, limit, offset);
		}

		for(EventStatusEntity eventEntity : entList){
			EventStatusListModel eventStatusModel = new EventStatusListModel();

			if(mf.model_id) eventStatusModel.setModel_id(eventEntity.getModel_id());
			if(mf.serial_no) eventStatusModel.setSerial_no(eventEntity.getSerial_no());
			if(mf.detection_class) eventStatusModel.setDetection_class(eventEntity.getDetection_class());
			if(mf.id) eventStatusModel.setId(eventEntity.getId());
			if(mf.event_time) eventStatusModel.setEvent_time(eventEntity.getEvent_time());
			if(mf.event_id) eventStatusModel.setEvent_id(eventEntity.getEvent_id());
			if(mf.event_status) eventStatusModel.setEvent_status(eventEntity.getEvent_status());
			if(mf.incident_class) eventStatusModel.setIncident_class(eventEntity.getIncident_class());
			if(mf.event_level) eventStatusModel.setEvent_level(eventEntity.getEvent_level());
			if(mf.cope_status) eventStatusModel.setCope_status(eventEntity.getCope_status());
			if(mf.incident_time) eventStatusModel.setIncident_time(eventEntity.getIncident_time());
			if(mf.return_time) eventStatusModel.setReturn_time(eventEntity.getReturn_time());
			if(mf.version) eventStatusModel.setVersion(eventEntity.getVersion());
			if(mf.event_type) eventStatusModel.setEvent_type(eventEntity.getEvent_type());
			if(mf.sensor_id) eventStatusModel.setSensor_id(eventEntity.getSensor_id());
			if(mf.name_locale1) eventStatusModel.setName_locale1(eventEntity.getName_locale1());
			if(mf.name_locale2) eventStatusModel.setName_locale2(eventEntity.getName_locale2());
			if(mf.name_locale3) eventStatusModel.setName_locale3(eventEntity.getName_locale3());
			if(mf.description_locale1) eventStatusModel.setDescription_locale1(eventEntity.getDescription_locale1());
			if(mf.description_locale2) eventStatusModel.setDescription_locale2(eventEntity.getDescription_locale2());
			if(mf.description_locale3) eventStatusModel.setDescription_locale3(eventEntity.getDescription_locale3());
			if(mf.chk_app_name) eventStatusModel.setChk_app_name(eventEntity.getChk_app_name());
			if(mf.chk_app_parameter) eventStatusModel.setChk_app_parameter(eventEntity.getChk_app_parameter());
			if(mf.check_timing) eventStatusModel.setCheck_timing(eventEntity.getCheck_timing());
			if(mf.note) eventStatusModel.setNote(eventEntity.getNote());
			modelList.add(eventStatusModel);
		}
		model.setTotal(modelList.size());
		model.setEvent_status_list(modelList);
		eventStatusLst.add(model);
		return eventStatusLst;
	}

	private ModelFilter makeModelFilter(String fields){
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if("model_id".equals(str)) mf.model_id = true;
				if("serial_no".equals(str)) mf.serial_no = true;
				if("detection_class".equals(str)) mf.detection_class = true;
				if("id".equals(str)) mf.id = true;
				if("event_time".equals(str)) mf.event_time = true;
				if("event_id".equals(str)) mf.event_id = true;
				if("event_status".equals(str)) mf.event_status = true;
				if("incident_class".equals(str)) mf.incident_class = true;
				if("event_level".equals(str)) mf.event_level = true;
				if("cope_status".equals(str)) mf.cope_status = true;
				if("incident_time".equals(str)) mf.incident_time = true;
				if("return_time".equals(str)) mf.return_time = true;
				if("version".equals(str)) mf.version = true;
				if("event_type".equals(str)) mf.event_type = true;
				if("sensor_id".equals(str)) mf.sensor_id = true;
				if("name_locale1".equals(str)) mf.name_locale1 = true;
				if("name_locale2".equals(str)) mf.name_locale2 = true;
				if("name_locale3".equals(str)) mf.name_locale3 = true;
				if("description_locale1".equals(str)) mf.description_locale1 = true;
				if("description_locale2".equals(str)) mf.description_locale2 = true;
				if("description_locale3".equals(str)) mf.description_locale3 = true;
				if("chk_app_name".equals(str)) mf.chk_app_name = true;
				if("chk_app_parameter".equals(str)) mf.chk_app_parameter = true;
				if("check_timing".equals(str)) mf.check_timing = true;
				if("note".equals(str)) mf.note = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			model_id = b;
			serial_no = b;
			detection_class = b;
			id = b;
			event_time = b;
			event_id = b;
			event_status = b;
			incident_class = b;
			event_level = b;
			cope_status = b;
			incident_time = b;
			return_time = b;
			version = b;
			event_type = b;
			sensor_id = b;
			name_locale1 = b;
			name_locale2 = b;
			name_locale3 = b;
			description_locale1 = b;
			description_locale2 = b;
			description_locale3 = b;
			chk_app_name = b;
			chk_app_parameter = b;
			check_timing = b;
			note = b;

		}

		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean detection_class = true;
		public boolean id = true;
		public boolean event_time = true;
		public boolean event_id = true;
		public boolean event_status = true;
		public boolean incident_class = true;
		public boolean event_level = true;
		public boolean cope_status = true;
		public boolean incident_time = true;
		public boolean return_time = true;
		public boolean version = true;
		public boolean event_type = true;
		public boolean sensor_id = true;
		public boolean name_locale1 = true;
		public boolean name_locale2 = true;
		public boolean name_locale3 = true;
		public boolean description_locale1 = true;
		public boolean description_locale2 = true;
		public boolean description_locale3 = true;
		public boolean chk_app_name = true;
		public boolean chk_app_parameter = true;
		public boolean check_timing = true;
		public boolean note = true;

	}
}


package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.UserProgramAuthorityEntity;
import com.app.model.UserProgramAuthorityModel;
import com.app.model.UserProgramAuthorityQueryModel;
import com.app.repository.UserProgramAuthorityRepository;

/**
 * ユーザ・プログラム権限情報取得サービスクラス
 * @author 9571
 *
 */
@Service
@Transactional(readOnly = true)
public class UserProgramAuthorityService {
	@Autowired
	private UserProgramAuthorityRepository userProgramAuthorityRepository;

	/**
	 * ユーザ・プログラム権限情報取得
	 * @param filter 検索条件オブジェクト
	 * @return ユーザ・プログラム権限情報リスト
	 * @throws Exception
	 */
	public List<UserProgramAuthorityModel> getUserProgramAuthority(UserProgramAuthorityQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		// 検索実行
		List<UserProgramAuthorityEntity> entList = userProgramAuthorityRepository.getUserProgramAuthority(filter, sort, limit, offset);

		// 返却項目フィルタ処理
		List<UserProgramAuthorityModel> modelList = new ArrayList<UserProgramAuthorityModel>();
		for (UserProgramAuthorityEntity entity : entList) {
			UserProgramAuthorityModel newModel = new UserProgramAuthorityModel();
			if (mf.role_id) newModel.setRole_id(entity.getRole_id());
			if (mf.authority_id) newModel.setAuthority_id(entity.getAuthority_id());
			if (mf.authority_type) newModel.setAuthority_type(entity.getAuthority_type());
			if (mf.program_name_locale1) newModel.setProgram_name_locale1(entity.getProgram_name_locale1());
			if (mf.program_name_locale2) newModel.setProgram_name_locale2(entity.getProgram_name_locale2());
			if (mf.program_name_locale3) newModel.setProgram_name_locale3(entity.getProgram_name_locale3());
			if (mf.program_description_locale1) newModel.setProgram_description_locale1(entity.getProgram_description_locale1());
			if (mf.program_description_locale2) newModel.setProgram_description_locale2(entity.getProgram_description_locale2());
			if (mf.program_description_locale3) newModel.setProgram_description_locale3(entity.getProgram_description_locale3());
			if (mf.program_id) newModel.setProgram_id(entity.getProgram_id());
			if (mf.url) newModel.setUrl(entity.getUrl());
			if (mf.method) newModel.setMethod(entity.getMethod());
			if (mf.program_note) newModel.setProgram_note(entity.getProgram_note());
			if (mf.role_name_locale1) newModel.setRole_name_locale1(entity.getRole_name_locale1());
			if (mf.role_name_locale2) newModel.setRole_name_locale2(entity.getRole_name_locale2());
			if (mf.role_name_locale3) newModel.setRole_name_locale3(entity.getRole_name_locale3());
			if (mf.role_description_locale1) newModel.setRole_description_locale1(entity.getRole_description_locale1());
			if (mf.role_description_locale2) newModel.setRole_description_locale2(entity.getRole_description_locale2());
			if (mf.role_description_locale3) newModel.setRole_description_locale3(entity.getRole_description_locale3());
			if (mf.role_note) newModel.setRole_note(entity.getRole_note());

			modelList.add(newModel);
		}
		return modelList;
	}

	/**
	 * ユーザ・プログラム権限情報一覧件数取得
	 * @param filter 検索条件オブジェクト
	 * @return 検索結果件数
	 * @throws Exception
	 */
	public Long countAll(UserProgramAuthorityQueryModel filter) throws Exception{
		return userProgramAuthorityRepository.countAll(filter);
	}

	/**
	 * 返却項目フィルター作成
	 * @param fields 取得対象項目名リスト（カンマ区切り）
	 * @return フィルターオブジェクト
	 */
	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("role_id".equals(str)) mf.role_id = true;
				if ("authority_id".equals(str)) mf.authority_id = true;
				if ("authority_type".equals(str)) mf.authority_type = true;
				if ("program_name_locale1".equals(str)) mf.program_name_locale1 = true;
				if ("program_name_locale2".equals(str)) mf.program_name_locale2 = true;
				if ("program_name_locale3".equals(str)) mf.program_name_locale3 = true;
				if ("program_description_locale1".equals(str)) mf.program_description_locale1 = true;
				if ("program_description_locale2".equals(str)) mf.program_description_locale2 = true;
				if ("program_description_locale3".equals(str)) mf.program_description_locale3 = true;
				if ("program_id".equals(str)) mf.program_id = true;
				if ("url".equals(str)) mf.url = true;
				if ("method".equals(str)) mf.method = true;
				if ("program_note".equals(str)) mf.program_note = true;
				if ("role_name_locale1".equals(str)) mf.role_name_locale1 = true;
				if ("role_name_locale2".equals(str)) mf.role_name_locale2 = true;
				if ("role_name_locale3".equals(str)) mf.role_name_locale3 = true;
				if ("role_description_locale1".equals(str)) mf.role_description_locale1 = true;
				if ("role_description_locale2".equals(str)) mf.role_description_locale2 = true;
				if ("role_description_locale3".equals(str)) mf.role_description_locale3 = true;
				if ("role_note".equals(str)) mf.role_note = true;
			}
		}
		return mf;
	}

	/**
	 * 返却項目フィルタークラス
	 * true=返却する。false=返却しない。
	 *
	 */
	class ModelFilter {
		public ModelFilter(boolean b) {
			role_id = b;
			authority_id = b;
			authority_type = b;
			program_name_locale1 = b;
			program_name_locale2 = b;
			program_name_locale3 = b;
			program_description_locale1 = b;
			program_description_locale2 = b;
			program_description_locale3 = b;
			program_id = b;
			url = b;
			method = b;
			program_note = b;
			role_name_locale1 = b;
			role_name_locale2 = b;
			role_name_locale3 = b;
			role_description_locale1 = b;
			role_description_locale2 = b;
			role_description_locale3 = b;
			role_note = b;

		}
		public boolean role_id = true;
		public boolean authority_id = true;
		public boolean authority_type = true;
		public boolean program_name_locale1 = true;
		public boolean program_name_locale2 = true;
		public boolean program_name_locale3 = true;
		public boolean program_description_locale1 = true;
		public boolean program_description_locale2 = true;
		public boolean program_description_locale3 = true;
		public boolean program_id = true;
		public boolean url = true;
		public boolean method = true;
		public boolean program_note = true;
		public boolean role_name_locale1 = true;
		public boolean role_name_locale2 = true;
		public boolean role_name_locale3 = true;
		public boolean role_description_locale1 = true;
		public boolean role_description_locale2 = true;
		public boolean role_description_locale3 = true;
		public boolean role_note = true;
	}
}


package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstRoleRootGroupEntity;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.RoleRootGroupModel;
import com.app.model.RoleRootGroupQueryModel;
import com.app.repository.RoleRootGroupRepository;

@Service
@Transactional(readOnly = true)
public class RoleRootGroupService {

	@Autowired
	private RoleRootGroupRepository roleRootGroupRepository;

	public RoleRootGroupModel findOne(int uuid, String fields) throws Exception{
		ModelFilter mf = makeModelFilter(fields);

		MstRoleRootGroupEntity entity = roleRootGroupRepository.findOne(uuid);
		RoleRootGroupModel newModel = null;
		if (entity != null) {
			newModel = new RoleRootGroupModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.role_id) newModel.setRole_id(entity.getRole_id());
			if (mf.root_group_id) newModel.setRoot_group_id(entity.getRoot_group_id());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}
		return  newModel;
	}

	public List<RoleRootGroupModel> findAll(RoleRootGroupQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<MstRoleRootGroupEntity> entList = roleRootGroupRepository.findAll(filter, sort, limit, offset);
		List<RoleRootGroupModel> modelList = new ArrayList<RoleRootGroupModel>();
		for (MstRoleRootGroupEntity entity : entList) {
			RoleRootGroupModel newModel = new RoleRootGroupModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.role_id) newModel.setRole_id(entity.getRole_id());
			if (mf.root_group_id) newModel.setRoot_group_id(entity.getRoot_group_id());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(RoleRootGroupQueryModel filter) throws Exception{
		return roleRootGroupRepository.countAll(filter);
	}

	@Transactional(readOnly = false)
	public RoleRootGroupModel save(RoleRootGroupModel model) throws Exception{

		MstRoleRootGroupEntity newRec = new MstRoleRootGroupEntity();

		if (model.getRole_id() != null) newRec.setRole_id(model.getRole_id());
		if (model.getRoot_group_id() != null) newRec.setRoot_group_id(model.getRoot_group_id());
		newRec.setVersion(0L);

		newRec = roleRootGroupRepository.save(newRec);

		RoleRootGroupModel newModel = new RoleRootGroupModel();
		newModel.setId(newRec.getId());
		newModel.setRole_id(newRec.getRole_id());
		newModel.setRoot_group_id(newRec.getRoot_group_id());
		newModel.setVersion(newRec.getVersion());
		newModel.setInserted(newRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdated(newRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public RoleRootGroupModel update(Locale locale,int id, RoleRootGroupModel model) throws Exception{
		MstRoleRootGroupEntity rec = roleRootGroupRepository.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.roleRootGroupInfo")});
			throw exp;
		}

		rec.setRole_id(model.getRole_id());
		rec.setRoot_group_id(model.getRoot_group_id());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.roleRootGroupInfo")});
			throw exp;
		}

		roleRootGroupRepository.saveAndFlush(rec);
		MstRoleRootGroupEntity updateRec = roleRootGroupRepository.findOne(id);
		RoleRootGroupModel newModel = new RoleRootGroupModel();
		newModel.setId(updateRec.getId());
		newModel.setRole_id(updateRec.getRole_id());
		newModel.setRoot_group_id(updateRec.getRoot_group_id());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInserted(updateRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdated(updateRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}


	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		MstRoleRootGroupEntity rec = roleRootGroupRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.roleRootGroupInfo")});
			throw exp;
		}
		roleRootGroupRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("role_id".equals(str)) mf.role_id = true;
				if ("root_group_id".equals(str)) mf.root_group_id = true;
				if ("version".equals(str)) mf.version = true;
				if ("inserted".equals(str)) mf.inserted = true;
				if ("insert_time".equals(str)) mf.insert_time = true;
				if ("updated".equals(str)) mf.updated = true;
				if ("update_time".equals(str)) mf.update_time = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			role_id = b;
			root_group_id = b;
			version = b;
			inserted = b;
			insert_time = b;
			updated = b;
			update_time = b;
		}
		public boolean id = true;
		public boolean role_id = true;
		public boolean root_group_id = true;
		public boolean version = true;
		public boolean inserted = true;
		public boolean insert_time = true;
		public boolean updated = true;
		public boolean update_time = true;
	}
}


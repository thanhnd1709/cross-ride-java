package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.DeviceStructureEntity;
import com.app.model.DeviceStructureModel;
import com.app.model.ResponseDeviceStructureModel;
import com.app.repository.DeviceStructureRepositoryCustom;

/**
 * デバイス階層情報取得サービスクラス
 * @author （TOSCO）9571
 *
 */
@Service
@Transactional(readOnly = true)
public class DeviceStructureService {

	/**
	 * デバイス階層情報取得
	 * @param reqModel 検索条件オブジェクト
	 * @return デバイス階層リスト
	 * @throws Exception
	 */

	@Autowired private DeviceStructureRepositoryCustom deviceStructureRepositoryCustom;

	public List<ResponseDeviceStructureModel> getDeviceStructure(DeviceStructureModel reqModel) throws Exception{

		// 取得フィールド処理
		ModelFilter mf = makeModelFilter(reqModel.getFields());

		String sort = null;
		if (reqModel.getSort() != null) {
			for (String item : reqModel.getSort().split(",")) {
				if (sort != null) {
					sort += ",";
				} else
					sort = "";
				if (item.startsWith("-")) {
					if (item.equalsIgnoreCase("-device_structure")) sort += (item.toLowerCase().replace("-device_structure", "parent_device_list")) + " DESC";
					 else sort += (item.toLowerCase().replace("-", "")) + " DESC";
				} else {
					if (item.equalsIgnoreCase("device_structure")) sort += item.toLowerCase().replace("device_structure", "parent_device_list");
					else sort += item.toLowerCase();
				}
			}
		}

		// ページング処理
		Integer limit = null;
		Integer offset = null;
		if (reqModel.getPage() != null && reqModel.getLimit() != null) {
			limit = Integer.parseInt(reqModel.getLimit());
			offset = (Integer.parseInt(reqModel.getPage()) - 1) * limit;
		}

		List<ResponseDeviceStructureModel> lstDeviceStructure = new ArrayList<>();

		//デバイス階層取得処理
		List<DeviceStructureEntity> list = deviceStructureRepositoryCustom.getDeviceStructure(reqModel, sort, limit,
				offset);
		for (DeviceStructureEntity resEntity : list) {
			ResponseDeviceStructureModel devStrModel = new ResponseDeviceStructureModel();
			if (mf.device_structure) devStrModel.setDevice_structure(resEntity.getParent_device_list());
			if (mf.level) devStrModel.setLevel(resEntity.getLevel());
			if (mf.model_id) devStrModel.setModel_id(resEntity.getModel_id());
			if (mf.serial_no) devStrModel.setSerial_no(resEntity.getSerial_no());
			if (mf.device_mode) devStrModel.setDevice_mode(resEntity.getDevice_mode());
			lstDeviceStructure.add(devStrModel);
		}
		return lstDeviceStructure;
	}

	private ModelFilter makeModelFilter(String fields){
		ModelFilter mf = null;
		if(fields == null || fields.trim().length() == 0){
			mf = new ModelFilter(true);
		}else{
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("device_structure".equals(str))
					mf.device_structure = true;
				if ("level".equals(str))
					mf.level = true;
				if ("model_id".equals(str))
					mf.model_id = true;
				if ("serial_no".equals(str))
					mf.serial_no = true;
				if ("device_mode".equals(str))
					mf.device_mode = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			device_structure = b;
			level = b;
			model_id = b;
			serial_no = b;
			device_mode = b;
		}

		public boolean device_structure;
		public boolean level;
		public boolean model_id;
		public boolean serial_no;
		public boolean device_mode;
	}
}


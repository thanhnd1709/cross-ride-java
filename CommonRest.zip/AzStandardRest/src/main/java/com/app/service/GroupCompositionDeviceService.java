package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstGroupCompositionDeviceEntity;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.GroupCompositionDeviceModel;
import com.app.model.GroupCompositionDeviceQueryModel;
import com.app.repository.GroupCompositionDeviceRepository;

@Service
@Transactional(readOnly = true)
public class GroupCompositionDeviceService {
	@Autowired
	private GroupCompositionDeviceRepository groupCompositionDeviceRepository;


	public GroupCompositionDeviceModel findOne(int uuid, String fields) throws Exception{
		ModelFilter mf = makeModelFilter(fields);

		MstGroupCompositionDeviceEntity entity = groupCompositionDeviceRepository.findOne(uuid);
		GroupCompositionDeviceModel newModel = null;
		if (entity != null) {
			newModel = new GroupCompositionDeviceModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.device_group_id) newModel.setDevice_group_id(entity.getDevice_group_id());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}else{
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.groupCompositionDeviceInfo")});
			throw exp;
		}
		return  newModel;
	}

	public List<GroupCompositionDeviceModel> findAll(GroupCompositionDeviceQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<MstGroupCompositionDeviceEntity> entList = groupCompositionDeviceRepository.findAll(filter, sort, limit, offset);
		List<GroupCompositionDeviceModel> modelList = new ArrayList<GroupCompositionDeviceModel>();
		for (MstGroupCompositionDeviceEntity entity : entList) {
			GroupCompositionDeviceModel newModel = new GroupCompositionDeviceModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.device_group_id) newModel.setDevice_group_id(entity.getDevice_group_id());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(GroupCompositionDeviceQueryModel filter) throws Exception{
		return groupCompositionDeviceRepository.countAll(filter);
	}

	@Transactional(readOnly = false)
	public GroupCompositionDeviceModel save(GroupCompositionDeviceModel model) throws Exception{

		MstGroupCompositionDeviceEntity newRec = new MstGroupCompositionDeviceEntity();

		if (model.getDevice_group_id() != null) newRec.setDevice_group_id(model.getDevice_group_id());
		if (model.getModel_id() != null) newRec.setModel_id(model.getModel_id());
		if (model.getSerial_no() != null) newRec.setSerial_no(model.getSerial_no());
		newRec.setVersion(0L);

		newRec = groupCompositionDeviceRepository.save(newRec);

		GroupCompositionDeviceModel newModel = new GroupCompositionDeviceModel();
		newModel.setId(newRec.getId());
		newModel.setDevice_group_id(newRec.getDevice_group_id());
		newModel.setModel_id(newRec.getModel_id());
		newModel.setSerial_no(newRec.getSerial_no());
		newModel.setVersion(newRec.getVersion());
		newModel.setInserted(newRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdated(newRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public GroupCompositionDeviceModel update(Locale locale,int id, GroupCompositionDeviceModel model) throws Exception{
		MstGroupCompositionDeviceEntity rec = groupCompositionDeviceRepository.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.groupCompositionDeviceInfo")});
			throw exp;
		}

		rec.setDevice_group_id(model.getDevice_group_id());
		rec.setModel_id(model.getModel_id());
		rec.setSerial_no(model.getSerial_no());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.groupCompositionDeviceInfo")});
			throw exp;
		}





		groupCompositionDeviceRepository.saveAndFlush(rec);
		MstGroupCompositionDeviceEntity updateRec = groupCompositionDeviceRepository.findOne(id);
		GroupCompositionDeviceModel newModel = new GroupCompositionDeviceModel();
		newModel.setId(updateRec.getId());
		newModel.setDevice_group_id(updateRec.getDevice_group_id());
		newModel.setModel_id(updateRec.getModel_id());
		newModel.setSerial_no(updateRec.getSerial_no());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInserted(updateRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdated(updateRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}


	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		MstGroupCompositionDeviceEntity rec = groupCompositionDeviceRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.groupCompositionDeviceInfo")});
			throw exp;
		}
		groupCompositionDeviceRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("device_group_id".equals(str)) mf.device_group_id = true;
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("version".equals(str)) mf.version = true;
				if ("inserted".equals(str)) mf.inserted = true;
				if ("insert_time".equals(str)) mf.insert_time = true;
				if ("updated".equals(str)) mf.updated = true;
				if ("update_time".equals(str)) mf.update_time = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			device_group_id = b;
			model_id = b;
			serial_no = b;
			version = b;
			inserted = b;
			insert_time = b;
			updated = b;
			update_time = b;
		}
		public boolean id = true;
		public boolean device_group_id = true;
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean version = true;
		public boolean inserted = true;
		public boolean insert_time = true;
		public boolean updated = true;
		public boolean update_time = true;
	}
}


package com.app.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.common.Consts;
import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstSensorEntity;
import com.app.entity.StdNewMeasureDataEntity;
import com.app.exception.IoTSQLException;
import com.app.model.ResponseLatestSensorDataModel;
import com.app.model.ResponseLatestSensorModel;
import com.app.model.ResponseMeasureDataModel;
import com.app.model.SensorModel1;
import com.app.model.SensorModel2;
import com.app.repository.MstSensorRepositoryCustom;
import com.app.repository.StdNewMeasureDataRepositoryCustom;

/**
 * センサー最新値取得サービスクラス
 * @author（TOSCO）ウェイ
 */
@Service
public class GetLatestSensorDataService {

	@Autowired
	private MstSensorRepositoryCustom _sensorRepoCustom;
	@Autowired
	private StdNewMeasureDataRepositoryCustom _measureDataRepoCustom;

	/**
	 * センサー最新値取得処理
	 * @return センサー最新値リスト
	 */
	public List<ResponseLatestSensorDataModel> getLatestSensorData(List<SensorModel1> sensorList) throws Exception{

		// センサーリストをソートする
		Collections.sort(sensorList, new BeanComparator<SensorModel1>("serial_no"));
		Collections.sort(sensorList, new BeanComparator<SensorModel1>("model_id"));

		// センサー情報を整理する
		List<SensorModel2> ssModel = new ArrayList<>();
		String modelId = "";
		String serialNo = "";
		List<String> ssIdList = null;

		for(SensorModel1 sensor : sensorList){
			if("".equals(modelId) && "".equals(serialNo)) {
				modelId = sensor.getModel_id();
				serialNo = sensor.getSerial_no();
				ssIdList = new ArrayList<>();
			}else{
				if(!modelId.equals(sensor.getModel_id()) || !serialNo.equals(sensor.getSerial_no())){
					ssModel.add(new SensorModel2(modelId, serialNo
							, ssIdList.stream().distinct().collect(Collectors.toList())));
					modelId = sensor.getModel_id();
					serialNo = sensor.getSerial_no();
					ssIdList = new ArrayList<>();
				}
			}
			ssIdList.add(sensor.getSensor_id());
		}
		ssModel.add(new SensorModel2(modelId, serialNo, ssIdList.stream().distinct().collect(Collectors.toList())));

		/****************************
		 * センサー最新値取得処理
		 ****************************/
		List<ResponseLatestSensorDataModel> lstSensorData = this.getLatestSensor(ssModel);

		// センサー最新値取得処理
		return lstSensorData;
	}


	/**
	 * センサーデータ取得処理
	 * @return センサーデータリスト
	 */
	private List<ResponseLatestSensorDataModel> getLatestSensor(List<SensorModel2> ssModelList) throws Exception{

		List<ResponseMeasureDataModel> lstMeasureData = new ArrayList<>();
		List<ResponseLatestSensorModel> lstSensor = new ArrayList<>();
		List<ResponseLatestSensorDataModel> lstSensorData = new ArrayList<>();

		String modelId = "";
		String serialNo = "";

		try {
			// センサーデータ取得処理
			for(SensorModel2 ssModel : ssModelList){

				// 機種ID
				modelId = ssModel.getModel_id();
				// シリアルNo
				serialNo = ssModel.getSerial_no();
				// センサーID
				List<String> ssIdList = ssModel.getSensor_id_list();

				for(String ssId : ssIdList){
					// センサー情報取得
					List<MstSensorEntity> lstSensorEntity = _sensorRepoCustom.find(modelId, serialNo, ssId, Consts.MEASURE_TYPE_1);
					//logger.debug("" + lstSensorEntity);

					// 該当センサー情報が存在しない場合、
					// レスポンスの対象センサーに空リストを設定し、次のセンサー情報の取得処理に進む
					if(lstSensorEntity == null || lstSensorEntity.size() <= 0){

						if(ssId != null){
							if(ssId.contains(",")){
								String [] ssids = ssId.split(",");
								for(String id:ssids){
									lstSensor.add(new ResponseLatestSensorModel(id,  new ArrayList<>()));
								}

							}else{
								lstSensor.add(new ResponseLatestSensorModel(ssId, new ArrayList<>()));
							}
						}
						continue;
					}

					// 該当センサー情報が存在する場合
					for(MstSensorEntity sensorEntity : lstSensorEntity){

						List<ResponseMeasureDataModel> lstResult = this.getMeasureData(modelId, serialNo
								, sensorEntity.getSensor_id(), sensorEntity.getData_type(), sensorEntity.getFixed_length());
						for(ResponseMeasureDataModel result : lstResult){
							lstMeasureData.add(result);
						}

						// 該当センサーに取得された計測データを格納する
						lstSensor.add(new ResponseLatestSensorModel(sensorEntity.getSensor_id(), lstMeasureData));
						lstMeasureData = new ArrayList<>();
					}
				}
				// センサーデータを格納する
				lstSensorData.add(new ResponseLatestSensorDataModel(modelId, serialNo, lstSensor));
				lstSensor = new ArrayList<>();
			}
		}catch (Exception e) {
			throw new IoTSQLException(e);
		}

		return lstSensorData;
	}

	/**
	 * 最新計測データ取得処理
	 * @return 計測データリスト
	 */
	private List<ResponseMeasureDataModel> getMeasureData(String paramModelId
																, String paramSerialNo
																, String paramSensorId
																, String paramDataType
																, Integer paramFixedLen){

		List<ResponseMeasureDataModel> lstResult = new ArrayList<>();
		List<StdNewMeasureDataEntity> lstEntity= new ArrayList<>();

		try{
			lstEntity = _measureDataRepoCustom.search(paramModelId, paramSerialNo, paramSensorId);

			for(StdNewMeasureDataEntity entity : lstEntity){
				lstResult.add(new ResponseMeasureDataModel(DateTimeUtil.formatTs(entity.getMeasure_time())
															, entity.getMeasure_data()));
			}
		}catch (Exception e) {
			throw new IoTSQLException(e);
		}

		return lstResult;
	}
}

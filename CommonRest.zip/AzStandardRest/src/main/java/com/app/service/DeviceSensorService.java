package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.DeviceListModel;
import com.app.model.SensorModel;

@Service
@Transactional(readOnly = true)
public class DeviceSensorService {

	/**
	 * デバイス下センサ情報取得サービスクラス
	 * @return センサ情報リスト
	 */
	public List<SensorModel> getDeviceSensor(List<DeviceListModel> reqDeviceListModel) throws Exception{

		List<SensorModel> lstSensor = new ArrayList<>();

		return lstSensor;
	}
}


package com.app.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.InitialStartup;
import com.app.common.Consts;
import com.app.common.utils.DateTimeUtil;
import com.app.exception.IoTSQLException;
import com.app.model.ResponseSensorDataModel;
import com.app.model.SensorDataModel;
import com.app.model.SensorModel1;
import com.app.model.SensorModel2;
import com.app.model.SystemInfoModel;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.table.CloudTable;
import com.microsoft.azure.storage.table.CloudTableClient;

/**
 * センサーデータ取得サービスクラス
 * @author（TOSCO）ウェイ
 */
@Service
public class GetSensorDataService {

	//private Logger logger = LoggerFactory.getLogger(GetSensorDataService.class);

	@Autowired
	private GetSensorDataKbn1Service _ssDataServiceKbn1;
	@Autowired
	private GetSensorDataKbn2Service _ssDataServiceKbn2;

//	private ResourceBundle _bundle = ResourceBundle.getBundle("application");
//	private final String _storageConnectionString = _bundle.getString("storage.connection.string");

	private final String _storageConnectionString = System.getenv("storage.connection.string");
//	private final String _storageConnectionString = "DefaultEndpointsProtocol=https;"
//			+ "AccountName=iotstoragejnzv4f47vqym4;"
//			+ "AccountKey=k8KpSwGQCrNyvHP7cLFVd/h+0ByvXkq/DzAn8uwQ7NUETpeSQRlYEKoov7qAkDV5PowrV+baTRVwV+CSAhjWJA==;"
//			+ "EndpointSuffix=core.windows.net";
	private HashMap<String,Date> _systemInfo = new HashMap<String,Date>();

	/**
	 * センサーデータ取得処理
	 * @return センサーデータリスト
	 */
	public List<ResponseSensorDataModel> getSensorData(SensorDataModel ssDataModel) throws Exception{

		List<ResponseSensorDataModel> lstSensorData = new ArrayList<>();

		List<SensorModel1> sensorList = ssDataModel.getSensor_list();
		Timestamp dateFrom;
		Timestamp dateTo;

		try {
			// 対象期間(From)
			dateFrom = DateTimeUtil.toTimestamp1(ssDataModel.getMeasure_time_from());

			// 対象期間(To)
			String measureTimeTo = ssDataModel.getMeasure_time_to();
			if(measureTimeTo != null && !"".equals(measureTimeTo)){
				dateTo = DateTimeUtil.toTimestamp1(measureTimeTo);
			}else{
				dateTo = new Timestamp(System.currentTimeMillis());
			}

			// センサーリストをソートする
			Collections.sort(sensorList, new BeanComparator<SensorModel1>("serial_no"));
			Collections.sort(sensorList, new BeanComparator<SensorModel1>("model_id"));

		}catch (Exception e) {
			throw new IoTSQLException(e);
		}

		// センサー情報を整理する
		List<SensorModel2> ssModel = new ArrayList<>();
		String modelId = "";
		String serialNo = "";
		List<String> ssIdList = null;
		for(SensorModel1 sensor : sensorList){

			if("".equals(modelId) && "".equals(serialNo)) {
				modelId = sensor.getModel_id();
				serialNo = sensor.getSerial_no();
				ssIdList = new ArrayList<>();
			}else{
				if(!modelId.equals(sensor.getModel_id()) || !serialNo.equals(sensor.getSerial_no())){
					ssModel.add(new SensorModel2(modelId, serialNo
							, ssIdList.stream().distinct().collect(Collectors.toList())));
					modelId = sensor.getModel_id();
					serialNo = sensor.getSerial_no();
					ssIdList = new ArrayList<>();
				}
			}
			ssIdList.add(sensor.getSensor_id());
		}
		ssModel.add(new SensorModel2(modelId, serialNo, ssIdList.stream().distinct().collect(Collectors.toList())));

		/****************************
		 * Azureへの接続処理
		 ****************************/
		// Azure Table Storage、Azure Blob Storageへの接続処理を行う
		// Azure Storage接続文字列を取得して、Azure のストレージ アカウントにアクセスする
		CloudStorageAccount storageAccount = CloudStorageAccount.parse(_storageConnectionString);

		// CloudTableClient オブジェクトを作成し、これを使用して下記の新しい CloudTable オブジェクトを作成する
		// 時間別計測データ（devHHData）
		CloudTableClient tableClient = storageAccount.createCloudTableClient();
		CloudTable cloudTable1 = tableClient.getTableReference(Consts.TABLE_HH_DATA);
		
		CloudTableClient tableClient2 = storageAccount.createCloudTableClient();
		CloudTable cloudTable2 = tableClient2.getTableReference(Consts.TABLE_MEASURE_DATA);

		// CloudBlobClient オブジェクトを作成し、これを使用するコンテナーへの参照を取得する
		// 日付別Blobファイル（measuredata）
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
		CloudBlobContainer container = blobClient.getContainerReference(Consts.BLOB_FILE);

		/****************************
		 * 検索用期間取得処理
		 ****************************/
		this.getPeriodDateList(ssDataModel.getGet_class(), dateFrom, dateTo);

		/****************************
		 * センサーデータ取得処理
		 ****************************/
		// リクエスト．検索区分が "1"の場合は、下記の処理を行う
		if(Consts.KBN_SEARCH_1.equals(ssDataModel.getGet_class())){
			lstSensorData = _ssDataServiceKbn1.getSensorDataKbn1(dateFrom
																	, dateTo
																	, ssDataModel.getRound_kbn()
																	, ssDataModel.getMax_number()
																	, ssDataModel.getSort()
																	, ssModel
																	, _systemInfo
																	, cloudTable1
																	, cloudTable2
																	, container);

		// リクエスト．検索区分が "2"の場合は、下記の処理を行う
		}else if(Consts.KBN_SEARCH_2.equals(ssDataModel.getGet_class())){
			lstSensorData = _ssDataServiceKbn2.getSensorDataKbn2(dateFrom
																	, dateTo
																	, ssModel
																	, _systemInfo
																	, cloudTable1
																	, cloudTable2
																	, container);
		}
		return lstSensorData;
	}

	/**
	 * 検索用期間リスト取得処理
	 * @param searchKbn   検索区分
	 */
	private void getPeriodDateList(String searchKbn, Timestamp dateFrom, Timestamp dateTo) throws Exception{

		String[] timeSeriesRange = InitialStartup.timeSeriesAPIRangeSearch;
		SystemInfoModel systemInfoModel = InitialStartup.systemInfoModel;
		long dataMigrateMontlyWaiter = InitialStartup.systemInfoModel.getDataBlobMigrateWaite() > InitialStartup.systemInfoModel.getDataBlobMigrateWaite2()?
				InitialStartup.systemInfoModel.getDataBlobMigrateWaite2():InitialStartup.systemInfoModel.getDataBlobMigrateWaite();


		// システム日時取得
		Timestamp now = new Timestamp(System.currentTimeMillis());
		Calendar calendar = Calendar.getInstance();

		Date truncateHour;

		// 検索用期間リスト１
		for(String data : timeSeriesRange){
			switch(data){

				// hour：時間別計測データ
				case Consts.PARAMETER_KBN_HOUR:
					// 時間別移行待機時間
					calendar.setTime(now);
					calendar.add(
							Calendar.HOUR_OF_DAY, Integer.valueOf("-" + systemInfoModel.getDataHourMigrateWaite()));
					truncateHour = DateUtils.truncate(calendar.getTime(), Calendar.HOUR_OF_DAY);
					_systemInfo.put(Consts.PARAMETER_KBN_HOUR, truncateHour);
					break;

					// blob：月別Blobファイル
				case Consts.PARAMETER_KBN_MONTH:
					calendar.setTime(now);
					calendar.add(
							Calendar.DAY_OF_MONTH, Integer.valueOf("-" + dataMigrateMontlyWaiter));
					truncateHour = DateUtils.truncate(calendar.getTime(), Calendar.DAY_OF_MONTH);

					_systemInfo.put(Consts.PARAMETER_KBN_MONTH, truncateHour);
					break;
			}
		}

	}
}

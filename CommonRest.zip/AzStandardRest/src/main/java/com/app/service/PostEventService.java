package com.app.service;

import java.util.List;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.common.Consts;
import com.app.entity.PostEventEntity;
import com.app.exception.IoTSQLException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.SendMessageQueue;
import com.app.model.StdEventModel;
import com.app.model.UserModel;
import com.app.repository.PostEventRepositoryCustom;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.windowsazure.Configuration;
import com.microsoft.windowsazure.services.servicebus.ServiceBusConfiguration;
import com.microsoft.windowsazure.services.servicebus.ServiceBusContract;
import com.microsoft.windowsazure.services.servicebus.ServiceBusService;
import com.microsoft.windowsazure.services.servicebus.models.BrokeredMessage;

/**
 * イベント・アラーム登録サービスクラス
 * @author（TOSCO）ウェイ
 */
@Service
public class PostEventService {

	private Logger logger = LoggerFactory.getLogger(PostEventService.class);

	private ResourceBundle _bundle = ResourceBundle.getBundle("application");
//	private final String _serviceBusNamespace = _bundle.getString("service.bus.namespace");
//	private final String _serviceBusSasKeyName = _bundle.getString("service.bus.sas.key.name");
//	private final String _serviceBusSasKey = _bundle.getString("service.bus.sas.key");
	private final String _serviceBusRootUri= _bundle.getString("service.bus.root.uri");

	private final String _serviceBusNamespace = System.getenv("service.bus.namespace");
	private final String _serviceBusSasKeyName = System.getenv("service.bus.sas.key.name");
	private final String _serviceBusSasKey = System.getenv("service.bus.sas.key");

	@Autowired AuthUserInfoComponent authUserInfo;
	@Autowired PostEventRepositoryCustom _Repository;

	/**
	 * イベント・アラーム登録処理
	 */
	public void postFile(List<StdEventModel> fileModel) throws Exception{

		for(StdEventModel model : fileModel){
			//検出区分
			String detectionClass = model.getDetectionClass();
			model.setDetectionClass(detectionClass == null? Consts.DETECTION_CLASS_5 : detectionClass);
		}

		SendMessageQueue queue = new SendMessageQueue();
		queue.setHeader(new UserModel(authUserInfo.getPrincipalName()));
		queue.setBody(fileModel);

		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(queue);
		logger.info("json : " + json);

		//｢イベント登録キュー｣ にメッセージを送信する
		try{
			Configuration config =
					ServiceBusConfiguration.configureWithSASAuthentication(_serviceBusNamespace
																	    		, _serviceBusSasKeyName
																	    		, _serviceBusSasKey
																	    		, _serviceBusRootUri);
			ServiceBusContract service = ServiceBusService.create(config);
		    BrokeredMessage message = new BrokeredMessage(json);
		    service.sendQueueMessage(Consts.SERVICE_BUS_QUEUE_EVENT, message);
		    logger.info("SendQueueMessage : OK");
		}
		catch (Exception e){
			throw new IoTSQLException(e);
		}
	}

	/**
	 * イベント権限チェック
	 */
	public List<PostEventEntity> eventAuthChk(List<String> modelList, String userId) throws Exception {
		return _Repository.eventAuthChk(modelList,userId);
	}
}

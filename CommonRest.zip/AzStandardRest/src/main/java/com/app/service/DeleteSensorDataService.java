package com.app.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.SensorDataModel2;

/**
 * センサーデータ削除サービスクラス
 * @author（TOSCO）ウェイ
 */
@Service
public class DeleteSensorDataService {

//	@Autowired
//	private StdMeasureDataRepositoryCustom _stdmdRepoCustom;
//	@Autowired
//	private StdNewMeasureDataRepositoryCustom _stdNewmdRepoCustom;
//	@Autowired
//	private BlobDataRepositoryCustom _blobRepoCustom;

//	private long oneDay = 1 * 24 * 60 * 60 * 1000;

//	private ResourceBundle _bundle = ResourceBundle.getBundle("application");
//	private final String _storageConnectionString = _bundle.getString("storage.connection.string");

	/**
	 * センサーデータ削除処理
	 */
	@Transactional(readOnly = false)
	public void deleteSensorData(SensorDataModel2 reqModel) throws Exception{

//		boolean hasData = false;

//		Timestamp dateFrom;
//		Timestamp dateTo;
//		SimpleDateFormat formatter = new SimpleDateFormat(Consts.DATE_FORMAT);
//		try {
//			dateFrom = DateTimeUtil.toTimestamp1(reqModel.getMeasure_time_from());
//			dateTo = DateTimeUtil.toTimestamp1(reqModel.getMeasure_time_to());
//		}catch(Exception e){
//			throw new IoTSQLException(e);
//		}

//		String modelId = reqModel.getModel_id();
//		String serialNo = reqModel.getSerial_no();
//		String sensorId = reqModel.getSensor_id();
//		String strDateFrom = DateTimeUtil.formatTs(dateFrom);
//		String strDateTo = DateTimeUtil.formatTs(dateTo);
//
//		/****************************
//		 * Azureへの接続処理
//		 ****************************/
//		// Azure Table Storage、Azure Blob Storageへの接続処理を行う
//		// Azure Storage接続文字列を取得して、Azure のストレージ アカウントにアクセスする
//		CloudStorageAccount storageAccount = CloudStorageAccount.parse(_storageConnectionString);
//
//		// CloudTableClient オブジェクトを作成し、これを使用して下記の新しい CloudTable オブジェクトを作成する
//		// 時間別計測データ（devHHData）
//		// ｢降順｣時間別計測データ（devHHDataDesc）
//		// 日別計測データ（devDayData）
//		// ｢降順｣日別計測データ（devDayDataDesc）
//		CloudTableClient tableClient = storageAccount.createCloudTableClient();
//		CloudTable cloudTable1 = tableClient.getTableReference(Consts.TABLE_HH_DATA);
//		CloudTable cloudTable2 = tableClient.getTableReference(Consts.TABLE_HH_DATA_DESC);
//		CloudTable cloudTable3 = tableClient.getTableReference(Consts.TABLE_DAY_DATA);
//		CloudTable cloudTable4 = tableClient.getTableReference(Consts.TABLE_DAY_DATA_DESC);
//
//		// CloudBlobClient オブジェクトを作成し、これを使用するコンテナーへの参照を取得する
//		// 日付別Blobファイル（measuredata）
//		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
//		CloudBlobContainer container = blobClient.getContainerReference(Consts.BLOB_FILE);
//
//		/****************************
//		 * センサーデータ削除処理
//		 ****************************/
		// 計測データ削除処理
//		if(_stdmdRepoCustom.delete(modelId, serialNo, sensorId, dateFrom, dateTo) > 0){
//			hasData = true;
//		}
//
//		// 時間別計測データ削除処理
//		if(this.deleteHourMeasureData(modelId, serialNo, sensorId, strDateFrom, strDateTo, cloudTable1) > 0){
//			hasData = true;
//		}
//
//		// 日別計測データ削除処理
//		if(this.deleteDayMeasureData(modelId, serialNo, sensorId, strDateFrom, strDateTo, cloudTable3) > 0){
//			hasData = true;
//		}
//
//		// 日付別Blobファイル削除処理
//		if(this.deleteBlobMeasureData(modelId, serialNo, sensorId, strDateFrom, strDateTo, container) > 0){
//			hasData = true;
//		}
//
//		// 対象計測データが見つからない場合
//		if(hasData == false){
//			DataNotFoundException exp = new DataNotFoundException("");
//			exp.setArgs(new MessageSourceResolvable[]{
//					new DefaultMessageSourceResolvable("message.measureData")});
//			throw exp;
//		}
//
//		// 最新計測データのロック処理
//		List<StdNewMeasureDataEntity> lstNewMeasureData = new ArrayList<>();
//		lstNewMeasureData = _stdNewmdRepoCustom.lock(modelId, serialNo, sensorId, dateFrom, dateTo);
//
//		for(StdNewMeasureDataEntity newMeasureData : lstNewMeasureData){
//			// 該当センサーの最新計測値を取得する
//			ResponseMeasureDataModel result = this.getNewMeasureData(newMeasureData, cloudTable2, cloudTable4, container);
//
//			if(result != null){
//				// 最新計測データを更新する
//				_stdNewmdRepoCustom.update(modelId, serialNo, sensorId, dateFrom, dateTo
//											, result.getMeasureTime(), result.getData());
//			}else{
//				// 最新計測データを削除する
//				_stdNewmdRepoCustom.delete(modelId, serialNo, sensorId, dateFrom, dateTo);
//			}
//		}
	}


//	/**
//	 * 時間別計測データ削除処理
//	 */
//	private int deleteHourMeasureData(String paramModelId
//										, String paramSerialNo
//										, String paramSensorId
//										, String paramDateFrom
//										, String paramDateTo
//										, CloudTable cloudTable1){
//		try {
//
//		}catch(Exception e){
//			throw new IoTSQLException(e);
//		}
//		return 0;
//	}
//
//	/**
//	 * 日別計測データ削除処理
//	 */
//	private int deleteDayMeasureData(String paramModelId
//										, String paramSerialNo
//										, String paramSensorId
//										, String paramDateFrom
//										, String paramDateTo
//										, CloudTable cloudTable3){
//		try {
//
//		}catch(Exception e){
//			throw new IoTSQLException(e);
//		}
//		return 0;
//	}
//
//	/**
//	 * 日付別Blobファイル削除処理
//	 */
//	private int deleteBlobMeasureData(String paramModelId
//										, String paramSerialNo
//										, String paramSensorId
//										, String paramDateFrom
//										, String paramDateTo
//										, CloudBlobContainer container){
//
//		int retVal = 0;
//
//		return retVal;
//	}
//
//	/**
//	 * 該当センサーの最新計測値を取得する
//	 * @throws Exception
//	 */
//	private ResponseMeasureDataModel getNewMeasureData(StdNewMeasureDataEntity entity
//												, CloudTable cloudTable2, CloudTable cloudTable4
//												, CloudBlobContainer container) throws Exception{
//
//		return null;
//	}
}

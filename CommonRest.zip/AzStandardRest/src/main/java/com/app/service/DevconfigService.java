package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstDevconfigEntity;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.DevconfigModel;
import com.app.model.DevconfigQueryModel;
import com.app.repository.DevconfigRepository;
import com.app.repository.DevconfigRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class DevconfigService {
	@Autowired
	private DevconfigRepository devconfigRepository;
	@Autowired
	private DevconfigRepositoryCustom devconfigRepositoryCustom;

	public DevconfigModel findOne(int uuid, String fields) throws Exception{
		ModelFilter mf = makeModelFilter(fields);

		MstDevconfigEntity entity = devconfigRepository.findOne(uuid);
		DevconfigModel newModel = null;
		if (entity != null) {
			newModel = new DevconfigModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.config_id) newModel.setConfig_id(entity.getConfig_id());
			if (mf.config_type) newModel.setConfig_type(entity.getConfig_type());
			if (mf.required_class) newModel.setRequired_class(entity.getRequired_class());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.data_type) newModel.setData_type(entity.getData_type());
			if (mf.data) newModel.setData(entity.getData());
			if (mf.config_file_name) newModel.setConfig_file_name(entity.getConfig_file_name());
			if (mf.tool_address) newModel.setTool_address(entity.getTool_address());
			if (mf.tool_class) newModel.setTool_class(entity.getTool_class());
			if (mf.apply_command) newModel.setApply_command(entity.getApply_command());
			if (mf.inventory_command) newModel.setInventory_command(entity.getInventory_command());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}
		return  newModel;
	}

	public List<DevconfigModel> findAll(DevconfigQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<MstDevconfigEntity> entList = devconfigRepositoryCustom.findAll(filter, sort, limit, offset);
		List<DevconfigModel> modelList = new ArrayList<DevconfigModel>();
		for (MstDevconfigEntity entity : entList) {
			DevconfigModel newModel = new DevconfigModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.config_id) newModel.setConfig_id(entity.getConfig_id());
			if (mf.config_type) newModel.setConfig_type(entity.getConfig_type());
			if (mf.required_class) newModel.setRequired_class(entity.getRequired_class());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.data_type) newModel.setData_type(entity.getData_type());
			if (mf.data) newModel.setData(entity.getData());
			if (mf.config_file_name) newModel.setConfig_file_name(entity.getConfig_file_name());
			if (mf.tool_address) newModel.setTool_address(entity.getTool_address());
			if (mf.tool_class) newModel.setTool_class(entity.getTool_class());
			if (mf.apply_command) newModel.setApply_command(entity.getApply_command());
			if (mf.inventory_command) newModel.setInventory_command(entity.getInventory_command());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(DevconfigQueryModel filter) throws Exception{
		return devconfigRepositoryCustom.countAll(filter);
	}

	@Transactional(readOnly = false)
	public DevconfigModel save(DevconfigModel model) throws Exception{

		MstDevconfigEntity newRec = new MstDevconfigEntity();

		if (model.getModel_id() != null) newRec.setModel_id(model.getModel_id());
		if (model.getSerial_no() != null) newRec.setSerial_no(model.getSerial_no());
		if (model.getConfig_id() != null) newRec.setConfig_id(model.getConfig_id());
		if (model.getConfig_type() != null) newRec.setConfig_type(model.getConfig_type());
		if (model.getRequired_class() != null) newRec.setRequired_class(model.getRequired_class());
		if (model.getName_locale1() != null) newRec.setName_locale1(model.getName_locale1());
		if (model.getName_locale2() != null) newRec.setName_locale2(model.getName_locale2());
		if (model.getName_locale3() != null) newRec.setName_locale3(model.getName_locale3());
		if (model.getDescription_locale1() != null) newRec.setDescription_locale1(model.getDescription_locale1());
		if (model.getDescription_locale2() != null) newRec.setDescription_locale2(model.getDescription_locale2());
		if (model.getDescription_locale3() != null) newRec.setDescription_locale3(model.getDescription_locale3());
		if (model.getData_type() != null) newRec.setData_type(model.getData_type());
		if (model.getData() != null) newRec.setData(model.getData());
		if (model.getConfig_file_name() != null) newRec.setConfig_file_name(model.getConfig_file_name());
		if (model.getTool_address() != null) newRec.setTool_address(model.getTool_address());
		if (model.getTool_class() != null) newRec.setTool_class(model.getTool_class());
		if (model.getApply_command() != null) newRec.setApply_command(model.getApply_command());
		if (model.getInventory_command() != null) newRec.setInventory_command(model.getInventory_command());
		if (model.getNote() != null) newRec.setNote(model.getNote());
		newRec.setVersion(0L);

		newRec = devconfigRepository.save(newRec);
		DevconfigModel newModel = new DevconfigModel();
		newModel.setId(newRec.getId());
		newModel.setModel_id(newRec.getModel_id());
		newModel.setSerial_no(newRec.getSerial_no());
		newModel.setConfig_id(newRec.getConfig_id());
		newModel.setConfig_type(newRec.getConfig_type());
		newModel.setRequired_class(newRec.getRequired_class());
		newModel.setName_locale1(newRec.getName_locale1());
		newModel.setName_locale2(newRec.getName_locale2());
		newModel.setName_locale3(newRec.getName_locale3());
		newModel.setDescription_locale1(newRec.getDescription_locale1());
		newModel.setDescription_locale2(newRec.getDescription_locale2());
		newModel.setDescription_locale3(newRec.getDescription_locale3());
		newModel.setData_type(newRec.getData_type());
		newModel.setData(newRec.getData());
		newModel.setConfig_file_name(newRec.getConfig_file_name());
		newModel.setTool_address(newRec.getTool_address());
		newModel.setTool_class(newRec.getTool_class());
		newModel.setApply_command(newRec.getApply_command());
		newModel.setInventory_command(newRec.getInventory_command());
		newModel.setNote(newRec.getNote());
		newModel.setVersion(newRec.getVersion());
		newModel.setInserted(newRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdated(newRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public DevconfigModel update(Locale locale,int id, DevconfigModel model) throws Exception{
		MstDevconfigEntity rec = devconfigRepositoryCustom.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.devconfigInfo")});
			throw exp;
		}

		rec.setModel_id(model.getModel_id());
		rec.setSerial_no(model.getSerial_no());
		rec.setConfig_id(model.getConfig_id());
		rec.setConfig_type(model.getConfig_type());
		rec.setRequired_class(model.getRequired_class());
		rec.setName_locale1(model.getName_locale1());
		rec.setName_locale2(model.getName_locale2());
		rec.setName_locale3(model.getName_locale3());
		rec.setDescription_locale1(model.getDescription_locale1());
		rec.setDescription_locale2(model.getDescription_locale2());
		rec.setDescription_locale3(model.getDescription_locale3());
		rec.setData_type(model.getData_type());
		rec.setData(model.getData());
		rec.setConfig_file_name(model.getConfig_file_name());
		rec.setTool_address(model.getTool_address());
		rec.setTool_class(model.getTool_class());
		rec.setApply_command(model.getApply_command());
		rec.setInventory_command(model.getInventory_command());
		rec.setNote(model.getNote());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.devconfigInfo")});
			throw exp;
		}

		devconfigRepository.saveAndFlush(rec);
		MstDevconfigEntity updateRec = devconfigRepository.findOne(id);
		DevconfigModel newModel = new DevconfigModel();
		newModel.setId(updateRec.getId());
		newModel.setModel_id(updateRec.getModel_id());
		newModel.setSerial_no(updateRec.getSerial_no());
		newModel.setConfig_id(updateRec.getConfig_id());
		newModel.setConfig_type(updateRec.getConfig_type());
		newModel.setRequired_class(updateRec.getRequired_class());
		newModel.setName_locale1(updateRec.getName_locale1());
		newModel.setName_locale2(updateRec.getName_locale2());
		newModel.setName_locale3(updateRec.getName_locale3());
		newModel.setDescription_locale1(updateRec.getDescription_locale1());
		newModel.setDescription_locale2(updateRec.getDescription_locale2());
		newModel.setDescription_locale3(updateRec.getDescription_locale3());
		newModel.setData_type(updateRec.getData_type());
		newModel.setData(updateRec.getData());
		newModel.setConfig_file_name(updateRec.getConfig_file_name());
		newModel.setTool_address(updateRec.getTool_address());
		newModel.setTool_class(updateRec.getTool_class());
		newModel.setApply_command(updateRec.getApply_command());
		newModel.setInventory_command(updateRec.getInventory_command());
		newModel.setNote(updateRec.getNote());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInserted(updateRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdated(updateRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}


	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		MstDevconfigEntity rec = devconfigRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.devconfigInfo")});
			throw exp;
		}
		devconfigRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("config_id".equals(str)) mf.config_id = true;
				if ("config_type".equals(str)) mf.config_type = true;
				if ("required_class".equals(str)) mf.required_class = true;
				if ("name_locale1".equals(str)) mf.name_locale1 = true;
				if ("name_locale2".equals(str)) mf.name_locale2 = true;
				if ("name_locale3".equals(str)) mf.name_locale3 = true;
				if ("description_locale1".equals(str)) mf.description_locale1 = true;
				if ("description_locale2".equals(str)) mf.description_locale2 = true;
				if ("description_locale3".equals(str)) mf.description_locale3 = true;
				if ("data_type".equals(str)) mf.data_type = true;
				if ("data".equals(str)) mf.data = true;
				if ("config_file_name".equals(str)) mf.config_file_name = true;
				if ("tool_address".equals(str)) mf.tool_address = true;
				if ("tool_class".equals(str)) mf.tool_class = true;
				if ("apply_command".equals(str)) mf.apply_command = true;
				if ("inventory_command".equals(str)) mf.inventory_command = true;
				if ("note".equals(str)) mf.note = true;
				if ("version".equals(str)) mf.version = true;
				if ("inserted".equals(str)) mf.inserted = true;
				if ("insert_time".equals(str)) mf.insert_time = true;
				if ("updated".equals(str)) mf.updated = true;
				if ("update_time".equals(str)) mf.update_time = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			model_id = b;
			serial_no = b;
			config_id = b;
			config_type = b;
			required_class = b;
			name_locale1 = b;
			name_locale2 = b;
			name_locale3 = b;
			description_locale1 = b;
			description_locale2 = b;
			description_locale3 = b;
			data_type = b;
			data = b;
			config_file_name = b;
			tool_address = b;
			tool_class = b;
			apply_command = b;
			inventory_command = b;
			note = b;
			version = b;
			inserted = b;
			insert_time = b;
			updated = b;
			update_time = b;
		}
		public boolean id = true;
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean config_id = true;
		public boolean config_type = true;
		public boolean required_class = true;
		public boolean name_locale1 = true;
		public boolean name_locale2 = true;
		public boolean name_locale3 = true;
		public boolean description_locale1 = true;
		public boolean description_locale2 = true;
		public boolean description_locale3 = true;
		public boolean data_type = true;
		public boolean data = true;
		public boolean config_file_name = true;
		public boolean tool_address = true;
		public boolean tool_class = true;
		public boolean apply_command = true;
		public boolean inventory_command = true;
		public boolean note = true;
		public boolean version = true;
		public boolean inserted = true;
		public boolean insert_time = true;
		public boolean updated = true;
		public boolean update_time = true;
	}
}


package com.app.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.script.Bindings;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.SimpleScriptContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.entity.StdGwCommandHistoryEntity;
import com.app.model.RequestOpeInstructModel;
import com.app.model.ResponseOpeInstructModel;
import com.app.model.SubResponseModel;
import com.app.repository.DeviceRepositoryCustom;
import com.app.repository.GWCommandHistoryRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.sdk.iot.service.devicetwin.DeviceMethod;
import com.microsoft.azure.sdk.iot.service.devicetwin.MethodResult;

/**
 * GWへのコマンド実行依頼サービス
 * @author 810
 *
 */
@Service
@Transactional(readOnly = true)
public class GatewayCommandService {
	@Autowired
	private GWCommandHistoryRepository gWCommandHistoryRepository;
	@Autowired
	private DeviceRepositoryCustom deviceRepositoryCustom;
	@Autowired
	private MessageSource messageSource;
	public static final Logger logger = LoggerFactory.getLogger(GatewayCommandService.class);
	private static final Long responseTimeout = TimeUnit.SECONDS.toSeconds(30);
	private static final Long connectTimeout = TimeUnit.SECONDS.toSeconds(5);
	private static final String GATEWAY_METHOD = "OpeInstruct";
	private String _iotHubConnectionString = System.getenv("iot.hub.connection.string");

	/**
	 * GWデバイスとデバイスの権限チェックを行う。
	 * @param locale
	 * @param reqModel
	 * @param lstError
	 * @return エラーリスト
	 */
	public List<SubResponseModel> checkDeviceAuthority(Locale locale, RequestOpeInstructModel reqModel, List<SubResponseModel> lstError) {
		// GWデバイス権限チェック
		Boolean auth = deviceRepositoryCustom.hasAuthority(reqModel.getGw_model_id(), reqModel.getGw_serial_no(),
				reqModel.getRequest_user_id());
		if (auth == null) {
			logger.info("GWデバイス未登録または権限無し gw_model_id=" + reqModel.getGw_model_id() + ", gw_serial_no=" +
					reqModel.getGw_serial_no() + ", user_id=" + reqModel.getRequest_user_id());
			lstError.add(new SubResponseModel("gw_model_id",
					messageSource.getMessage(Consts.MESSAGE_E000114, null, locale)));
			lstError.add(new SubResponseModel("gw_serial_no",
					messageSource.getMessage(Consts.MESSAGE_E000114, null, locale)));
		}

		// デバイス権限チェック
		if (reqModel.getModel_id() != null || reqModel.getSerial_no() != null) {
			auth = deviceRepositoryCustom.hasAuthority(reqModel.getModel_id(), reqModel.getSerial_no(),
					reqModel.getRequest_user_id());
			if (auth == null) {
				logger.info("デバイス未登録または権限無し gw_model_id=" + reqModel.getModel_id() + ", gw_serial_no=" +
						reqModel.getSerial_no() + ", user_id=" + reqModel.getRequest_user_id());
				lstError.add(new SubResponseModel("model_id",
						messageSource.getMessage(Consts.MESSAGE_E000114, null, locale)));
				lstError.add(new SubResponseModel("serial_no",
						messageSource.getMessage(Consts.MESSAGE_E000114, null, locale)));
			}
		}

		return lstError;
	}

	/**
	 * GWコマンド実行履歴を登録する。
	 * @param reqModel
	 * @return 登録したレコードのID
	 */
	@Transactional(readOnly = false)
	public Integer addGwCommandHistory(RequestOpeInstructModel reqModel) {
		logger.info("GWコマンド実行履歴登録");
		StdGwCommandHistoryEntity newRec = new StdGwCommandHistoryEntity();
		newRec.setGw_model_id(reqModel.getGw_model_id());
		newRec.setGw_serial_no(reqModel.getGw_serial_no());
		newRec.setModel_id(reqModel.getModel_id());
		newRec.setSerial_no(reqModel.getSerial_no());
		newRec.setOperation(reqModel.getOperation());
		newRec.setArgument(reqModel.getArgumentString());
		newRec.setExec_time(reqModel.getExec_time());
		newRec.setWait_time(reqModel.getWait_time());
		newRec.setRequest_user_id(reqModel.getRequest_user_id());
		newRec.setRemote_addr(reqModel.getRemote_addr());
		newRec.setClient_addr(reqModel.getClient_addr());
		newRec.setHttp_referer(reqModel.getHttp_referer());
		newRec.setCors_origin(reqModel.getCors_origin());
		newRec.setRequest_time(new Timestamp(System.currentTimeMillis()));
		newRec = gWCommandHistoryRepository.save(newRec);

		return newRec.getId();
	}

	/**
	 * Gatewayのコマンドを実行する。
	 * @param reqModel
	 * @return
	 * @throws Exception
	 */
	public ResponseOpeInstructModel requestCommand(RequestOpeInstructModel reqModel, Integer sendId) throws Exception {

		if (StringUtil.IsNullOrEmpty(_iotHubConnectionString)) {
			//throw new IllegalArgumentException("IoTHubConnectionString is not set.");
			_iotHubConnectionString = "HostName=iotHubjnzv4f47vqym4.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=S6BmIx3SkkUW1Z3bzwi7lCUvY2ikrxABQWJDrR/Q1DY=";
		}
	    logger.info("IoTHubConnectionString=" + (_iotHubConnectionString.length() > 30 ? _iotHubConnectionString.substring(0, 30) + "..." : _iotHubConnectionString));

		// パラメータJSON作成
	    String device = reqModel.getGw_model_id() + "$" + reqModel.getGw_serial_no();
	    Map<String, Object> map = new LinkedHashMap<String,Object>();
	    map.put("sendId", sendId);
	    map.put("operation", reqModel.getOperation());
	    map.put("modelId", reqModel.getModel_id());
	    map.put("serialNo", reqModel.getSerial_no());
	    map.put("execTime", reqModel.getExec_time());
	    map.put("argument", reqModel.getArgument());

	    Long waittime = reqModel.getWait_time() == null ? responseTimeout : reqModel.getWait_time().longValue();

	    // ダイレクトメソッド呼び出し
	    logger.debug("ダイレクトメソッド呼び出し device=" + device + ", method=" + GATEWAY_METHOD +", waittime=" + waittime + ", parameter=" + map);
		DeviceMethod methodClient = DeviceMethod.createFromConnectionString(_iotHubConnectionString);
		MethodResult result = methodClient.invoke(device, GATEWAY_METHOD, waittime, connectTimeout, map);

	    // レスポンスJSON取得
	    ObjectMapper mapper = new ObjectMapper();
	    Map<String, Object> resultMap = new LinkedHashMap<String,Object>();

	    logger.debug("ダイレクトメソッド paylaod.toString()=" + result.getPayload().toString());
	    logger.debug("ダイレクトメソッド paylaod=" + result.getPayload());

	    resultMap = mapper.readValue(result.getPayload().toString(), new TypeReference<LinkedHashMap<String,Object>>() {});
	    resultMap.put("resultCode", result.getStatus());
	    logger.debug("ダイレクトメソッドレスポンス " + resultMap);

	    // レスポンス作成
	    ResponseOpeInstructModel resModel = new ResponseOpeInstructModel();
	    resModel.setSend_id(sendId);

		resModel.setResult_code(String.valueOf(result.getStatus()));

		Object obj1 =  resultMap.get("resultDetailCode");

		if (obj1 instanceof String){
			resModel.setResult_detail_code((String)resultMap.get("resultDetailCode"));
	    }else if (obj1 instanceof Integer){
	    	resModel.setResult_detail_code(String.valueOf((Integer)(resultMap.get("resultDetailCode"))));

	    }
		resModel.setResult_message((String)resultMap.get("resultMessage"));
		resModel.setData(resultMap.get("data"));

		return resModel;
	}

	/**
	 * GWコマンド実行履歴を更新する。
	 * @param resModel GWコマンド実行時のレスポンスデータ
	 * @param historyId GWコマンド実行履歴登録時のID
	 * @throws Exception
	 */
	@Transactional(readOnly = false)
	public void updateGwCommandHistory(ResponseOpeInstructModel resModel, Integer historyId) throws Exception {
		// GWコマンド実行履歴更新
	    logger.info("GWコマンド実行履歴更新");
		StdGwCommandHistoryEntity newRec = gWCommandHistoryRepository.findOne(historyId);
		newRec.setResult_code(resModel.getResult_code());
		newRec.setResult_detail_code(resModel.getResult_detail_code());
		newRec.setResult_message(resModel.getResult_message());
		if (resModel.getData() != null) {
			ObjectMapper mapper = new ObjectMapper();
			String data = mapper.writeValueAsString(resModel.getData());
			newRec.setResult_data(data);
		}
		newRec.setResult_time(new Timestamp(System.currentTimeMillis()));
		gWCommandHistoryRepository.saveAndFlush(newRec);
	}

	/**
	 * GWコマンド実行前スクリプトを実行する。
	 * @param reqModel APIパラメータ
	 * @param sendId GWコマンド実行履歴ID
	 * @throws Exception
	 */
	public void beforeRequestCommand(RequestOpeInstructModel reqModel) throws Exception {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("gw_model_id", reqModel.getGw_model_id());
		param.put("gw_serial_no", reqModel.getGw_serial_no());
		param.put("model_id", reqModel.getModel_id());
		param.put("serial_no", reqModel.getSerial_no());
		param.put("operation", reqModel.getOperation());
		execScript("before.js", param);
	}

	/**
	 * GWコマンド実行後スクリプトを実行する。
	 * @param reqModel APIパラメータ
	 * @param sendId GWコマンド実行履歴ID
	 * @throws Exception
	 */
	public void afterRequestCommand(RequestOpeInstructModel reqModel) throws Exception {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("gw_model_id", reqModel.getGw_model_id());
		param.put("gw_serial_no", reqModel.getGw_serial_no());
		param.put("model_id", reqModel.getModel_id());
		param.put("serial_no", reqModel.getSerial_no());
		param.put("operation", reqModel.getOperation());
		execScript("after.js", param);
	}

	/**
	 * 引数で指定されたスクリプトファイルのJavaScriptを実行する。
	 * スクリプトファイルは、環境変数opeinstruct.script.dirで指定されたディレクトリに
	 * 配置されているものとする。未設定の場合は、カレントディレクトリに配置されている
	 * ものとする。
	 * @param script スクリプトファイル名
	 * @param param スクリプト引数
	 * @throws Exception
	 */
	private void execScript(String script, Map<String, Object> param) throws Exception {
		String scriptDir = System.getenv("opeinstruct.script.dir");
		if (scriptDir == null) {
			scriptDir = System.getProperty("user.dir");
		}

		scriptDir += scriptDir.endsWith("/") ? "" : "/";
		Path path = Paths.get(scriptDir + script);
		if (Files.exists(path)) {
			logger.info("exec script. (" + path + ")");
			ScriptEngineManager factory = new ScriptEngineManager();
			ScriptEngine engine = factory.getEngineByName("nashorn");
			Bindings bindings = engine.createBindings();
			ScriptContext context = new SimpleScriptContext();
			context.setBindings(bindings, ScriptContext.ENGINE_SCOPE);
			bindings.putAll(param);
			engine.eval(Files.newBufferedReader(path), context);
		} else {
			logger.info("script not exists. (" + path + ")");
		}
	}
}


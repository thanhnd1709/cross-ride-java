package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.Consts;
import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstUserRollEntity;
import com.app.exception.BadRequestException;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.SubResponseModel;
import com.app.model.UserRollModel;
import com.app.model.UserRollQueryModel;
import com.app.repository.UserRoleRepository;
import com.app.repository.UserRoleRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class UserRoleService {
	@Autowired
	private UserRoleRepository userRoleRepository;
	@Autowired
	private UserRoleRepositoryCustom userRoleRepositoryCustom;
	@Autowired
	private AuthUserInfoComponent authUserInfoComponent;
	@Autowired
	private MessageSource _msgSource;

	public UserRollModel findOne(int uuid, String fields) throws Exception {
		ModelFilter mf = makeModelFilter(fields);

		MstUserRollEntity entity = userRoleRepository.findOne(uuid);
		UserRollModel newModel = null;
		if (entity != null) {
			newModel = new UserRollModel();
			if (mf.id)
				newModel.setId(entity.getId());
			if (mf.user_id)
				newModel.setUser_id(entity.getUser_id());
			if (mf.role_id)
				newModel.setRole_id(entity.getRole_id());
			if (mf.version)
				newModel.setVersion(entity.getVersion());
			if (mf.inserted)
				newModel.setInserted(entity.getInserted());
			if (mf.insert_time)
				newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated)
				newModel.setUpdated(entity.getUpdated());
			if (mf.update_time)
				newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}
		return newModel;
	}

	public List<UserRollModel> findAll(UserRollQueryModel filter) throws Exception {

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<MstUserRollEntity> entList = userRoleRepositoryCustom.findAll(filter, sort, limit, offset);
		List<MstUserRollEntity> adminChk = userRoleRepositoryCustom.RoleAccessChk(filter);
		List<UserRollModel> modelList = new ArrayList<UserRollModel>();
		for (MstUserRollEntity entity : entList) {
			// 認証されたユーザIDを検索条件に設定
			String userId = authUserInfoComponent.getPrincipalName();
			UserRollModel newModel = new UserRollModel();
			// ログインユーザがシステム管理者ではなく、ログインユーザと紐付いていないロールの場合、返却しない
			if (adminChk.isEmpty() && !entity.getUser_id().equals(userId)) {
				continue;
			}
			if (mf.id)
				newModel.setId(entity.getId());
			if (mf.user_id)
				newModel.setUser_id(entity.getUser_id());
			if (mf.role_id)
				newModel.setRole_id(entity.getRole_id());
			if (mf.version)
				newModel.setVersion(entity.getVersion());
			if (mf.inserted)
				newModel.setInserted(entity.getInserted());
			if (mf.insert_time)
				newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated)
				newModel.setUpdated(entity.getUpdated());
			if (mf.update_time)
				newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(UserRollQueryModel filter) throws Exception {
		return userRoleRepositoryCustom.countAll(filter);
	}

	@Transactional(readOnly = false)
	public UserRollModel save(UserRollModel model) throws Exception {

		MstUserRollEntity newRec = new MstUserRollEntity();

		if (model.getUser_id() != null)
			newRec.setUser_id(model.getUser_id());
		if (model.getRole_id() != null)
			newRec.setRole_id(model.getRole_id());
		newRec.setVersion(0L);

		newRec = userRoleRepository.save(newRec);

		UserRollModel newModel = new UserRollModel();
		newModel.setId(newRec.getId());
		newModel.setUser_id(newRec.getUser_id());
		newModel.setRole_id(newRec.getRole_id());
		newModel.setVersion(newRec.getVersion());
		newModel.setInserted(newRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdated(newRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public UserRollModel update(Locale locale, int id, UserRollModel model) throws Exception {
		MstUserRollEntity rec = userRoleRepositoryCustom.findOneForUpdate(id);
		if (rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[] { new DefaultMessageSourceResolvable("message.userRoleInfo") });
			throw exp;
		}

		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[] { new DefaultMessageSourceResolvable("message.userRoleInfo") });
			throw exp;
		} else {
			List<SubResponseModel> lstError = new ArrayList<>();
			// ユーザID・ロールIDは変更不可
			if (model.getUser_id() != null && !model.getUser_id().equals(rec.getUser_id())) {
				lstError.add(
						new SubResponseModel("user_id", _msgSource.getMessage(Consts.MESSAGE_E000127, new String[]{"user_id"}, locale)));

			}

			if (model.getRole_id() != null && !model.getRole_id().equals(rec.getRole_id())) {
				lstError.add(
						new SubResponseModel("role_id", _msgSource.getMessage(Consts.MESSAGE_E000127, new String[]{"role_id"}, locale)));
			}
			if (!lstError.isEmpty()) {
				BadRequestException exp = new BadRequestException("");
				exp.setArgs(lstError);
				throw exp;
			}
		}

		rec.setUser_id(model.getUser_id());
		rec.setRole_id(model.getRole_id());

		userRoleRepository.saveAndFlush(rec);
		MstUserRollEntity updateRec = userRoleRepository.findOne(id);
		UserRollModel newModel = new UserRollModel();
		newModel.setId(updateRec.getId());
		newModel.setUser_id(updateRec.getUser_id());
		newModel.setRole_id(updateRec.getRole_id());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInserted(updateRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdated(updateRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		MstUserRollEntity rec = userRoleRepository.findOne(uuid);
		if (rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[] { new DefaultMessageSourceResolvable("message.userRoleInfo") });
			throw exp;
		}
		userRoleRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str))
					mf.id = true;
				if ("user_id".equals(str))
					mf.user_id = true;
				if ("role_id".equals(str))
					mf.role_id = true;
				if ("version".equals(str))
					mf.version = true;
				if ("inserted".equals(str))
					mf.inserted = true;
				if ("insert_time".equals(str))
					mf.insert_time = true;
				if ("updated".equals(str))
					mf.updated = true;
				if ("update_time".equals(str))
					mf.update_time = true;
			}
		}
		return mf;
	}

	private ModelFilter makeRoleFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("role_id".equals(str))
					mf.role_id = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			user_id = b;
			role_id = b;
			version = b;
			inserted = b;
			insert_time = b;
			updated = b;
			update_time = b;
		}

		public boolean id = true;
		public boolean user_id = true;
		public boolean role_id = true;
		public boolean version = true;
		public boolean inserted = true;
		public boolean insert_time = true;
		public boolean updated = true;
		public boolean update_time = true;
	}

	// ログインユーザがアクセス可能なロールかチェック
	public List<MstUserRollEntity> RoleAccessChk(UserRollQueryModel query) {
		return userRoleRepositoryCustom.RoleAccessChk(query);
	}

	// ログインユーザがアクセス可能なロールかチェック
	public List<MstUserRollEntity> RoleAccessChk(UserRollModel query) {
		return userRoleRepositoryCustom.RoleAccessChk(query);
	}

	// ログインユーザがアクセス可能なロールかチェック
	public List<MstUserRollEntity> RoleAccessChkId(Integer id) {
		return userRoleRepositoryCustom.RoleAccessChkId(id);
	}

}

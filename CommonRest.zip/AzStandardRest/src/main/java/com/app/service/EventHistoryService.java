package com.app.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.common.utils.StringUtil;
import com.app.entity.EventHistoryEntity;
import com.app.exception.IoTSQLException;
import com.app.model.EventHistoryListModel;
import com.app.model.EventHistoryModel;
import com.app.model.ResponseEventHistoryModel;
import com.app.repository.EventHistoryRepositoryCustom;

/**
 * イベント・アラーム履歴検索サービスクラス
 * @author（TOSCO）小川
 */
@Service
@Transactional(readOnly = true)
public class EventHistoryService {

	@Autowired private EventHistoryRepositoryCustom eventHistoryRepositoryCustom;

	/**
	 * イベント・アラーム履歴検索処理
	 * @return イベント・アラーム履歴リスト
	 */
	public ResponseEventHistoryModel SearchEventHistory(EventHistoryModel reqModel) throws Exception{

		// 取得フィールド処理
		ModelFilter mf = makeModelFilter(reqModel.getFields());

		// ソート処理
		String sort = null;
		if (reqModel.getSort() != null) {
			for (String item : reqModel.getSort().split(",")) {
				if(sort != null){
					sort += ", ";
				}else{
					sort ="";
				}
				if(item.startsWith("-")){
					sort += (item.toLowerCase()).replace("-", "") + " DESC";
				}else{
					sort += item.toLowerCase();
				}
			}
		}

		// ページング処理
		Integer limit2 = null;
		Integer limit = null;
		Integer offset = null;
		if (reqModel.getMax_number() != null && reqModel.getPage() == null && reqModel.getLimit() == null){
			 offset = 0;
			 limit = (reqModel.getMax_number());
		}
		if (reqModel.getPage() != null && reqModel.getLimit() != null) {

			if (reqModel.getMax_number() != null && reqModel.getMax_number() < Integer.parseInt(reqModel.getLimit())){
				limit = reqModel.getMax_number();
			}else{
				limit = Integer.parseInt(reqModel.getLimit());
			}
			limit2 =  Integer.parseInt(reqModel.getLimit());
			offset = (Integer.parseInt(reqModel.getPage()) - 1) * limit2;
		}

		Timestamp dateFrom;
		Timestamp dateTo;
		try {
			// イベント時刻(From)
			dateFrom = DateTimeUtil.toTimestamp1(reqModel.getEvent_time_from());

			// イベント時刻(To)
			String eventTimeTo = reqModel.getEvent_time_to();
			if(eventTimeTo != null && !"".equals(eventTimeTo)){
				dateTo = DateTimeUtil.toTimestamp1(eventTimeTo);
			}else{
				dateTo = new Timestamp(System.currentTimeMillis());
			}
		}catch (Exception e) {
			throw new IoTSQLException(e);
		}

		/*********************************
		 * イベント・アラーム履歴取得処理
		 *********************************/
		ResponseEventHistoryModel model = new ResponseEventHistoryModel();
		List<EventHistoryListModel> modelList = new ArrayList<>();
		List<EventHistoryEntity> entList = new ArrayList<>();

		if (!StringUtil.IsNullOrEmpty(reqModel.getDevice_group_id()) && !StringUtil.IsBlank(reqModel.getDevice_group_id())) {
			// ①デバイスグループID指定時 かつ 親子展開フラグがtrueの時、
			// デバイスグループを親子展開し展開後のデバイスグループ群で対象のイベントIDを求めイベント履歴を検索する
			if (reqModel.getParent_flg() != null && reqModel.getParent_flg() == true) {
				entList = eventHistoryRepositoryCustom.searchDeviceGroupIdTrue(reqModel, dateFrom, dateTo, sort, limit, offset);
			}

			// ②デバイスグループID指定時 かつ 親子展開フラグがfalseの時、
			// 指定されたデバイスグループで対象のイベントIDを求めイベント履歴を検索する
			else if (reqModel.getParent_flg() == null || reqModel.getParent_flg() == false) {
				entList = eventHistoryRepositoryCustom.searchDeviceGroupIdFalse(reqModel, dateFrom, dateTo, sort, limit, offset);
			}
		}

		else if((reqModel.getDevice_list() != null && reqModel.getDevice_list().size() > 0)){
			// ③[配列]デバイスリスト指定時 かつ 親子展開フラグがtrueの時、
			// デバイスを親子展開し展開後のデバイス群で対象のイベントIDを求めイベント履歴を検索する
			if(reqModel.getParent_flg() != null && reqModel.getParent_flg() == true){
				entList = eventHistoryRepositoryCustom.searchDeviceLitsTrue(reqModel, dateFrom, dateTo, sort, limit, offset);
			}

			// ④[配列]デバイスリスト指定時 かつ 親子展開フラグがfalseの時、
			// 指定されたデバイスで対象のイベントIDを求めイベント履歴を検索する
			else if(reqModel.getParent_flg() == null || reqModel.getParent_flg() == false){
				entList = eventHistoryRepositoryCustom.searchDeviceListFalse(reqModel, dateFrom, dateTo, sort, limit, offset);
			}
		}

		// ⑤デバイスグループID、[配列]デバイスリスト未指定時、イベント時刻(From-To)等でイベント履歴を検索する
		else if(reqModel.getDevice_group_id() == null && reqModel.getDevice_list() == null){
			entList = eventHistoryRepositoryCustom.searchEventTime(reqModel, dateFrom, dateTo, sort, limit, offset);
		}

		for (EventHistoryEntity entity : entList){
			EventHistoryListModel newModel = new EventHistoryListModel();
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.detection_class) newModel.setDetection_class(entity.getDetection_class());
			if (mf.event_id) newModel.setEvent_id(entity.getEvent_id());
			if (mf.event_time) newModel.setEvent_time(entity.getEvent_time());
			if (mf.event_status) newModel.setEvent_status(entity.getEvent_status());
			if (mf.incident_class) newModel.setIncident_class(entity.getIncident_class());
			if (mf.event_level) newModel.setEvent_level(entity.getEvent_level());
			if (mf.detection_info) newModel.setDetection_info(entity.getDetection_info());
			if (mf.event_type) newModel.setEvent_type(entity.getEvent_type());
			if (mf.sensor_id) newModel.setSensor_id(entity.getSensor_id());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.chk_app_name) newModel.setChk_app_name(entity.getChk_app_name());
			if (mf.chk_app_parameter) newModel.setChk_app_parameter(entity.getChk_app_parameter());
			if (mf.check_timing) newModel.setCheck_timing(entity.getCheck_timing());
			if (mf.note) newModel.setNote(entity.getNote());
			modelList.add(newModel);
		}

		model.setTotal(entList.size());
		model.setEvent_history_list(modelList);

		return model;
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("detection_class".equals(str)) mf.detection_class = true;
				if ("event_id".equals(str)) mf.event_id = true;
				if ("event_time".equals(str)) mf.event_time = true;
				if ("event_status".equals(str)) mf.event_status = true;
				if ("incident_class".equals(str)) mf.incident_class = true;
				if ("event_level".equals(str)) mf.event_level = true;
				if ("detection_info".equals(str)) mf.detection_info = true;
				if ("event_type".equals(str)) mf.event_type = true;
				if ("sensor_id".equals(str)) mf.sensor_id = true;
				if ("name_locale1".equals(str)) mf.name_locale1 = true;
				if ("name_locale2".equals(str)) mf.name_locale2 = true;
				if ("name_locale3".equals(str)) mf.name_locale3 = true;
				if ("description_locale1".equals(str)) mf.description_locale1 = true;
				if ("description_locale2".equals(str)) mf.description_locale2 = true;
				if ("description_locale3".equals(str)) mf.description_locale3 = true;
				if ("chk_app_name".equals(str)) mf.chk_app_name = true;
				if ("chk_app_parameter".equals(str)) mf.chk_app_parameter = true;
				if ("check_timing".equals(str)) mf.check_timing = true;
				if ("note".equals(str)) mf.note = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			model_id = b;
			serial_no = b;
			detection_class = b;
			event_id = b;
			event_time = b;
			event_status = b;
			incident_class = b;
			event_level = b;
			detection_info = b;
			event_type = b;
			sensor_id = b;
			name_locale1 = b;
			name_locale2 = b;
			name_locale3 = b;
			description_locale1 = b;
			description_locale2 = b;
			description_locale3 = b;
			chk_app_name = b;
			chk_app_parameter = b;
			check_timing = b;
			note = b;
		}
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean detection_class = true;
		public boolean event_id = true;
		public boolean event_time = true;
		public boolean event_status = true;
		public boolean incident_class = true;
		public boolean event_level = true;
		public boolean detection_info = true;
		public boolean event_type = true;
		public boolean sensor_id = true;
		public boolean name_locale1 = true;
		public boolean name_locale2 = true;
		public boolean name_locale3 = true;
		public boolean description_locale1 = true;
		public boolean description_locale2 = true;
		public boolean description_locale3 = true;
		public boolean chk_app_name = true;
		public boolean chk_app_parameter = true;
		public boolean check_timing = true;
		public boolean note = true;
	}
}

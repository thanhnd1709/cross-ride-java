package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.UserDeviceGroupAuthorityEntity;
import com.app.model.UserDeviceGroupAuthorityModel;
import com.app.model.UserDeviceGroupAuthorityQueryModel;
import com.app.repository.UserDeviceGroupAuthorityRepository;

/**
 * ユーザ・デバイスグループ権限情報サービスクラス
 * @author 810
 *
 */
@Service
@Transactional(readOnly = true)
public class UserDeviceGroupAuthorityService {
	@Autowired
	private UserDeviceGroupAuthorityRepository userDeviceGroupAuthorityRepository;

	/**
	 * ユーザ・デバイスグループ権限情報一覧取得
	 * @param filter 検索条件オブジェクト
	 * @return ユーザ・デバイス権限情報リスト
	 * @throws Exception
	 */
	public List<UserDeviceGroupAuthorityModel> findAll(UserDeviceGroupAuthorityQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		// 検索実行
		List<UserDeviceGroupAuthorityEntity> entList = userDeviceGroupAuthorityRepository.findAll(filter, sort, limit, offset);

		// 返却項目フィルタ処理
		List<UserDeviceGroupAuthorityModel> modelList = new ArrayList<UserDeviceGroupAuthorityModel>();
		for (UserDeviceGroupAuthorityEntity entity : entList) {
			UserDeviceGroupAuthorityModel newModel = new UserDeviceGroupAuthorityModel();
			if (mf.device_group_id) newModel.setDevice_group_id(entity.getDevice_group_id());
			if (mf.device_group_type) newModel.setDevice_group_type(entity.getDevice_group_type());
			if (mf.device_group_subtype) newModel.setDevice_group_subtype(entity.getDevice_group_subtype());
			if (mf.device_group_name_locale1) newModel.setDevice_group_name_locale1(entity.getDevice_group_name_locale1());
			if (mf.device_group_name_locale2) newModel.setDevice_group_name_locale2(entity.getDevice_group_name_locale2());
			if (mf.device_group_name_locale3) newModel.setDevice_group_name_locale3(entity.getDevice_group_name_locale3());
			if (mf.device_group_description_locale1) newModel.setDevice_group_description_locale1(entity.getDevice_group_description_locale1());
			if (mf.device_group_description_locale2) newModel.setDevice_group_description_locale2(entity.getDevice_group_description_locale2());
			if (mf.device_group_description_locale3) newModel.setDevice_group_description_locale3(entity.getDevice_group_description_locale3());
			if (mf.parent_device_group_id) newModel.setParent_device_group_id(entity.getParent_device_group_id());
			if (mf.setup_place) newModel.setSetup_place(entity.getSetup_place());
			if (mf.setup_status) newModel.setSetup_status(entity.getSetup_status());
			if (mf.latitude) newModel.setLatitude(entity.getLatitude());
			if (mf.longitude) newModel.setLongitude(entity.getLongitude());
			if (mf.device_group_note) newModel.setDevice_group_note(entity.getDevice_group_note());
			if (mf.role_id) newModel.setRole_id(entity.getRole_id());
			if (mf.root_group_id) newModel.setRoot_group_id(entity.getRoot_group_id());
			if (mf.role_name_locale1) newModel.setRole_name_locale1(entity.getRole_name_locale1());
			if (mf.role_name_locale2) newModel.setRole_name_locale2(entity.getRole_name_locale2());
			if (mf.role_name_locale3) newModel.setRole_name_locale3(entity.getRole_name_locale3());
			if (mf.role_description_locale1) newModel.setRole_description_locale1(entity.getRole_description_locale1());
			if (mf.role_description_locale2) newModel.setRole_description_locale2(entity.getRole_description_locale2());
			if (mf.role_description_locale3) newModel.setRole_description_locale3(entity.getRole_description_locale3());
			if (mf.role_note) newModel.setRole_note(entity.getRole_note());
			if (mf.hierarchy) newModel.setHierarchy(entity.getHierarchy());
			modelList.add(newModel);
		}
		return modelList;
	}

	/**
	 * ユーザ・デバイスグループ権限情報一覧件数取得
	 * @param filter 検索条件オブジェクト
	 * @return 検索結果件数
	 * @throws Exception
	 */
	public Long countAll(UserDeviceGroupAuthorityQueryModel filter) throws Exception{
		return userDeviceGroupAuthorityRepository.countAll(filter);
	}

	/**
	 * 返却項目フィルター作成
	 * @param fields 取得対象項目名リスト（カンマ区切り）
	 * @return フィルターオブジェクト
	 */
	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("device_group_id".equals(str)) mf.device_group_id = true;
				if ("device_group_type".equals(str)) mf.device_group_type = true;
				if ("device_group_subtype".equals(str)) mf.device_group_subtype = true;
				if ("device_group_name_locale1".equals(str)) mf.device_group_name_locale1 = true;
				if ("device_group_name_locale2".equals(str)) mf.device_group_name_locale2 = true;
				if ("device_group_name_locale3".equals(str)) mf.device_group_name_locale3 = true;
				if ("device_group_description_locale1".equals(str)) mf.device_group_description_locale1 = true;
				if ("device_group_description_locale2".equals(str)) mf.device_group_description_locale2 = true;
				if ("device_group_description_locale3".equals(str)) mf.device_group_description_locale3 = true;
				if ("parent_device_group_id".equals(str)) mf.parent_device_group_id = true;
				if ("setup_place".equals(str)) mf.setup_place = true;
				if ("setup_status".equals(str)) mf.setup_status = true;
				if ("latitude".equals(str)) mf.latitude = true;
				if ("longitude".equals(str)) mf.longitude = true;
				if ("device_group_note".equals(str)) mf.device_group_note = true;
				if ("role_id".equals(str)) mf.role_id = true;
				if ("root_group_id".equals(str)) mf.root_group_id = true;
				if ("role_name_locale1".equals(str)) mf.role_name_locale1 = true;
				if ("role_name_locale2".equals(str)) mf.role_name_locale2 = true;
				if ("role_name_locale3".equals(str)) mf.role_name_locale3 = true;
				if ("role_description_locale1".equals(str)) mf.role_description_locale1 = true;
				if ("role_description_locale2".equals(str)) mf.role_description_locale2 = true;
				if ("role_description_locale3".equals(str)) mf.role_description_locale3 = true;
				if ("role_note".equals(str)) mf.role_note = true;
				if ("hierarchy".equals(str)) mf.hierarchy = true;
			}
		}
		return mf;
	}

	/**
	 * 返却項目フィルタークラス
	 * true=返却する。false=返却しない。
	 * @author 810
	 *
	 */
	class ModelFilter {
		public ModelFilter(boolean b) {
			device_group_id = b;
			device_group_type = b;
			device_group_subtype = b;
			device_group_name_locale1 = b;
			device_group_name_locale2 = b;
			device_group_name_locale3 = b;
			device_group_description_locale1 = b;
			device_group_description_locale2 = b;
			device_group_description_locale3 = b;
			parent_device_group_id = b;
			setup_place = b;
			setup_status = b;
			latitude = b;
			longitude = b;
			device_group_note = b;
			role_id = b;
			root_group_id = b;
			role_name_locale1 = b;
			role_name_locale2 = b;
			role_name_locale3 = b;
			role_description_locale1 = b;
			role_description_locale2 = b;
			role_description_locale3 = b;
			role_note = b;
			hierarchy = b;
		}
		public boolean device_group_id = true;
		public boolean device_group_type = true;
		public boolean device_group_subtype = true;
		public boolean device_group_name_locale1 = true;
		public boolean device_group_name_locale2 = true;
		public boolean device_group_name_locale3 = true;
		public boolean device_group_description_locale1 = true;
		public boolean device_group_description_locale2 = true;
		public boolean device_group_description_locale3 = true;
		public boolean parent_device_group_id = true;
		public boolean setup_place = true;
		public boolean setup_status = true;
		public boolean latitude = true;
		public boolean longitude = true;
		public boolean device_group_note = true;
		public boolean role_id = true;
		public boolean root_group_id = true;
		public boolean role_name_locale1 = true;
		public boolean role_name_locale2 = true;
		public boolean role_name_locale3 = true;
		public boolean role_description_locale1 = true;
		public boolean role_description_locale2 = true;
		public boolean role_description_locale3 = true;
		public boolean role_note = true;
		public boolean hierarchy = true;
	}
}


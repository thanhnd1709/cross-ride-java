package com.app.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.StdDevconfigHistoryEntity;
import com.app.exception.DataDuplicateException;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.DevconfigHistoriesModel;
import com.app.model.DevconfigHistoriesQueryModel;
import com.app.repository.DevconfigHistoriesRepository;
import com.app.repository.DevconfigHistoriesRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class DevconfigHistoriesService {

	@Autowired
	private DevconfigHistoriesRepository devconfigHistoriesRepository;
	@Autowired
	private DevconfigHistoriesRepositoryCustom devconfigHistoriesRepositoryCustom;

	public DevconfigHistoriesModel findOne(int uuid, String fields) throws Exception{
		ModelFilter mf = makeModelFilter(fields);

		StdDevconfigHistoryEntity entity = devconfigHistoriesRepository.findOne(uuid);
		DevconfigHistoriesModel newModel = null;
		if (entity != null) {
			newModel = new DevconfigHistoriesModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.config_id) newModel.setConfig_id(entity.getConfig_id());
			if (mf.config_file) newModel.setConfig_file(entity.getConfig_file());
			if (mf.gw_upload_time) newModel.setGw_upload_time(DateTimeUtil.formatTimestamp(entity.getGw_upload_time()));
			if (mf.format_version) newModel.setFormat_version(entity.getFormat_version());
			if (mf.config_version) newModel.setConfig_version(entity.getConfig_version());
			if (mf.file_notification_key) newModel.setFile_notification_key(entity.getFile_notification_key());
			if (mf.regist_flg) newModel.setRegist_flg(entity.getRegist_flg());
			if (mf.result_send_id) newModel.setResult_send_id(entity.getResult_send_id());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}
		return  newModel;
	}

	public List<DevconfigHistoriesModel> findAll(DevconfigHistoriesQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<StdDevconfigHistoryEntity> entList = devconfigHistoriesRepositoryCustom.findAll(filter, sort, limit, offset);
		List<DevconfigHistoriesModel> modelList = new ArrayList<DevconfigHistoriesModel>();
		for (StdDevconfigHistoryEntity entity : entList) {
			DevconfigHistoriesModel newModel = new DevconfigHistoriesModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.config_id) newModel.setConfig_id(entity.getConfig_id());
			if (mf.config_file) newModel.setConfig_file(entity.getConfig_file());
			if (mf.gw_upload_time) newModel.setGw_upload_time(DateTimeUtil.formatTimestamp(entity.getGw_upload_time()));
			if (mf.format_version) newModel.setFormat_version(entity.getFormat_version());
			if (mf.config_version) newModel.setConfig_version(entity.getConfig_version());
			if (mf.file_notification_key) newModel.setFile_notification_key(entity.getFile_notification_key());
			if (mf.regist_flg) newModel.setRegist_flg(entity.getRegist_flg());
			if (mf.result_send_id) newModel.setResult_send_id(entity.getResult_send_id());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(DevconfigHistoriesQueryModel filter) throws Exception{
		return devconfigHistoriesRepositoryCustom.countAll(filter);
	}

	@Transactional(readOnly = false)
	public DevconfigHistoriesModel save(DevconfigHistoriesModel model) throws Exception{

		StdDevconfigHistoryEntity newRec = new StdDevconfigHistoryEntity();

		if (model.getModel_id() != null) newRec.setModel_id(model.getModel_id());
		if (model.getSerial_no() != null) newRec.setSerial_no(model.getSerial_no());
		if (model.getConfig_id() != null) newRec.setConfig_id(model.getConfig_id());
		if (model.getConfig_file() != null) newRec.setConfig_file(model.getConfig_file());
		if (model.getGw_upload_time() != null) newRec.setGw_upload_time(DateTimeUtil.parseTimestamp(model.getGw_upload_time()));
		if (model.getFormat_version() != null) newRec.setFormat_version(model.getFormat_version());
		if (model.getConfig_version() != null) newRec.setConfig_version(model.getConfig_version());
		if (model.getFile_notification_key() != null) newRec.setFile_notification_key(model.getFile_notification_key());
		if (model.getRegist_flg() != null) newRec.setRegist_flg(model.getRegist_flg());
		if (model.getResult_send_id() != null) newRec.setResult_send_id(model.getResult_send_id());
		newRec.setVersion(0L);




		try {
			newRec = devconfigHistoriesRepository.save(newRec);
		} catch( Exception e) {
			DataDuplicateException exp = new DataDuplicateException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.devconfigHistoriesInfo")});
			throw exp;
		}

		DevconfigHistoriesModel newModel = new DevconfigHistoriesModel();
		newModel.setId(newRec.getId());
		newModel.setModel_id(newRec.getModel_id());
		newModel.setSerial_no(newRec.getSerial_no());
		newModel.setConfig_id(newRec.getConfig_id());
		newModel.setConfig_file(newRec.getConfig_file());
		newModel.setGw_upload_time(DateTimeUtil.formatTimestamp(newRec.getGw_upload_time()));
		newModel.setFormat_version(newRec.getFormat_version());
		newModel.setConfig_version(newRec.getConfig_version());
		newModel.setFile_notification_key(newRec.getFile_notification_key());
		newModel.setRegist_flg(newRec.getRegist_flg());
		newModel.setResult_send_id(newRec.getResult_send_id());
		newModel.setVersion(newRec.getVersion());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public DevconfigHistoriesModel update(Locale locale,int id, DevconfigHistoriesModel model) throws Exception{
		StdDevconfigHistoryEntity rec = devconfigHistoriesRepositoryCustom.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.devconfigHistoriesInfo")});
			throw exp;
		}

		rec.setModel_id(model.getModel_id());
		rec.setSerial_no(model.getSerial_no());
		rec.setConfig_id(model.getConfig_id());
		rec.setConfig_file(model.getConfig_file());
		rec.setGw_upload_time(DateTimeUtil.parseTimestamp(model.getGw_upload_time()));
		rec.setFormat_version(model.getFormat_version());
		rec.setConfig_version(model.getConfig_version());
		rec.setFile_notification_key(model.getFile_notification_key());
		rec.setRegist_flg(model.getRegist_flg());
		rec.setResult_send_id(model.getResult_send_id());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.devconfigHistoriesInfo")});
			throw exp;
		}



		devconfigHistoriesRepository.saveAndFlush(rec);
		StdDevconfigHistoryEntity updateRec = devconfigHistoriesRepository.findOne(id);
		DevconfigHistoriesModel newModel = new DevconfigHistoriesModel();
		newModel.setId(updateRec.getId());
		newModel.setModel_id(updateRec.getModel_id());
		newModel.setSerial_no(updateRec.getSerial_no());
		newModel.setConfig_id(updateRec.getConfig_id());
		newModel.setConfig_file(updateRec.getConfig_file());
		newModel.setGw_upload_time(DateTimeUtil.formatTimestamp(updateRec.getGw_upload_time()));
		newModel.setFormat_version(updateRec.getFormat_version());
		newModel.setConfig_version(updateRec.getConfig_version());
		newModel.setFile_notification_key(updateRec.getFile_notification_key());
		newModel.setRegist_flg(updateRec.getRegist_flg());
		newModel.setResult_send_id(updateRec.getResult_send_id());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}


	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		StdDevconfigHistoryEntity rec = devconfigHistoriesRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.devconfigHistoriesInfo")});
			throw exp;
		}
		devconfigHistoriesRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("config_id".equals(str)) mf.config_id = true;
				if ("config_file".equals(str)) mf.config_file = true;
				if ("gw_upload_time".equals(str)) mf.gw_upload_time = true;
				if ("format_version".equals(str)) mf.format_version = true;
				if ("config_version".equals(str)) mf.config_version = true;
				if ("file_notification_key".equals(str)) mf.file_notification_key = true;
				if ("regist_flg".equals(str)) mf.regist_flg = true;
				if ("result_send_id".equals(str)) mf.result_send_id = true;
				if ("version".equals(str)) mf.version = true;
				if ("insert_time".equals(str)) mf.insert_time = true;
				if ("update_time".equals(str)) mf.update_time = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			model_id = b;
			serial_no = b;
			config_id = b;
			config_file = b;
			gw_upload_time = b;
			format_version = b;
			config_version = b;
			file_notification_key = b;
			regist_flg = b;
			result_send_id = b;
			version = b;
			insert_time = b;
			update_time = b;
		}
		public boolean id = true;
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean config_id = true;
		public boolean config_file = true;
		public boolean gw_upload_time = true;
		public boolean format_version = true;
		public boolean config_version = true;
		public boolean file_notification_key = true;
		public boolean regist_flg = true;
		public boolean result_send_id = true;
		public boolean version = true;
		public boolean insert_time = true;
		public boolean update_time = true;
	}
}


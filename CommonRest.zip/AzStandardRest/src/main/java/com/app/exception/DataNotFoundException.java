package com.app.exception;

import org.springframework.context.MessageSourceResolvable;

/**
 * データが見つからない例外クラス
 * @author（TOSCO）ウェイ
 */
public class DataNotFoundException extends Exception {

	private static final long serialVersionUID = -2086490690853265539L;

	private MessageSourceResolvable[] args;

	public DataNotFoundException(String errcode) {
		super(errcode);
	}

	public MessageSourceResolvable[] getArgs() {
		return args;
	}

	public void setArgs(MessageSourceResolvable[] args) {
		this.args = args;
	}

}

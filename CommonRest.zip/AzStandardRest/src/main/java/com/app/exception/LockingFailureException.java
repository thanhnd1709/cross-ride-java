package com.app.exception;

import org.springframework.context.MessageSourceResolvable;

/**
 * ロックエラークラス
 * @author（TOSCO）ウェイ
 */
public class LockingFailureException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private MessageSourceResolvable[] args;

	public LockingFailureException(String errcode) {
		super(errcode);
	}

	public MessageSourceResolvable[] getArgs() {
		return args;
	}

	public void setArgs(MessageSourceResolvable[] args) {
		this.args = args;
	}

}

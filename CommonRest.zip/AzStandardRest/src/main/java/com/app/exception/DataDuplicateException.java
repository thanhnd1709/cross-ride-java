package com.app.exception;

import org.springframework.context.MessageSourceResolvable;

/**
 * 重複例外クラス
 * @author（TOSCO）ウェイ
 */
public class DataDuplicateException extends Exception {

	private static final long serialVersionUID = -8257835490808062290L;

	private MessageSourceResolvable[] args;

	public DataDuplicateException(String errcode){
		super(errcode);
	}

	public MessageSourceResolvable[] getArgs() {
		return args;
	}

	public void setArgs(MessageSourceResolvable[] args) {
		this.args = args;
	}



}

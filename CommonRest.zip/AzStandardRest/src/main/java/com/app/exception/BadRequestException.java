package com.app.exception;

import java.util.List;

import com.app.model.SubResponseModel;

/**
 * リクエスト例外クラス
 * @author（TOSCO）ウェイ
 */
public class BadRequestException extends Exception {

	private static final long serialVersionUID = 1L;

	private List<SubResponseModel> args;

	public BadRequestException(String errcode){
		super(errcode);
	}

	/**
	 * @return args
	 */
	public List<SubResponseModel> getArgs() {
		return args;
	}

	/**
	 * @param args セットする args
	 */
	public void setArgs(List<SubResponseModel> args) {
		this.args = args;
	}
}

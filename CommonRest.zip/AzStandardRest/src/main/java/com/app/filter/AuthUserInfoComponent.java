package com.app.filter;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

/**
 * 認証情報を格納するコンポーネント
 * @author 1168
 *
 */
@Component
@RequestScope //インスタンスの生存期間はリクエストの間
public class AuthUserInfoComponent {

	/**
	 * ※PrincipalIDはユーザIDではないので注意
	 */
	private String principalID;
	/**
	 * ユーザID
	 * ※PrincipalIDはユーザIDではないので注意
	 */
	private String principalName;

	/**
	 * ※PrincipalIDはユーザIDではないので注意
	 * @return
	 */
	public String getPrincipalID() {
		return principalID;
	}
	/**
	 * ※PrincipalIDはユーザIDではないので注意
	 * @param principalID
	 */
	public void setPrincipalID(String principalID) {
		this.principalID = principalID;
	}
	/**
	 * ユーザIDを返す。
	 * ※PrincipalIDはユーザIDではないので注意
	 * @return ユーザID
	 */
	public String getPrincipalName() {
		return principalName;
	}
	/**
	 * ユーザIDを設定する。
	 * ※PrincipalIDはユーザIDではないので注意
	 * @param principalName ユーザID
	 */
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}



}

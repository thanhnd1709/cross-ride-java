package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベントリストモデル
 */
@Data
public class EventListModel {

	@ApiModelProperty(value = "イベント発生時刻")
	private String eventTime;

	@ApiModelProperty(value = "イベントID")
	private String eventId;

	@ApiModelProperty(value = "イベント状態")
	private String eventStatus;

	@ApiModelProperty(value = "発生復帰区分")
	private String incidentClass;

	@ApiModelProperty(value = "イベントレベル")
	private String eventLevel;

	@ApiModelProperty(value ="検出時情報")
	private String detectionInfo;


	public EventListModel(String eventTime, String eventId, String eventStatus, String incidentClass, String eventLevel, String detectionInfo){
		this.eventTime = eventTime;
		this.eventId = eventId;
		this.eventStatus = eventStatus;
		this.incidentClass = incidentClass;
		this.eventLevel = eventLevel;
		this.detectionInfo = detectionInfo;
	}

}

package com.app.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 展開用ファイル登録モデル
 *
 * @author 1572
 */
@Data
public class PostExpansionFileQueryModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ファイル名(ファイルパス情報含む)")
	private String file_name;

	@ApiModelProperty(value = "圧縮有無フラグ",required = true)
	private String zip_flg;

	@ApiModelProperty(value = "メッセージ区分 ※\"Data Send1\" or \"Data Send2\" or \"Data Send3\"",required = true)
	private String message_class;

	@ApiModelProperty(value = "ファイルデータ ※base64フラグ=false かつ データにダブルクォーテーションが含まれる場合は、エスケープしセットする事",required = true)
	private String file_data;

	@ApiModelProperty(value = "base64 フラグ ※true:INパラメータのファイルデータに base64でエンコードした値をセットしている")
	private String base64_flg;

	/* API内で値を設定するため、非公開とする。 */
	@ApiModelProperty(value = "ユーザID", hidden = true)
	private String user_id;


}

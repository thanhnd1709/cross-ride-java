package com.app.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ファイル登録APIセンサー権限チェック返却モデル
 *
 * @author 1572
 */
@Data
public class PostFileAuthChkModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "センサーID")
	private String sensor_id;
}

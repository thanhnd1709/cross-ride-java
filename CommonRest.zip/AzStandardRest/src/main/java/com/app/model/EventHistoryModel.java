package com.app.model;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベント・アラーム履歴検索モデル
 * @author（TOSCO）小川
 */
@Data
public class EventHistoryModel {

	@ApiModelProperty(value = "検出区分（1：GW異常検知(未受信) / 2：GW異常検知(受信SEQ抜け) / 3：デバイス異常検知 / 4：エッジ側イベント検出 / 5：クラウド側イベント検出   "
			+ "※複数が対象となる場合、区分値リストを配列で指定する（例：1と4が検索対象の場合、1,4 とセット））" , required =true)
	private String[] get_class;

	@ApiModelProperty(value = "発生復帰区分（1：発生(デフォルト値) / 2：復帰 / 3：全て")
	private String incident_class;

	@ApiModelProperty(value = "イベント時刻(From) ※yyyy-MM-dd HH:mm:ss.SSSSSSS" , required =true)
	private String event_time_from;

	@ApiModelProperty(value = "イベント時刻(To) ※yyyy-MM-dd HH:mm:ss.SSSSSSS 未指定時はシステム時刻とする")
	private String event_time_to;

	@ApiModelProperty(value = "デバイスグループID ※デバイスグループID 指定時、 [配列]デバイスリスト、 [配列]イベントリスト は指定不可")
	private String device_group_id;

	@ApiModelProperty(value = "[配列]デバイスリスト（機種ID、シリアルNo）")
	private List<DeviceListModel> device_list;

	@ApiModelProperty(value = "[配列]イベントリスト（機種ID、 シリアルNo、イベントID）")
	private List<EventListModel2> event_list;

	@ApiModelProperty(value = "イベント状態  ※複数が対象となる場合、カンマ区切りで指定する")
	private String[] event_status;

	@ApiModelProperty(value = "イベントレベル  ※複数が対象となる場合、カンマ区切りで指定する")
	private String[] event_level;

	@ApiModelProperty(value = "検出情報  ※複数が対象となる場合、カンマ区切りで指定する")
	private String[] detection_info;

	@ApiModelProperty(value = "親子展開フラグ（true：INパラメータがデバイスグループID指定の時、デバイスグループを親子関係で展開し、子デバイスグループも対象とする。"
			+ "INパラメータがデバイスリスト指定の時、 デバイスを親子関係で展開し、子デバイスグループも対象とする。"
			+ "INパラメータがイベントリスト指定の時、 親子展開はしない / false：親子展開しない）")
	private Boolean parent_flg;

	@ApiModelProperty(value = "最大件数")
	private Integer max_number;

	@ApiModelProperty(value = "ソート順(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;
}

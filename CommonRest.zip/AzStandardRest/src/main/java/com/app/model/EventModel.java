package com.app.model;
import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class EventModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ID")
	private Integer id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "機種ID" , required =true)
	private String model_id;

	@NotNull(message = "{" +  Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "シリアルNo" , required =true)
	private String serial_no;

	@NotNull(message = "{" +  Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "イベントID" , required =true)
	private String event_id;

	@Size(max = 50, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "イベント種別")
	private String event_type;

	@Size(max = 50, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "イベントレベル")
	private String event_level;

	@Size(max = 50, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "センサーID")
	private String sensor_id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 100, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール1)" , required =true)
	private String name_locale1;

	@Size(max = 100, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール2)")
	private String name_locale2;

	@Size(max = 100, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール3)")
	private String name_locale3;

	@Size(max = 2000, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール1)")
	private String description_locale1;

	@Size(max = 2000, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール2)")
	private String description_locale2;

	@Size(max = 2000, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール3)")
	private String description_locale3;

	@Size(max = 50, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "アラーム検出アプリ名")
	private String chk_app_name;

	@Size(max = 500, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "アラーム検出パラメータ")
	private String chk_app_parameter;

	@Size(max = 50, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "チェックタイミング")
	private String check_timing;

	@Size(max = 2000, message = "{" +  Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "備考")
	private String note;

	@ApiModelProperty(value = "バージョン")
	private Long version;

	@ApiModelProperty(value = "登録者")
	private String inserted;

	@ApiModelProperty(value = "登録時刻")
	private String insert_time;

	@ApiModelProperty(value = "更新者")
	private String updated;

	@ApiModelProperty(value = "更新時刻")
	private String update_time;

}

package com.app.model;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

import javax.validation.constraints.NotNull;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 指定デバイスグループ下デバイス取得クエリモデル
 */
@Data
public class DeviceGroupDeviceQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String ENCODING = "UTF-8";

	@ApiModelProperty(value = "デバイスグループID",required = true)
	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	private String[] device_group_id;

	@ApiModelProperty(value = "階層数(1～40を指定。未指定の場合、40とみなす。)")
	private String level;

	/* API内で値を設定するため、非公開とする。 */
	@ApiModelProperty(value = "ユーザID",hidden = true)
	private String user_id;

	@ApiModelProperty(value = "任意並び順条件")
	private String sort;

	@ApiModelProperty(value = "取得フィールド")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (device_group_id != null)
				for (String s : device_group_id)
					sj.add("device_group_id=" + URLEncoder.encode(s, ENCODING));

			if (level != null) sj.add("level=" + URLEncoder.encode(level, ENCODING));

			if (sort != null) sj.add("sort=" + URLEncoder.encode(sort, ENCODING));

			if (fields != null) sj.add("fields=" + URLEncoder.encode(fields, ENCODING));

			if (page != null) sj.add("page=" + URLEncoder.encode(page, ENCODING));

			if (limit != null) sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}

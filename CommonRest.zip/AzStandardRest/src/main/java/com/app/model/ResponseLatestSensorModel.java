package com.app.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class ResponseLatestSensorModel {

	@ApiModelProperty(value = "センサーID")
	private String sensorId;

	@ApiModelProperty(value = "計測データリスト")
	private List<ResponseMeasureDataModel> dataList;

	public ResponseLatestSensorModel(String sensorId, List<ResponseMeasureDataModel> dataList){
		this.sensorId = sensorId;
		this.dataList = dataList;
	}
}
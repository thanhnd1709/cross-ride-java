package com.app.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 画像・音ファイル等登録モデル
 *
 * @author 1572
 */
@Data
public class PostMeasureFileQueryModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ファイル名(ファイルパス情報含む)")
	private String file_name;

	@ApiModelProperty(value = "圧縮有無フラグ",required = true)
	private String zip_flg;

	@ApiModelProperty(value = "機種ID ※デバイス(機種ID または S/N)どちらかは必須")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo ※デバイス(機種ID または S/N)どちらかは必須")
	private String serial_no;

	@ApiModelProperty(value = "センサーID",required = true)
	private String sensor_id;

	@ApiModelProperty(value = "計測時刻 ※yyyyMMddHHmmssFFFFFFF",required = true)
	private String measure_time;

	@ApiModelProperty(value = "ファイルデータ ※base64 フラグ = false の場合はエスケープした値、base64 フラグ = true の場合、エスケープ無しの値をセット",required = true)
	private String file_data;

	@ApiModelProperty(value = "base64 フラグ")
	private String base64_flg;

	@ApiModelProperty(value = "予備1")
	private String reserve1;

	@ApiModelProperty(value = "予備2")
	private String reserve2;

	@ApiModelProperty(value = "予備3")
	private String reserve3;

	@ApiModelProperty(value = "予備4")
	private String reserve4;

	@ApiModelProperty(value = "予備5")
	private String reserve5;

	/* API内で値を設定するため、非公開とする。 */
	@ApiModelProperty(value = "ユーザID", hidden = true)
	private String user_id;
}

package com.app.model;
import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザ・センサー権限情報取得モデル
 * @author 9571
 *
 */
@Data
public class UserSensorAuthorityModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "センサーID")
	private String sensor_id;

	@ApiModelProperty(value = "センサー種別")
	private String sensor_type;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String sensor_name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String sensor_name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String sensor_name_locale3;

	@ApiModelProperty(value = "単位(ロケール1)")
	private String unit_locale1;

	@ApiModelProperty(value = "単位(ロケール2)")
	private String unit_locale2;

	@ApiModelProperty(value = "単位(ロケール3)")
	private String unit_locale3;

	@ApiModelProperty(value = "変換式(ロケール1)")
	private String transform_locale1;

	@ApiModelProperty(value = "変換式(ロケール2)")
	private String transform_locale2;

	@ApiModelProperty(value = "変換式(ロケール3)")
	private String transform_locale3;

	@ApiModelProperty(value = "小数点桁数(ロケール1)")
	private Integer decimal_num_locale1;

	@ApiModelProperty(value = "小数点桁数(ロケール2)")
	private Integer decimal_num_locale2;

	@ApiModelProperty(value = "小数点桁数(ロケール3)")
	private Integer decimal_num_locale3;

	@ApiModelProperty(value = "上限値(ロケール1)")
	private Double max_value_locale1;

	@ApiModelProperty(value = "上限値(ロケール2)")
	private Double max_value_locale2;

	@ApiModelProperty(value = "上限値(ロケール3)")
	private Double max_value_locale3;

	@ApiModelProperty(value = "下限値(ロケール1)")
	private Double min_value_locale1;

	@ApiModelProperty(value = "下限値(ロケール2)")
	private Double min_value_locale2;

	@ApiModelProperty(value = "下限値(ロケール3)")
	private Double min_value_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String sensor_description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String sensor_description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String sensor_description_locale3;

	@ApiModelProperty(value = "計測タイプ（1：データ / 2：ファイル）")
	private String measure_type;

	@ApiModelProperty(value = "データ型（int：整数(4バイト) / long：整数(8バイト) / real：実数(有効桁数7桁) / float：実数(有効桁数15桁) / bit：ビット列 / stat：状態数値 / "
			+ "string:テキスト / binary：バイナリデータ / json：JSON形式 / other：その他(数値配列など)）")
	private String data_type;

	@ApiModelProperty(value = "固定長サイズ")
	private Integer fixed_length;

	@ApiModelProperty(value = "時系列データ作成フラグ（true：時系列データ(Table storage)を作成する / false：時系列データ(Table storage)を作成しない）")
	private Boolean time_data_create_flg;

	@ApiModelProperty(value = "短期保管時間")
	private Integer short_term_minutes;

	@ApiModelProperty(value = "備考")
	private String sensor_note;

	@ApiModelProperty(value = "デバイスグルップID")
	private String device_group_id;

	@ApiModelProperty(value = "デバイスグループ種別")
	private String device_group_type;

	@ApiModelProperty(value = "デバイスグループサブ種別")
	private String device_group_subtype;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String device_group_name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String device_group_name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String device_group_name_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String device_group_description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String device_group_description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String device_group_description_locale3;

	@ApiModelProperty(value = "親デバイスグループID")
	private String parent_device_group_id;

	@ApiModelProperty(value = "設置場所")
	private String setup_place;

	@ApiModelProperty(value = "設置状態")
	private String setup_status;

	@ApiModelProperty(value = "緯度")
	private BigDecimal latitude;

	@ApiModelProperty(value = "経度")
	private BigDecimal longitude;

	@ApiModelProperty(value = "備考")
	private String device_group_note;

	@ApiModelProperty(value = "ロールID")
	private String role_id;

	@ApiModelProperty(value = "ロールグルップID")
	private String root_group_id;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String role_name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String role_name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String role_name_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String role_description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String role_description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String role_description_locale3;

	@ApiModelProperty(value = "備考")
	private String role_note;

	@ApiModelProperty(value = "デバイスグループ階層")
	private Integer hierarchy;
}

package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイスグループアラーム状態モデル
 */
@Data
public class DeviceGroupAlarmStatusModel {

	@ApiModelProperty(value = "検出区分（1：GW異常検知(未受信) / 2：GW異常検知(受信SEQ抜け) / 3：デバイス異常検知 / 4：エッジ側イベント検出 / 5：クラウド側イベント検出   "
			+ "※複数が対象となる場合、区分値リストを配列で指定する（例：1と4が検索対象の場合、1,4 とセット））" , required =true)
	private String[] get_class;

	@ApiModelProperty(value = "発生復帰区分（1：発生(デフォルト値) / 2：復帰 / 3：全て")
	private String incident_class;

	@ApiModelProperty(value = "取得情報区分（1：直下最大イベントレベル / 2：配下最大イベントレベル）" , required =true)
	private String get_info_class;

	@ApiModelProperty(value = "比較区分 (1:文字列としてレベル値を大小比較(デフォルト値)  2:数値に変換し比較)")
	private String compare_class;

	@ApiModelProperty(value = "[配列]デバイスグループID" , required =true)
	private String [] device_group_id;

	@ApiModelProperty(value = "ソート順(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

}

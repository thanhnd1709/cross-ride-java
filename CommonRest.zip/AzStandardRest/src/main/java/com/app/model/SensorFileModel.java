package com.app.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーファイルモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class SensorFileModel {

	@ApiModelProperty(value = "検索区分（1：対象期間内の全データ取得 / 2：センサ毎に、対象期間内の最初のデータを１件取得）", required = true)
	private String get_class;

	@ApiModelProperty(value = "対象期間(From) ※yyyy-MM-dd HH:mm:ss.SSSSSSS", required = true)
	private String measure_time_from;

	@ApiModelProperty(value = "対象期間(To) ※yyyy-MM-dd HH:mm:ss.SSSSSSS 未指定時はシステム時刻とする")
	private String measure_time_to;

	@ApiModelProperty(value = "センサリスト", required = true)
	private List<SensorModel1> sensor_list;

	@ApiModelProperty(value = "ID")
	private String[] id;

	@ApiModelProperty(value = "UpLoad時刻")
	private String[] upload_time;

	@ApiModelProperty(value = "圧縮有無")
	private String[] zip_flg;

	@ApiModelProperty(value = "ファイル名（ファイルパス/ファイル名）")
	private String[] file_name;

	@ApiModelProperty(value = "MD5")
	private String[] hash;

	@ApiModelProperty(value = "送信元デバイスID")
	private String[] sender_device_id;

	@ApiModelProperty(value = "送信通知時刻")
	private String[] notice_time;

	@ApiModelProperty(value = "予備1")
	private String[] reserve1;

	@ApiModelProperty(value = "予備2")
	private String[] reserve2;

	@ApiModelProperty(value = "予備3")
	private String[] reserve3;

	@ApiModelProperty(value = "予備4")
	private String[] reserve4;

	@ApiModelProperty(value = "予備5")
	private String[] reserve5;

	@ApiModelProperty(value = "その他メタデータ")
	private String[] other_metadata;

	@ApiModelProperty(value = "アップロードユーザID")
	private String[] upload_user_id;

	@ApiModelProperty(value = "任意並び順条件(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;
}

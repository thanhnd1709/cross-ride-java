package com.app.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーデータモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class ResponseLatestSensorDataModel {

	@ApiModelProperty(value = "機種ID")
	private String modelId;
	@ApiModelProperty(value = "シリアルNo")
	private String serialNo;
	@ApiModelProperty(value = "センサーデータリスト")
	private List<ResponseLatestSensorModel> timeList;

	public ResponseLatestSensorDataModel(String modelId, String serialNo, List<ResponseLatestSensorModel> timeList){
		this.modelId = modelId;
		this.serialNo = serialNo;
		this.timeList = timeList;
	}
}
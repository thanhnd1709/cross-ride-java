package com.app.model;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * GWへのコマンド実行依頼レスポンスモデル
 * @author 810
 *
 */
@Data
public class ResponseOpeInstructModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "送信ID")
	private Integer send_id;

	@ApiModelProperty(value = "HTTP状態コード", hidden = true)
	@JsonIgnore
	private String result_code;

	@ApiModelProperty(value = "結果詳細コード")
	private String result_detail_code;

	@ApiModelProperty(value = "結果メッセージ")
	private String result_message;

	@ApiModelProperty(value = "取得データ")
	private Object data;
}

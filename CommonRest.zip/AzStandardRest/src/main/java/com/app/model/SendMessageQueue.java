package com.app.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * メッセージ送信モデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
@JsonPropertyOrder({ "header", "body" })
public class SendMessageQueue {

	@ApiModelProperty(value = "ヘッダー")
	private UserModel header;

	@ApiModelProperty(value = "ボディー")
	private List<StdEventModel> body;
}

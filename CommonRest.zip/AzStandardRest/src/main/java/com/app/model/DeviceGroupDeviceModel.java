package com.app.model;
import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 指定デバイスグループ下デバイスモデル
 */
@Data
public class DeviceGroupDeviceModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "デバイスグループ階層"
			+ "(指定デバイスグループID ～ 関連付けされたデバイスグループID までを タブ区切りで連結)")
	private String device_group_list;

	@ApiModelProperty(value = "階層数")
	private String level;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;


}
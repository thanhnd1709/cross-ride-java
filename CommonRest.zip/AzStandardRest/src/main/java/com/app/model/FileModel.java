package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ファイルモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class FileModel {

	@ApiModelProperty(value = "ファイル種別（1:画像・音ファイル等 / 9:その他ファイル）", required = true)
	private String file_type;

	@ApiModelProperty(value = "コンテナ名 ※ファイル種別が9の時は、コンテナ名も必須である。 (9以外の時は、設定されていても無視する)")
	private String container;

	@ApiModelProperty(value = "ファイル名(ファイルパス情報含む)", required = true)
	private String file_name;
}

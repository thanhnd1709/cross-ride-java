package com.app.model;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DevconfigHistoriesQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String ENCODING = "UTF-8";

	@ApiModelProperty(value = "ID")
	private String[] id;

	@ApiModelProperty(value = "機種ID")
	private String[] model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String[] serial_no;

	@ApiModelProperty(value = "コンフィグID")
	private String[] config_id;

	@ApiModelProperty(value = "コンフィグファイル名")
	private String[] config_file;

	@ApiModelProperty(value = "GWアップロード時刻 (yyyy-MM-dd'T'HH:mm:ss.fffffff'Z')")
	private String[] gw_upload_time;

	@ApiModelProperty(value = "フォーマットバージョン")
	private String[] format_version;

	@ApiModelProperty(value = "コンフィグバージョン")
	private String[] config_version;

	@ApiModelProperty(value = "設定ファイル通知キー")
	private String[] file_notification_key;

	@ApiModelProperty(value = "マスタ登録結果")
	private String[] regist_flg;

	@ApiModelProperty(value = "結果通知送信ID")
	private String[] result_send_id;

	@ApiModelProperty(value = "バージョン")
	private String[] version;

	@ApiModelProperty(value = "登録時刻")
	private String[] insert_time;

	@ApiModelProperty(value = "更新時刻")
	private String[] update_time;

	@ApiModelProperty(value = "任意並び順条件(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	@ApiModelProperty(value = "ユーザID",hidden = true)
	private String user_id;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (id != null) for (String s : id) sj.add("id=" + URLEncoder.encode(s, ENCODING));

			if (model_id != null) for (String s : model_id) sj.add("model_id=" + URLEncoder.encode(s, ENCODING));

			if (serial_no != null) for (String s : serial_no) sj.add("serial_no=" + URLEncoder.encode(s, ENCODING));

			if (config_id != null) for (String s : config_id) sj.add("config_id=" + URLEncoder.encode(s, ENCODING));

			if (config_file != null) for (String s : config_file) sj.add("config_file=" + URLEncoder.encode(s, ENCODING));

			if (gw_upload_time != null) for (String s : gw_upload_time) sj.add("gw_upload_time=" + URLEncoder.encode(s, ENCODING));

			if (format_version != null) for (String s : format_version) sj.add("format_version=" + URLEncoder.encode(s, ENCODING));

			if (config_version != null) for (String s : config_version) sj.add("config_version=" + URLEncoder.encode(s, ENCODING));

			if (file_notification_key != null) for (String s : file_notification_key) sj.add("file_notification_key=" + URLEncoder.encode(s, ENCODING));

			if (regist_flg != null) for (String s : regist_flg) sj.add("regist_flg=" + URLEncoder.encode(s, ENCODING));

			if (result_send_id != null) for (String s : result_send_id) sj.add("result_send_id=" + URLEncoder.encode(s, ENCODING));

			if (version != null) for (String s : version) sj.add("version=" + URLEncoder.encode(s, ENCODING));

			if (insert_time != null) for (String s : insert_time) sj.add("insert_time=" + URLEncoder.encode(s, ENCODING));

			if (update_time != null) for (String s : update_time) sj.add("update_time=" + URLEncoder.encode(s, ENCODING));

			if (sort != null) sj.add("sort=" + URLEncoder.encode(sort, ENCODING));

			if (fields != null) sj.add("fields=" + URLEncoder.encode(fields, ENCODING));

			if (page != null) sj.add("page=" + URLEncoder.encode(page, ENCODING));

			if (limit != null) sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

			if (user_id != null) sj.add("user_id=" + URLEncoder.encode(user_id, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}

package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイスグループIDリストモデル
 */
@Data
public class DeviceGroupIdListModel {

	@ApiModelProperty(value = "デバイスグループID")
	private String device_group_id;

}

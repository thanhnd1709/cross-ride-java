package com.app.model;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベントリストモデル
 */
@Data
public class EventListModel1 {

	@ApiModelProperty(value = "イベント発生時刻 ※UTC時刻をセット(yyyyMMddHHmmssFFFFFFF)", required = true)
	private String eventTime;

	@ApiModelProperty(value = "イベントID", required = true)
	private String eventId;

	@ApiModelProperty(value = "イベント状態")
	@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
	private String eventStatus;

	@ApiModelProperty(value = "発生復帰区分（1：発生 / 2：復帰）", required = true)
	private String incidentClass;

	@ApiModelProperty(value = "イベントレベル")
	@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
	private String eventLevel;

	@ApiModelProperty(value ="検出時情報")
	@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
	private String detectionInfo;
}

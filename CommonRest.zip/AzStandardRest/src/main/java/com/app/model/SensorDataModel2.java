package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーデータ削除モデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class SensorDataModel2 {

	@ApiModelProperty(value = "計測時刻(From) ※yyyy-MM-dd HH:mm:ss.SSSSSSS", required = true)
	private String measure_time_from;

	@ApiModelProperty(value = "計測時刻(To) ※yyyy-MM-dd HH:mm:ss.SSSSSSS", required = true)
	private String measure_time_to;

	@ApiModelProperty(value = "機種ID ※デバイス(機種ID または S/N)どちらかは必須")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo ※デバイス(機種ID または S/N)どちらかは必須")
	private String serial_no;

	@ApiModelProperty(value = "センサーID", required = true)
	private String sensor_id;
}

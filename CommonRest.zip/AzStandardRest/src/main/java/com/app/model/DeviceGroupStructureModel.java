package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイスグループ階層情報取得モデル
 */
@Data
public class DeviceGroupStructureModel {

	@ApiModelProperty(value = "検索区分（1：指定されたデバイスグループID下の全ての階層のデバイスグループIDを取得 (指定されたデバイスグループIDを含む)"
			+ "					 / 2：1.で取得したデバイスグループIDの内、末端のデバイスグループIDのみ取得 / 3：1.で取得したデバイスグループIDの内、デバイスに直接関連付けられたデバイスグループIDのみ取得）" , required =true)
	private String get_class;

	@ApiModelProperty(value = "階層数（1～40） ※未指定時は40")
	private String level;

	@ApiModelProperty(value = "デバイスグループID" , required =true)
	private String device_group_id;

	@ApiModelProperty(value = "任意並び順条件(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

}

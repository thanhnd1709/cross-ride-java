package com.app.model;
import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DeviceModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ID")
	private Integer id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "機種ID" , required =true)
	private String model_id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "シリアルNo" , required =true)
	private String serial_no;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "デバイス種別" , required =true)
	private String device_type;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "IoTデバイスフラグ（true：Device Twinにも登録するデバイス / false）" , required =true)
	private Boolean iot_device_flg;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "通信デバイスフラグ（true：IoT Hubと通信するデバイス(GW等) / false）" , required =true)
	private Boolean communication_flg;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール１)" , required =true)
	private String name_locale1;

	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール２)")
	private String name_locale2;

	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール３)")
	private String name_locale3;

	@Size(max = 2000, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール１)")
	private String description_locale1;

	@Size(max = 2000, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール２)")
	private String description_locale2;

	@Size(max = 2000, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール３)")
	private String description_locale3;

	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "メーカーコード")
	private String maker_code;

	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "親機種ID")
	private String parent_model_id;

	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "親シリアルNo")
	private String parent_serial_no;

	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "設置場所")
	private String setup_place;

	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "設置状態")
	private String setup_status;

	@Size(max = 10, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "タイムゾーン")
	private String time_zone;

	@Digits(integer = 11, fraction = 9, message = "{" + Consts.MESSAGE_E000025 + "}")
	@ApiModelProperty(value = "緯度")
	private BigDecimal latitude;

	@Digits(integer = 12, fraction = 9, message = "{" + Consts.MESSAGE_E000025 + "}")
	@ApiModelProperty(value = "経度")
	private BigDecimal longitude;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Pattern(regexp = "^[1-3]?$", message = "{" + Consts.MESSAGE_E000045 + "}")
	@ApiModelProperty(value = "デバイスモード（1：運用中 / 2：メンテナンス中(受信禁止) / 3：撤去）" , required =true)
	private String device_mode;

	@ApiModelProperty(value = "未受信許容秒数")
	private Integer unreceive_seconds;

	@Size(max = 2000, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "備考")
	private String note;

	@ApiModelProperty(value = "バージョン")
	private Long version;

	@ApiModelProperty(value = "登録者")
	private String inserted;

	@ApiModelProperty(value = "登録時刻")
	private String insert_time;

	@ApiModelProperty(value = "更新者")
	private String updated;

	@ApiModelProperty(value = "更新時刻")
	private String update_time;

}

package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 指定デバイスグループ下デバイス取得モデル
 */
@Data
public class ResponseDeviceGroupDeviceModel {

	@ApiModelProperty(value = "デバイスグループ階層（指定デバイスグループID ～ 関連付けされたデバイスグループID までを タブ区切りで連結）")
	private String device_group_structure;

	@ApiModelProperty(value = "階層数")
	private Integer level;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

}
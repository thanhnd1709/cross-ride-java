package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイスリストモデル
 * (機種ID、シリアルNo)
 */
@Data
public class DeviceListModel {

	@ApiModelProperty(value = "機種ID " )
	private String model_id;

	@ApiModelProperty(value = "シリアルNo ")
	private String serial_no;

}

package com.app.model;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
/**
 * イベント・アラーム ステータス管理クエリモデル
 * @author 1572
 */
public class StatusManagementQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String ENCODING = "UTF-8";
	
	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "対応状況",required = true)
	private String cope_status;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "バージョン",required = true)
	private Long version;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (cope_status != null) sj.add("cope_status=" + URLEncoder.encode(cope_status, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}

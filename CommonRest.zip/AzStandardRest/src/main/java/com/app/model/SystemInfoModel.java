package com.app.model;

import lombok.Data;

/**
 * システム情報モデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class SystemInfoModel {

    // 計画データ削除日数
	//private Long DataMeasureDelete;
    // 時間別移行待機時間
	private Long DataHourMigrateWaite;
    // 時間別削除日数
	//private Long DataHourDelete;
    // 日別移行待機日数
	//private Long DataDailyMigrateWaite;
    // 日別削除日数
	//private Long DataDailyDelete;
    // 日別Blob移行待機日数
	private Long DataBlobMigrateWaite;
    // 計画データ削除日数２
	//private Long DataMeasureDelete2;
    // 日別Blob移行待機日数２
	private Long DataBlobMigrateWaite2;
    // 時系列API範囲検索用パラメータ
	//private String TimeSeriesAPIRangeSearch;
    // 時系列API１件検索用パラメータ
	//private String TimeSeriesAPI1Search;

}

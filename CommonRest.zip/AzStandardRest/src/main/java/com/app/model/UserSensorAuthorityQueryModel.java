package com.app.model;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザ・センサー権限情報取得クエリモデル
 * @author 9571
 *
 */
@Data
public class UserSensorAuthorityQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String ENCODING = "UTF-8";

	@ApiModelProperty(value = "機種ID")
	private String[] model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String[] serial_no;

	@ApiModelProperty(value = "センサーID")
	private String[] sensor_id;

	@ApiModelProperty(value = "センサー種別")
	private String[] sensor_type;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String[] sensor_name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String[] sensor_name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String[] sensor_name_locale3;

	@ApiModelProperty(value = "単位(ロケール1)")
	private String[] unit_locale1;

	@ApiModelProperty(value = "単位(ロケール2)")
	private String[] unit_locale2;

	@ApiModelProperty(value = "単位(ロケール3)")
	private String[] unit_locale3;

	@ApiModelProperty(value = "変換式(ロケール1)")
	private String[] transform_locale1;

	@ApiModelProperty(value = "変換式(ロケール2)")
	private String[] transform_locale2;

	@ApiModelProperty(value = "変換式(ロケール3)")
	private String[] transform_locale3;

	@ApiModelProperty(value = "小数点桁数(ロケール1)")
	private String[] decimal_num_locale1;

	@ApiModelProperty(value = "小数点桁数(ロケール2)")
	private String[] decimal_num_locale2;

	@ApiModelProperty(value = "小数点桁数(ロケール3)")
	private String[] decimal_num_locale3;

	@ApiModelProperty(value = "上限値(ロケール1)")
	private String[] max_value_locale1;

	@ApiModelProperty(value = "上限値(ロケール2)")
	private String[] max_value_locale2;

	@ApiModelProperty(value = "上限値(ロケール3)")
	private String[] max_value_locale3;

	@ApiModelProperty(value = "下限値(ロケール1)")
	private String[] min_value_locale1;

	@ApiModelProperty(value = "下限値(ロケール2)")
	private String[] min_value_locale2;

	@ApiModelProperty(value = "下限値(ロケール3)")
	private String[] min_value_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String[] sensor_description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String[] sensor_description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String[] sensor_description_locale3;

	@ApiModelProperty(value = "計測タイプ")
	private String[] measure_type;

	@ApiModelProperty(value = "データ型")
	private String[] data_type;

	@ApiModelProperty(value = "固定長サイズ")
	private String[] fixed_length;

	@ApiModelProperty(value = "時系列データ作成フラグ")
	private String[] time_data_create_flg;

	@ApiModelProperty(value = "短期保管時間")
	private String[] short_term_minutes;

	@ApiModelProperty(value = "備考")
	private String[] sensor_note;

	@ApiModelProperty(value = "デバイスグルップID")
	private String[] device_group_id;

	@ApiModelProperty(value = "デバイスグループ種別")
	private String[] device_group_type;

	@ApiModelProperty(value = "デバイスグループサブ種別")
	private String[] device_group_subtype;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String[] device_group_name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String[] device_group_name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String[] device_group_name_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String[] device_group_description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String[] device_group_description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String[] device_group_description_locale3;

	@ApiModelProperty(value = "親デバイスグループID")
	private String[] parent_device_group_id;

	@ApiModelProperty(value = "設置場所")
	private String[] setup_place;

	@ApiModelProperty(value = "設置状態")
	private String[] setup_status;

	@ApiModelProperty(value = "緯度")
	private String[] latitude;

	@ApiModelProperty(value = "経度")
	private String[] longitude;

	@ApiModelProperty(value = "備考")
	private String[] device_group_note;

	@ApiModelProperty(value = "ロールID")
	private String[] role_id;

	@ApiModelProperty(value = "ロールグルップID")
	private String[] root_group_id;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String[] role_name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String[] role_name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String[] role_name_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String[] role_description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String[] role_description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String[] role_description_locale3;

	@ApiModelProperty(value = "備考")
	private String[] role_note;

	@ApiModelProperty(value = "デバイスグループ階層")
	private String[] hierarchy;

	/* API内で値を設定するため、非公開とする。 */
	@ApiModelProperty(value = "ユーザID", hidden = true)
	private String user_id;

	@ApiModelProperty(value = "URL ※メソッド入力時は必須")
	private String url;

	@ApiModelProperty(value = "メソッド ※URL入力時は必須")
	private String method;

	@ApiModelProperty(value = "任意並び順条件")
	private String sort;

	@ApiModelProperty(value = "取得フィールド")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (device_group_id != null) for (String s : device_group_id) sj.add("device_group_id=" + URLEncoder.encode(s, ENCODING));

			if (model_id != null) for (String s : model_id) sj.add("model_id=" + URLEncoder.encode(s, ENCODING));

			if (serial_no != null) for (String s : serial_no) sj.add("serial_no=" + URLEncoder.encode(s, ENCODING));

			if (sensor_id != null) for (String s : sensor_id) sj.add("sensor_id=" + URLEncoder.encode(s, ENCODING));

			if (sensor_type != null) for (String s : sensor_type) sj.add("sensor_type=" + URLEncoder.encode(s, ENCODING));

			if (sensor_name_locale1 != null) for (String s : sensor_name_locale1) sj.add("sensor_name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (sensor_name_locale2 != null) for (String s : sensor_name_locale2) sj.add("sensor_name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (sensor_name_locale3 != null) for (String s : sensor_name_locale3) sj.add("sensor_name_locale3=" + URLEncoder.encode(s, ENCODING));

			if (unit_locale1 != null) for (String s : unit_locale1) sj.add("unit_locale1=" + URLEncoder.encode(s, ENCODING));

			if (unit_locale2 != null) for (String s : unit_locale2) sj.add("unit_locale2=" + URLEncoder.encode(s, ENCODING));

			if (unit_locale3 != null) for (String s : unit_locale3) sj.add("unit_locale3=" + URLEncoder.encode(s, ENCODING));

			if (transform_locale1 != null) for (String s : transform_locale1) sj.add("transform_locale1=" + URLEncoder.encode(s, ENCODING));

			if (transform_locale2 != null) for (String s : transform_locale2) sj.add("transform_locale2=" + URLEncoder.encode(s, ENCODING));

			if (transform_locale3 != null) for (String s : transform_locale3) sj.add("transform_locale3=" + URLEncoder.encode(s, ENCODING));

			if (decimal_num_locale1 != null) for (String s : decimal_num_locale1) sj.add("decimal_num_locale1=" + URLEncoder.encode(s, ENCODING));

			if (decimal_num_locale2 != null) for (String s : decimal_num_locale2) sj.add("decimal_num_locale2=" + URLEncoder.encode(s, ENCODING));

			if (decimal_num_locale3 != null) for (String s : decimal_num_locale3) sj.add("decimal_num_locale3=" + URLEncoder.encode(s, ENCODING));

			if (max_value_locale1 != null) for (String s : max_value_locale1) sj.add("max_value_locale1=" + URLEncoder.encode(s, ENCODING));

			if (max_value_locale2 != null) for (String s : max_value_locale2) sj.add("max_value_locale2=" + URLEncoder.encode(s, ENCODING));

			if (max_value_locale3 != null) for (String s : max_value_locale3) sj.add("max_value_locale3=" + URLEncoder.encode(s, ENCODING));

			if (min_value_locale1 != null) for (String s : min_value_locale1) sj.add("min_value_locale1=" + URLEncoder.encode(s, ENCODING));

			if (min_value_locale2 != null) for (String s : min_value_locale2) sj.add("min_value_locale2=" + URLEncoder.encode(s, ENCODING));

			if (min_value_locale3 != null) for (String s : min_value_locale3) sj.add("min_value_locale3=" + URLEncoder.encode(s, ENCODING));

			if (sensor_description_locale1 != null) for (String s : sensor_description_locale1) sj.add("sensor_description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (sensor_description_locale2 != null) for (String s : sensor_description_locale2) sj.add("sensor_description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (sensor_description_locale3 != null) for (String s : sensor_description_locale3) sj.add("sensor_description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (measure_type != null) for (String s : measure_type) sj.add("measure_type=" + URLEncoder.encode(s, ENCODING));

			if (data_type != null) for (String s : data_type) sj.add("data_type=" + URLEncoder.encode(s, ENCODING));

			if (fixed_length != null) for (String s : fixed_length) sj.add("fixed_length=" + URLEncoder.encode(s, ENCODING));

			if (time_data_create_flg != null) for (String s : time_data_create_flg) sj.add("time_data_create_flg=" + URLEncoder.encode(s, ENCODING));

			if (short_term_minutes != null) for (String s : short_term_minutes) sj.add("short_term_minutes=" + URLEncoder.encode(s, ENCODING));

			if (sensor_note != null) for (String s : sensor_note) sj.add("sensor_note=" + URLEncoder.encode(s, ENCODING));

			if (device_group_id != null) for (String s : device_group_id) sj.add("device_group_id=" + URLEncoder.encode(s, ENCODING));

			if (device_group_type != null) for (String s : device_group_type) sj.add("device_group_type=" + URLEncoder.encode(s, ENCODING));

			if (device_group_subtype != null) for (String s : device_group_subtype) sj.add("device_group_subtype=" + URLEncoder.encode(s, ENCODING));

			if (device_group_name_locale1 != null) for (String s : device_group_name_locale1) sj.add("device_group_name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (device_group_name_locale2 != null) for (String s : device_group_name_locale2) sj.add("device_group_name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (device_group_name_locale3 != null) for (String s : device_group_name_locale3) sj.add("device_group_name_locale3=" + URLEncoder.encode(s, ENCODING));

			if (device_group_description_locale1 != null) for (String s : device_group_description_locale1) sj.add("device_group_description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (device_group_description_locale2 != null) for (String s : device_group_description_locale2) sj.add("device_group_description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (device_group_description_locale3 != null) for (String s : device_group_description_locale3) sj.add("device_group_description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (parent_device_group_id != null) for (String s : parent_device_group_id) sj.add("parent_device_group_id=" + URLEncoder.encode(s, ENCODING));

			if (setup_place != null) for (String s : setup_place) sj.add("setup_place=" + URLEncoder.encode(s, ENCODING));

			if (setup_status != null) for (String s : setup_status) sj.add("setup_status" + URLEncoder.encode(s, ENCODING));

			if (latitude != null) for (String s : latitude) sj.add("latitude=" + URLEncoder.encode(s, ENCODING));

			if (longitude != null) for (String s : longitude) sj.add("longitude=" + URLEncoder.encode(s, ENCODING));

			if (device_group_note != null) for (String s : device_group_note) sj.add("device_group_note=" + URLEncoder.encode(s, ENCODING));

			if (role_id != null) for (String s : role_id) sj.add("role_id=" + URLEncoder.encode(s, ENCODING));

			if (root_group_id != null) for (String s : root_group_id) sj.add("root_group_id=" + URLEncoder.encode(s, ENCODING));

			if (role_name_locale1 != null) for (String s : role_name_locale1) sj.add("role_name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (role_name_locale2 != null) for (String s : role_name_locale2) sj.add("role_name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (role_name_locale3 != null) for (String s : role_name_locale3) sj.add("role_name_locale3=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale1 != null) for (String s : role_description_locale1) sj.add("role_description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale2 != null) for (String s : role_description_locale2) sj.add("role_description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale3 != null) for (String s : role_description_locale3) sj.add("role_description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (role_note != null) for (String s : role_note) sj.add("role_note=" + URLEncoder.encode(s, ENCODING));

			if (hierarchy != null) for (String s : role_note) sj.add("hierarchy=" + URLEncoder.encode(s, ENCODING));

			if (sort != null) sj.add("sort=" + URLEncoder.encode(sort, ENCODING));

			if (fields != null) sj.add("fields=" + URLEncoder.encode(fields, ENCODING));

			if (page != null) sj.add("page=" + URLEncoder.encode(page, ENCODING));

			if (limit != null) sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}

package com.app.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ファイル登録モデル
 *
 * @author 1572
 */
@Data
public class PostFileModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ファイル種別")
	private String file_type;

	@ApiModelProperty(value = "コンテナ名 ※次の場合、パラメータエラー ・展開用ファイル用コンテナ(expansion) ・受信ファイル用コンテナ(receivefile)" , required = true)
	private String container;

	@ApiModelProperty(value = "ファイル名(ファイルパス情報含む)")
	private String file_name;

	@ApiModelProperty(value = "圧縮有無フラグ" , required = true)
	private String zip_flg;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "センサーID")
	private String sensor_id;

	@ApiModelProperty(value = "base64 フラグ")
	private String base64_flg;

	@ApiModelProperty(value = "ファイルデータ ※base64 フラグ = false の場合はエスケープした値、base64 フラグ = true の場合、エスケープ無しの値をセット",required = true)
	private String file_data;

	@ApiModelProperty(value = "予備1")
	private String reserve1;

	@ApiModelProperty(value = "予備2")
	private String reserve2;

	@ApiModelProperty(value = "予備3")
	private String reserve3;

	@ApiModelProperty(value = "予備4")
	private String reserve4;

	@ApiModelProperty(value = "予備5")
	private String reserve5;

	/* API内で値を設定するため、非公開とする。 */
	@ApiModelProperty(value = "ユーザID", hidden = true)
	private String user_id;


}

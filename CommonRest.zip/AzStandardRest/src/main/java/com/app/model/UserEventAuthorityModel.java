package com.app.model;

import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザ・イベント権限情報モデル
 *
 * @author 1625
 *
 */
@Data
public class UserEventAuthorityModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "イベントID")
	private String event_id;

	@ApiModelProperty(value = "イベント種別")
	private String event_type;

	@ApiModelProperty(value = "イベントレベル")
	private String event_level;

	@ApiModelProperty(value = "センサーID")
	private String sensor_id;

	@ApiModelProperty(value = "名称(ロケール１)")
	private String name_locale1;

	@ApiModelProperty(value = "名称(ロケール２)")
	private String name_locale2;

	@ApiModelProperty(value = "名称(ロケール３)")
	private String name_locale3;

	@ApiModelProperty(value = "説明(ロケール１)")
	private String description_locale1;

	@ApiModelProperty(value = "説明(ロケール２)")
	private String description_locale2;

	@ApiModelProperty(value = "説明(ロケール３)")
	private String description_locale3;

	@ApiModelProperty(value = "アラーム検出アプリ名")
	private String chk_app_name;

	@ApiModelProperty(value = "アラーム検出パラメータ")
	private String chk_app_parameter;

	@ApiModelProperty(value = "チェックタイミング")
	private String check_timing;

	@ApiModelProperty(value = "備考")
	private String note;

	@ApiModelProperty(value = "デバイスグループID")
	private String device_group_id;

	@ApiModelProperty(value = "デバイスグループ種別")
	private String device_group_type;

	@ApiModelProperty(value = "デバイスグループサブ種別")
	private String device_group_subtype;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール1)")
	private String device_group_name_locale1;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール2)")
	private String device_group_name_locale2;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール3)")
	private String device_group_name_locale3;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール1)")
	private String device_group_description_locale1;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール2)")
	private String device_group_description_locale2;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール3)")
	private String device_group_description_locale3;

	@ApiModelProperty(value = "親デバイスグループID")
	private String parent_device_group_id;

	@ApiModelProperty(value = "設置場所")
	private String setup_place;

	@ApiModelProperty(value = "設置状態")
	private String setup_status;

	@ApiModelProperty(value = "緯度")
	private BigDecimal latitude;

	@ApiModelProperty(value = "経度")
	private BigDecimal longitude;

	@ApiModelProperty(value = "デバイスグループ備考")
	private String device_group_note;

	@ApiModelProperty(value = "ロールID")
	private String role_id;

	@ApiModelProperty(value = "ルートグループID")
	private String root_group_id;

	@ApiModelProperty(value = "ロール情報名称(ロケール1)")
	private String role_name_locale1;

	@ApiModelProperty(value = "ロール情報名称(ロケール2)")
	private String role_name_locale2;

	@ApiModelProperty(value = "ロール情報名称(ロケール3)")
	private String role_name_locale3;

	@ApiModelProperty(value = "ロール情報説明(ロケール1)")
	private String role_description_locale1;

	@ApiModelProperty(value = "ロール情報説明(ロケール2)")
	private String role_description_locale2;

	@ApiModelProperty(value = "ロール情報説明(ロケール3)")
	private String role_description_locale3;

	@ApiModelProperty(value = "ロール情報備考")
	private String role_note;

	@ApiModelProperty(value = "デバイスグループ階層")
	private Integer hierarchy;
}

package com.app.model;
import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class UserRollModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "")
	private Integer id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9!#\\$%&'\\*\\+\\-\\/=\\?\\^_\\{\\|\\}\\(\\)<>\\[\\]:;@\\.,\"]*$", message = "{" + Consts.MESSAGE_E000056 + "}")
	@ApiModelProperty(value = "ユーザID" , required =true)
	private String user_id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "ロールID" , required =true)
	private String role_id;

	@ApiModelProperty(value = "")
	private Long version;

	@ApiModelProperty(value = "")
	private String inserted;

	@ApiModelProperty(value = "")
	private String insert_time;

	@ApiModelProperty(value = "")
	private String updated;

	@ApiModelProperty(value = "")
	private String update_time;

}

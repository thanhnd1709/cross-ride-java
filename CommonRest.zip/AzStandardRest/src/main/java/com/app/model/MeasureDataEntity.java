package com.app.model;

import java.sql.Timestamp;


public class MeasureDataEntity {
	private String modelId;
	private String serialNo;
	private String sensorId;
	private Timestamp measureTime;
	private String measureData;
	private char dataMigrateClass;
	
	public MeasureDataEntity() {
		super();
	}
	public String getModelId() {
		return modelId;
	}
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getSensorId() {
		return sensorId;
	}
	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}
	public Timestamp getMeasureTime() {
		return measureTime;
	}
	public void setMeasureTime(Timestamp measureTime) {
		this.measureTime = measureTime;
	}
	public String getMeasureData() {
		return measureData;
	}
	public void setMeasureData(String measureData) {
		this.measureData = measureData;
	}
	public char getDataMigrateClass() {
		return dataMigrateClass;
	}
	public void setDataMigrateClass(char dataMigrateClass) {
		this.dataMigrateClass = dataMigrateClass;
	}
	
}

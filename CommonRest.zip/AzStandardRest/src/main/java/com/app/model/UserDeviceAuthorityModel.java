package com.app.model;

import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザ・デバイス権限情報モデル
 *
 * @author 1572
 *
 */
@Data
public class UserDeviceAuthorityModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "デバイス種別")
	private String device_type;

	@ApiModelProperty(value = "IoTデバイスフラグ")
	private Boolean iot_device_flg;

	@ApiModelProperty(value = "通信デバイスフラグ")
	private Boolean communication_flg;

	@ApiModelProperty(value = "デバイス情報名称(ロケール１)")
	private String device_name_locale1;

	@ApiModelProperty(value = "デバイス情報名称(ロケール２)")
	private String device_name_locale2;

	@ApiModelProperty(value = "デバイス情報名称(ロケール３)")
	private String device_name_locale3;

	@ApiModelProperty(value = "デバイス情報説明(ロケール１)")
	private String device_description_locale1;

	@ApiModelProperty(value = "デバイス情報説明(ロケール２)")
	private String device_description_locale2;

	@ApiModelProperty(value = "デバイス情報説明(ロケール３)")
	private String device_description_locale3;

	@ApiModelProperty(value = "メーカーコード")
	private String maker_code;

	@ApiModelProperty(value = "親機種ID")
	private String parent_model_id;

	@ApiModelProperty(value = "親シリアルNo")
	private String parent_serial_no;

	@ApiModelProperty(value = "設置場所")
	private String setup_place;

	@ApiModelProperty(value = "設置状態")
	private String setup_status;

	@ApiModelProperty(value = "タイムゾーン")
	private String time_zone;

	@ApiModelProperty(value = "緯度")
	private BigDecimal latitude;

	@ApiModelProperty(value = "経度")
	private BigDecimal longitude;

	@ApiModelProperty(value = "デバイスモード")
	private String device_mode;

	@ApiModelProperty(value = "未受信許容秒数")
	private Integer unreceive_seconds;

	@ApiModelProperty(value = "デバイス情報備考")
	private String device_note;

	@ApiModelProperty(value = "デバイスグループID")
	private String device_group_id;

	@ApiModelProperty(value = "ロールID")
	private String role_id;

	@ApiModelProperty(value = "ルートグループID")
	private String root_group_id;

	@ApiModelProperty(value = "デバイスグループ種別")
	private String device_group_type;
	
	@ApiModelProperty(value = "デバイスグループサブ種別")
	private String device_group_subtype;
	
	@ApiModelProperty(value = "デバイスグループ名称(ロケール1)")
	private String device_group_name_locale1;
	
	@ApiModelProperty(value = "デバイスグループ名称(ロケール2)")
	private String device_group_name_locale2;
	
	@ApiModelProperty(value = "デバイスグループ名称(ロケール3)")
	private String device_group_name_locale3;
	
	@ApiModelProperty(value = "デバイスグループ説明(ロケール1)")
	private String device_group_description_locale1;
	
	@ApiModelProperty(value = "デバイスグループ説明(ロケール2)")
	private String device_group_description_locale2;
	
	@ApiModelProperty(value = "デバイスグループ説明(ロケール3)")
	private String device_group_description_locale3;
	
	@ApiModelProperty(value = "親デバイスグループID")
	private String parent_device_group_id;

	@ApiModelProperty(value = "デバイスグループ備考")
	private String device_group_note;
	
//	@ApiModelProperty(value = "ユーザID")
//	private String user_id;

	@ApiModelProperty(value = "ロール情報名称(ロケール1)")
	private String role_name_locale1;

	@ApiModelProperty(value = "ロール情報名称(ロケール2)")
	private String role_name_locale2;

	@ApiModelProperty(value = "ロール情報名称(ロケール3)")
	private String role_name_locale3;

	@ApiModelProperty(value = "ロール情報説明(ロケール1)")
	private String role_description_locale1;

	@ApiModelProperty(value = "ロール情報説明(ロケール2)")
	private String role_description_locale2;

	@ApiModelProperty(value = "ロール情報説明(ロケール3)")
	private String role_description_locale3;

	@ApiModelProperty(value = "ロール情報備考")
	private String role_note;
	
	@ApiModelProperty(value = "デバイスグループ階層")
	private Integer hierarchy;
	
}

package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイスグループアラーム状態取得モデル
 */
@Data
public class ResponseDeviceGroupAlarmStatusModel {

	@ApiModelProperty(value = "デバイスグループID")
	private String device_group_id;

	@ApiModelProperty(value = "検出区分")
	private String detection_class;

	@ApiModelProperty(value = "直下最大イベントレベル")
	private String max_event_level;

}

package com.app.model;
import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class BaseSensorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ID")
	private Integer id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "機種ID" , required =true)
	private String model_id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@Pattern(regexp = "^[a-zA-Z0-9\\-:\\.\\+_\\*!\\(\\),=;']*$", message = "{" + Consts.MESSAGE_E000043 + "}")
	@ApiModelProperty(value = "センサーID" , required =true)
	private String sensor_id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "センサー種別" , required =true)
	private String sensor_type;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール1)" , required =true)
	private String name_locale1;

	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール2)")
	private String name_locale2;

	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "名称(ロケール3)")
	private String name_locale3;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "単位(ロケール1)" , required =true)
	private String unit_locale1;

	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "単位(ロケール2)")
	private String unit_locale2;

	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "単位(ロケール3)")
	private String unit_locale3;

	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "変換式(ロケール1)")
	private String transform_locale1;

	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "変換式(ロケール2)")
	private String transform_locale2;

	@Size(max = 100, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "変換式(ロケール3)")
	private String transform_locale3;

	@ApiModelProperty(value = "小数点桁数(ロケール1)")
	private Integer decimal_num_locale1;

	@ApiModelProperty(value = "小数点桁数(ロケール2)")
	private Integer decimal_num_locale2;

	@ApiModelProperty(value = "小数点桁数(ロケール3)")
	private Integer decimal_num_locale3;

	@ApiModelProperty(value = "上限値(ロケール1)")
	private Double max_value_locale1;

	@ApiModelProperty(value = "上限値(ロケール2)")
	private Double max_value_locale2;

	@ApiModelProperty(value = "上限値(ロケール3)")
	private Double max_value_locale3;

	@ApiModelProperty(value = "下限値(ロケール1)")
	private Double min_value_locale1;

	@ApiModelProperty(value = "下限値(ロケール2)")
	private Double min_value_locale2;

	@ApiModelProperty(value = "下限値(ロケール3)")
	private Double min_value_locale3;

	@Size(max = 2000, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール1)")
	private String description_locale1;

	@Size(max = 2000, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール2)")
	private String description_locale2;

	@Size(max = 2000, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "説明(ロケール3)")
	private String description_locale3;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Pattern(regexp = "^1|2$", message = "{" + Consts.MESSAGE_E000044 + "}")
	@ApiModelProperty(value = "計測タイプ（1：データ / 2：ファイル）" , required =true)
	private String measure_type;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Pattern(regexp = "^int|long|real|float|bit|stat|string|binary|json|other$", message = "{" + Consts.MESSAGE_E000042 + "}")
	@ApiModelProperty(value = "データ型（int：整数(4バイト) / long：整数(8バイト) / real：実数(有効桁数7桁) / float：実数(有効桁数15桁) / bit：ビット列 / stat：状態数値 / "
			+ "string:テキスト / binary：バイナリデータ / json：JSON形式 / other：その他(数値配列など)）" , required =true)
	private String data_type;

	@ApiModelProperty(value = "固定長サイズ")
	private Integer fixed_length;

	@ApiModelProperty(value = "時系列データ作成フラグ（true：時系列データ(Table storage)を作成する / false：時系列データ(Table storage)を作成しない）")
	private Boolean time_data_create_flg;

	@ApiModelProperty(value = "短期保管時間")
	private Integer short_term_minutes;

	@Size(max = 2000, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "備考")
	private String note;

	@ApiModelProperty(value = "個別属性同期フラグ（true：当マスタ登録・更新時、センサー情報(Sql Database) も合わせて更新する / false）")
	private Boolean attribute_sync_flg;

	@ApiModelProperty(value = "バージョン")
	private Long version;

	@ApiModelProperty(value = "登録者")
	private String inserted;

	@ApiModelProperty(value = "登録時刻")
	private String insert_time;

	@ApiModelProperty(value = "更新者")
	private String updated;

	@ApiModelProperty(value = "更新時刻")
	private String update_time;

}

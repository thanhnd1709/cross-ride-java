package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイス情報モデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class SensorModel3 {

	@ApiModelProperty(value = "機種ID ※デバイス(機種ID または S/N)どちらかは必須")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo ※デバイス(機種ID または S/N)どちらかは必須")
	private String serial_no;

	@ApiModelProperty(value = "センサーID")
	private String sensor_id;

	public SensorModel3(String model_id, String serial_no, String sensor_id){
		this.model_id = model_id;
		this.serial_no = serial_no;
		this.sensor_id = sensor_id;
	}
}

package com.app.model;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイス下センサ情報取得モデル
 */
@Data
public class DeviceSensorModel {

	@ApiModelProperty(value = "[配列]デバイスリスト（機種ID、シリアルNo）" , required =true)
	private List<DeviceListModel> device_list;

}
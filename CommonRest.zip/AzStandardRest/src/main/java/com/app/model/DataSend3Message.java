package com.app.model;

import java.util.List;

public class DataSend3Message extends DataSendMessage {
	public List<DataSend3TimeData> timeList;

	public class DataSend3TimeData {
		public String sensorId;
		public String measureStartTime;
		public String measureInterval;
		public List<String> dataList;

		public String getSensorId() {
			return sensorId;
		}

		public void setSensorId(String sensorId) {
			this.sensorId = sensorId;
		}

		public String getMeasureStartTime() {
			return measureStartTime;
		}

		public void setMeasureStartTime(String measureStartTime) {
			this.measureStartTime = measureStartTime;
		}

		public String getMeasureInterval() {
			return measureInterval;
		}

		public void setMeasureInterval(String measureInterval) {
			this.measureInterval = measureInterval;
		}

		public List<String> getDataList() {
			return dataList;
		}

		public void setDataList(List<String> dataList) {
			this.dataList = dataList;
		}

	}

	public List<DataSend3TimeData> getTimeList() {
		return timeList;
	}

	public void setTimeList(List<DataSend3TimeData> timeList) {
		this.timeList = timeList;
	}

}

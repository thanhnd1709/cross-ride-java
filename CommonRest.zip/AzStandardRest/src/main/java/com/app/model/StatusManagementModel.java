package com.app.model;
import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
/**
 * イベント・アラーム ステータス管理モデル
 * @author 1572
 */
public class StatusManagementModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ID")
	private Integer id;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "検出区分")
	private String detection_class;

	@ApiModelProperty(value = "イベントID")
	private String event_id;

	@ApiModelProperty(value = "イベント時刻(yyyy-MM-ddTHH:mm:ss.fffffffZ)")
	private String event_time;

	@ApiModelProperty(value = "イベント状態")
	private String event_status;

	@ApiModelProperty(value = "発生復帰区分")
	private String incident_class;

	@ApiModelProperty(value = "イベントレベル")
	private String event_level;

	@ApiModelProperty(value = "対応状況")
	private String cope_status;

	@ApiModelProperty(value = "発生時刻(yyyy-MM-ddTHH:mm:ss.fffffffZ)")
	private String incident_time;

	@ApiModelProperty(value = "復帰状況")
	private String return_time;

	@ApiModelProperty(value = "バージョン")
	private Long version;

	@ApiModelProperty(value = "登録時刻(yyyy-MM-ddTHH:mm:ss.fffffffZ)")
	private String insert_time;

	@ApiModelProperty(value = "更新時刻(yyyy-MM-ddTHH:mm:ss.fffffffZ)")
	private String update_time;
}

package com.app.model;
import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * GWへのファイル情報通知リクエストモデル
 * @author 810
 *
 */
@Data
public class FileInfoNotificationQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "GW機種ID", required = true)
	private String gw_model_id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "GWシリアルNo", required = true)
	private String gw_serial_no;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "コンテナ名", required = true)
	private String container;

	@ApiModelProperty(value = "ファイル名(ファイルパス情報含む)")
	private String file_name;

	@ApiModelProperty(value = "ファイル種別")
	private String file_type;

	@ApiModelProperty(value = "通知情報")
	private Object notice_info;

	@ApiModelProperty(value = "圧縮有無フラグ", required = true)
	private String zip_flg;

	@ApiModelProperty(value = "予備1")
	private String reserve1;

	@ApiModelProperty(value = "予備2")
	private String reserve2;

	@ApiModelProperty(value = "予備3")
	private String reserve3;

	@ApiModelProperty(value = "予備4")
	private String reserve4;

	@ApiModelProperty(value = "予備5")
	private String reserve5;

	@ApiModelProperty(value = "base64フラグ")
	private String base64_flg;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "ファイルデータ ※base64フラグ=false かつ データにダブルクォーテーションが含まれる場合は、エスケープしセットする事", required = true)
	private String file_data;
}

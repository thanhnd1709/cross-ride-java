package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイスグループ階層情報取得モデル
 */
@Data
public class ResponseDeviceGroupStructureModel {

	@ApiModelProperty(value = "デバイスグループ階層（指定デバイスグループID ～親デバイスグループID までを タブ区切りで連結）")
	private String device_group_structure;

	@ApiModelProperty(value = "階層数")
	private Integer level;

	@ApiModelProperty(value = "デバイスグループID")
	private String device_group_id;

}
package com.app.model;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベント・アラームモデル
 */
@Data
public class StdEventModel {

	@ApiModelProperty(value = "機種ID")
	private String modelId;

	@ApiModelProperty(value = "シリアルNo")
	private String serialNo;

	@ApiModelProperty(value = "検出区分")
	private String detectionClass;

	@ApiModelProperty(value = "イベントリスト")
	private List<EventListModel1> eventList;
	
	/* API内で値を設定するため、非公開とする。 */
	@ApiModelProperty(value = "ユーザID",hidden=true)
	private String user_id;
}

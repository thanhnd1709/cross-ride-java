package com.app.model;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RoleRootGroupQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String ENCODING = "UTF-8";

	@ApiModelProperty(value = "ID")
	private String[] id;

	@ApiModelProperty(value = "ロールID")
	private String[] role_id;

	@ApiModelProperty(value = "ルートグループID")
	private String[] root_group_id;

	@ApiModelProperty(value = "バージョン")
	private String[] version;

	@ApiModelProperty(value = "登録者")
	private String[] inserted;

	@ApiModelProperty(value = "登録時刻")
	private String[] insert_time;

	@ApiModelProperty(value = "更新者")
	private String[] updated;

	@ApiModelProperty(value = "更新時刻")
	private String[] update_time;

	@ApiModelProperty(value = "任意並び順条件(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (id != null) for (String s : id) sj.add("id=" + URLEncoder.encode(s, ENCODING));

			if (role_id != null) for (String s : role_id) sj.add("role_id=" + URLEncoder.encode(s, ENCODING));

			if (root_group_id != null) for (String s : root_group_id) sj.add("root_group_id=" + URLEncoder.encode(s, ENCODING));

			if (version != null) for (String s : version) sj.add("version=" + URLEncoder.encode(s, ENCODING));

			if (inserted != null) for (String s : inserted) sj.add("inserted=" + URLEncoder.encode(s, ENCODING));

			if (insert_time != null) for (String s : insert_time) sj.add("insert_time=" + URLEncoder.encode(s, ENCODING));

			if (updated != null) for (String s : updated) sj.add("updated=" + URLEncoder.encode(s, ENCODING));

			if (update_time != null) for (String s : update_time) sj.add("update_time=" + URLEncoder.encode(s, ENCODING));

			if (sort != null) sj.add("sort=" + URLEncoder.encode(sort, ENCODING));

			if (fields != null) sj.add("fields=" + URLEncoder.encode(fields, ENCODING));

			if (page != null) sj.add("page=" + URLEncoder.encode(page, ENCODING));

			if (limit != null) sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}

package com.app.model;

import org.springframework.core.io.InputStreamResource;

import io.swagger.annotations.ApiModelProperty;

/**
 * ファイルモデルクラス
 * @author（TOSCO）ウェイ
 */
public class ResponseFileModel1 {

	@ApiModelProperty(value = "ファイル Stream")
    public InputStreamResource file;

    public ResponseFileModel1(InputStreamResource file) {
        this.file = file;
    }
}

package com.app.model;

import io.swagger.annotations.ApiModelProperty;

/**
 * ファイルモデルクラス
 * @author（TOSCO）ウェイ
 */
public class ResponseFileModel2 {

	@ApiModelProperty(value = "ファイル名")
    public String file_name;
	
    public ResponseFileModel2(String file_name) {
        this.file_name = file_name;
    }

    public ResponseFileModel2() {
        this.file_name = file_name;
    }

    
}

package com.app.model;
import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * GWへのファイル情報通知レスポンスモデル
 * @author 810
 *
 */
@Data
public class FileInfoNotificationModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ファイル名(ファイルパス情報含む)")
	private String file_name;

	@ApiModelProperty(value = "送信ID")
	private Integer send_id;

	@ApiModelProperty(value = "結果詳細コード")
	private String result_detail_code;

	@ApiModelProperty(value = "結果メッセージ")
	private String result_message;

	@ApiModelProperty(value = "取得データ")
	private Object data;

}

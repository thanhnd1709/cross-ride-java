package com.app.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーデータモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class SensorDataModel1 {

	@ApiModelProperty(value = "センサリスト", required = true)
	private List<SensorModel1> sensor_list;
}
